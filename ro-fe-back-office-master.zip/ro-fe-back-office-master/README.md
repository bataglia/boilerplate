## Development setup

1. Install [nodejs 10.x]
2. `npm install -g npm@6.0.1`
3. `npm adduser --registry=https://repo.backbase.com/api/npm/npm-backbase/ --always-auth --scope=@backbase`

        Username: raiffeisen_portal_p5
        Password: raiffeisen1445

4. `npm install -g @angular/cli@8.0.0`
5. `npm install -g @bb-cli/schematics@2.x`
6. `npm install -g @bb-cli/bb-import@2.x`
7. `cd ro-fe-le`
8. `npm install`

## Serving the app

#### Locally
- `npm run start`

App is served on `ro-portal.rbro.rbg.cc:7777`

#### Backbase platform - CXP-Manager
- `npm run deploy:local`

## Setting up a portal in CXP-Manager
1. Access `http://localhost:8080/gateway/cxp-manager`
2. Create a new experience
3. Go to your experience catalog
4. Add `Raiffeisen Page`, the `Raiffeisen Le Angular App Container` and `MainContainer Widget` to your catalog
5. Go to Page Management app of your experience
6. Select `Raiffeisen Page` on the left menu
7. Drop the `Manageable Area` on the page from the catalog
8. Select `Home` page on the Main Navigation menu and change its master page from `Web-basic` to `Raiffeisen Page` and save it
9. Drop the `Raiffeisen Le Angular App Container` on the page
10. Inside the `Raiffeisen Le Angular App Container` drop the `MainContainer Widget`

## General app structure & guidelines

`/apps/raiffeisen-back-office` holds the root module of the angular app. It should remain as clean as possible.

`/apps/raiffeisen-back-office/environments` holds env files for all environments the athena project currently manages.
If environments need to be added|removed, just add|remove the environment.<env>.ts file and 
update **angular.json** looking for the **projects.raiffeisen-back-office.architect.build.configurations** key

`/libs/*` holds all widgets|components|services used across the app

`/libs/core/*` holds all singleton services used in the app (constants, errorHandler, utils, etc)

For mode information read the [official angular style guide for core modules]


        Warning: The core module must be imported only in the root module of the app (app.module.ts). 
        Importing it in other modules creates new instances of the providers defined in the core module.
        

`/libs/shared/*` holds all components|directives|pipes|models used across the app (preloader, 0-data, user-menu, etc.)
- for mode information read the [official angular style guide for shared modules]
- imports & exports the forms|reactive forms module, ngx-bootstrap components modules
- any component libraries that need to be used in the app should also be imported & exported here

All entities in the app have a public_api.ts file used to expose the module and services inside the module. 
Any exports made in this file are importable from `'@raiffeisen/<feature-folder>'`.

`/apps/raiffeisen-back-office/src/proxy.conf.json` can be used for development purposes to redirect all api calls for one or more specified uris to another server, be it local or remote.
For more info check out the [angular-cli documentation]

## Generators

**Available Schematics:**

Collection "@bb-cli/schematics" (default):

- app
- component
- data-module
- design-system
- library
- ng-new
- theme
- ui-component
- widget
 

    npm run ng generate <<item>>

Collection "@schematics/angular":
- appShell
- application
- class
- component
- directive
- enum
- guard
- interface
- library
- module
- pipe
- service
- serviceWorker
- universal
- webWorker


    ng generate @schematics/angular:<<item>>

### Generate widget

Decide if you need a widget, new page, or a component.

// TODO: How to decide that in our current approach?

If you need just a new component, decide if it will be shared across the app.

// TODO: Once we have the design system in place, before generating a component, we should check the design system documentation in order to assess whether our component already exists or not. If not, align with design system team in the creation of your new component.
If so, create a component folder in the shared module folder and create your ts|html files there.

    npm run generate:widget -- --name=example-widget

// FIXME:
After the widget is created, go inside the widget.module.ts file and remove the CommonModule import 
(it is already imported in the SharedModule).

// FIXME:
Inside widget.component.ts remove the style attribute from the **@Component** decorator and replace the **template** attribute with **templateUrl**, 
passing in the path to the feature.component.html file.

// TODO:
When generate something, check the angular.json if the items are being placed as libs.


**Run the local standalone server**

    npm start
    App is served on localhost:7777 and ro-portal.rbro.rbg.cc:7777

**Generate/Serve the application documentation**

Accepted JSDoc tags are:
 - @returns {Type}
 - @ignore
 - @param {Type}
 - @link
 - @example


    npm run docs
    The docs are served on localhost:3500

**Assets**

If we are planning to use CDNs to distribute assets, check [AssetsResolver documentation](http://wa3.backbase.com/foundation/latest/howto/managing-static-assets) from Backbase. It allows you to resolve the path of the files based on the environment configuration.


**i18n**

In `environment.ts` configuration files, you will find `assetsStaticI18n` property which resolves the path for your translation files. This approach give us the flexibility of pointing to a service or CDNs if needed.


**Useful links**

1. **[Backbase documentation]**
2. [Angular real-world app tutorial]
3. [Angular change detection guide]
4. [RxJS Tutorial 1]
5. [RxJS Tutorial 2]
6. [Docs tool documentation]


## Issues found
1. [main.ts is missing from the TypeScript compilation](https://github.com/angular/angular-cli/issues/10735)


[Backbase documentation]: http://wa3.backbase.com/foundation/latest/api
[Angular real-world app tutorial]: https://blog.realworldfullstack.io/real-world-angular-part-0-from-zero-to-cli-ng-a2ff646b90cc
[Angular change detection guide]: https://blog.thoughtram.io/angular/2016/02/22/angular-2-change-detection-explained.html
[RxJS Tutorial 1]: https://www.youtube.com/watch?v=PhggNGsSQyg
[RxJS Tutorial 2]: https://www.youtube.com/watch?v=T9wOu11uU6U&list=PL55RiY5tL51pHpagYcrN9ubNLVXF8rGVi
[angular-cli documentation]: https://github.com/angular/angular-cli/blob/master/docs/documentation/stories/proxy.md
[official angular style guide for shared modules]: https://angular.io/guide/styleguide#shared-feature-module
[official angular style guide for core modules]: https://angular.io/guide/styleguide#core-feature-module
[Docs tool documentation]: https://compodoc.app/guides/getting-started.html
[nodejs 10.x]: https://nodejs.org/dist/v10.16.3/node-v10.16.3-x64.msi
