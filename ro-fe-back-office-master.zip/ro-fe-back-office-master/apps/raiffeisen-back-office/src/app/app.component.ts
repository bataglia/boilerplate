import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

import { TranslateService } from '@ngx-translate/core';
import { distinctUntilChanged } from 'rxjs/operators';

import { AuthFacade } from '@rf-store/auth/auth.facade';
import { DynamicLocaleService } from '@utils/dynamic-locale.service';
import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'bb-raiffeisen-back-office',
  template: '<bb-root></bb-root>',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent extends SubscribedComponent implements OnInit {

  constructor(
    private readonly authFacade: AuthFacade,
    private readonly translateService: TranslateService,
    private readonly localeService: DynamicLocaleService
  ) {
    super();
  }

  ngOnInit() {
    this.authFacade.checkLoginStatus();
    this.registerSubscriptions(this.localeService.locale$.pipe(distinctUntilChanged()).subscribe(value => {
      this.translateService.use(value);
    }));
  }
}
