import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { BackbaseCoreModule } from '@backbase/foundation-ang/core';
import { WebSdkApiModule } from '@backbase/web-sdk-api-ang';
import { MainContainerBackOfficeModule } from '@widget/main-container-back-office';

import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { httpInterceptorProviders } from '@rf-shared/interceptors';

import { AppComponent } from './app.component';
import { ApplicationComponent } from './application/application.component';
// import { AccountModule } from './modules/account/account.module';
// import { DashboardModule } from './modules/dashboard/dashboard.module';
import { LoginModule } from './modules/login/login.module';
import { SharedModule } from './shared/shared.module';
import { RfStoreModule } from './store/store.module';

import { environment } from '@env/environment';
// import { CardListModule } from '@rf-modules/card-list/card-list-module';
import { OtherModule } from '@rf-modules/other/other.module';
// import { PaymentsModule } from '@rf-modules/payments/payments.module';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, environment.assetsStaticI18n, '.json');
}

@NgModule({
  declarations: [AppComponent, ApplicationComponent],
  entryComponents: [ApplicationComponent],
  imports: [
    BrowserModule,
    BackbaseCoreModule.forRoot({
      assets: {
        assetsStaticItemName: environment.assetsStaticItemName
      },
      classMap: {}
    }),
    RouterModule.forRoot([], {
      initialNavigation: false,
      useHash: true,
      scrollPositionRestoration: 'enabled'
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    HttpClientModule,
    SharedModule,
    MainContainerBackOfficeModule,
    WebSdkApiModule,
    LoginModule,
    // AccountModule,
    // DashboardModule,
    // CardListModule,
    // PaymentsModule,
    OtherModule,
    RfStoreModule
  ],
  providers: [...environment.mockProviders, httpInterceptorProviders],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule {}
