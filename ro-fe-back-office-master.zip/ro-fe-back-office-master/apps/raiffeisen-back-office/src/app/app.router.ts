import { Routes } from '@angular/router';

import { AuthGuard } from '@rf-shared/guards/auth.guard';
import { LoginGuard } from '@rf-shared/guards/login.guard';

import { AccountComponent } from '@rf-modules/account/account.component';
import { CardListComponent } from '@rf-modules/card-list/card-list.component';
import { DashboardComponent } from '@rf-modules/dashboard/dashboard.component';
import { LoginComponent } from '@rf-modules/login/login.component';
import { OtherComponent } from '@rf-modules/other/other.component';
import { PaymentsComponent } from '@rf-modules/payments/payments.component';
import { AccountStatementComponent } from '@rf-shared/components/account-statement/account-statement.component';
import { TransactionHistoryComponent } from '@rf-shared/components/transaction-history/transaction-history.component';
import { ApplicationComponent } from './application/application.component';

import { FeatureToggleGuard } from '@rf-shared/guards/feature-toggle.guard';
import { InboxListComponent } from '@rf-shared/components/inbox-list/inbox-list.component';
import { InboxMessageComponent } from '@rf-shared/components/inbox-message/inbox-message.component';

export const appRoutes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [LoginGuard]
  },
  {
    path: '',
    component: ApplicationComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: '',
        redirectTo: 'accounts',
        pathMatch: 'full'
      },
      {
        path: 'accounts',
        children: [
          {
            path: '',
            component: DashboardComponent,
            data: {
              title: 'navigation__labels__accounts__le'
            }
          },
          {
            path: 'statement',
            data: {
              singleMode: true
            },
            component: AccountComponent,
            children: [
              {
                path: '',
                component: AccountStatementComponent
              }
            ]
          },
          {
            path: 'transaction-history',
            data: {
              singleMode: true
            },
            component: AccountComponent,
            children: [
              {
                path: '',
                component: TransactionHistoryComponent
              }
            ]
          }
        ]
      },

      {
        path: 'card-list',
        component: CardListComponent
      },
      {
        path: 'transfers-payments',
        component: PaymentsComponent,
        data: {
          title: 'navigation__labels__transfers_and_payments__le'
        }
      },
      {
        path: 'account-statements',
        data: {
          singleMode: false
        },
        component: AccountComponent,
        children: [
          {
            path: '',
            component: AccountStatementComponent,
            data: {
              title: 'navigation__labels__account_statements__le'
            }
          }
        ]
      },
      {
        path: 'pending-transactions',
        component: OtherComponent,
        data: {
          title: 'navigation__labels__pending_transactions__le'
        }
      },
      {
        path: 'transactions-status',
        component: OtherComponent,
        data: {
          title: 'navigation__labels__transactions_status__le'
        }
      },
      {
        path: 'inbox',
        children: [
          {
            path: '',
            component: InboxListComponent
          },
          {
            path: 'message/:id',
            component: InboxMessageComponent
          }
        ]
      },
      {
        path: 'other',
        component: OtherComponent,
        canActivate: [FeatureToggleGuard],
        data: {
          title: 'navigation__labels__other_functionalities__le',
          feature: 'OTHER_FUNCTIONALITIES'
        }
      }
    ]
  }
];
