import { Location } from '@angular/common';
import {
  AfterViewChecked,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnInit,
  ViewChild
} from '@angular/core';
import { NavigationStart, Router } from '@angular/router';

import { BehaviorSubject, Subscription } from 'rxjs';
import { filter, map } from 'rxjs/operators';

import { DialogService } from '@rf-shared/components/dialog/dialog.service';
import { AuthFacade } from '@rf-store/auth/auth.facade';
import { StoreResetService } from '@rf-store/store-reset.service';
import { UtilsFacade } from '@rf-store/utils/utils.facade';

import { environment } from '@env/environment';
import { FEATURE_TOGGLE } from '@utils/feature-toggle';
import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-application-component',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ApplicationComponent extends SubscribedComponent
  implements OnInit, AfterViewChecked {
  topOffset$ = new BehaviorSubject<number>(0);

  avatarName$ = this.authFacade.legalEntityName$;
  avatarUrl$ = this.authFacade.avatarUrl$;

  footerTechnical$ = this.utilsFacade.footerTechnical$;
  footerUserGuide$ = this.utilsFacade.footerUserGuide$;
  footerGeneral$ = this.utilsFacade.footerGeneral$;
  footerTerms$ = this.utilsFacade.footerTerms$;

  promptSubscription: Subscription;
  cdnPath = environment.cdnPath;
  path = '';

  featureToggle = FEATURE_TOGGLE;

  @ViewChild('header', { static: true }) header: ElementRef;

  constructor(
    private readonly authFacade: AuthFacade,
    private readonly utilsFacade: UtilsFacade,
    private readonly storeResetService: StoreResetService,
    private readonly dialogService: DialogService,
    private readonly location: Location,
    private readonly router: Router
  ) {
    super();
  }

  ngOnInit() {
    this.utilsFacade.footerData();
    this.utilsFacade.getSystemDate();
    this.path = this.location.path().substr(1);
    this.registerSubscriptions(
      this.router.events
        .pipe(
          filter((event) => event instanceof NavigationStart),
          map((event) => event as NavigationStart)
        )
        .subscribe((event) => {
          this.path = event.url.substr(1);
        })
    );
  }

  ngAfterViewChecked() {
    this.topOffset$.next(this.header.nativeElement.clientHeight);
  }

  refreshApplication() {
    if (this.location.path() === '/accounts') {
      window.location.reload();
    } else {
      this.router.navigate(['/accounts']);
    }
  }

  promptLogOut() {
    this.promptSubscription = this.dialogService
      .open('user__labels__logout__confirm_message')
      .subscribe((res) => {
        if (res !== null) {
          this.removeSubscription(this.promptSubscription);
          this.promptSubscription.unsubscribe();
          if (res) {
            this.storeResetService.resetAllStates();
          }
        }
      });

    this.registerSubscriptions(this.promptSubscription);
  }
}
