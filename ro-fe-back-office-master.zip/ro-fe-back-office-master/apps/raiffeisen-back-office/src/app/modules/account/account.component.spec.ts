import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';

import { TranslateModule } from '@ngx-translate/core';

import { SharedModule } from '@rf-shared/shared.module';
import { RfStoreModule } from '@rf-store/store.module';

import { AccountComponent } from './account.component';

xdescribe('AccountComponent', () => {
  let component: AccountComponent;
  let fixture: ComponentFixture<AccountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountComponent],
      imports: [
        SharedModule,
        RouterModule.forRoot([]),
        RfStoreModule,
        HttpClientModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change selection value', async () => {
    component.changeSelected([]);

    component.selectedAccounts$.subscribe(value => {
      expect(value.length).toEqual(0);
      expect(value).toEqual([]);
    });
  });

  it('should destroy data and remove item from localStorage', () => {
    localStorage.setItem('savedSelectedAccountIds', 'test');
    fixture.destroy();
    expect(localStorage.getItem('savedSelectedAccountIds')).toBeNull();
    expect(component.routeSubscription.closed).toBeTruthy();
  });
});
