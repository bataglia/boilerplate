import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Subscription } from 'rxjs';

import { AccountsFacade } from '@rf-store/accounts/accounts.facade';
import * as fromModel from '@rf-store/accounts/accounts.model';
import { AuthFacade } from '@rf-store/auth/auth.facade';
import { CardsFacade } from '@rf-store/cards/cards.facade';

@Component({
  selector: 'ui-rzbr-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountComponent implements OnInit, OnDestroy {
  selectedAccounts$ = this.accountsFacade.selectedAccounts$;
  accounts$ = this.accountsFacade.items$;
  legalEntityName$ = this.authFacade.legalEntityName$;
  singleMode = false;
  routeSubscription: Subscription;

  constructor(
    private readonly accountsFacade: AccountsFacade,
    private readonly authFacade: AuthFacade,
    private readonly activatedRoute: ActivatedRoute,
    private readonly router: Router,
    private readonly cardFacade: CardsFacade
  ) {}

  ngOnInit() {
    this.routeSubscription = this.activatedRoute.data.subscribe((data) => {
      if (data.singleMode !== undefined) {
        this.singleMode = data.singleMode;
        if (!this.singleMode) {
          this.accountsFacade.resetStore();
          this.cardFacade.resetStore();
          this.accountsFacade.loadAccounts();
          this.cardFacade.loadCreditCards();
        } else {
          this.selectedAccounts$
            .subscribe((value) => {
              if (value.length === 0) {
                const accountIdsAsString = localStorage.getItem(
                  'savedSelectedAccountIds'
                );

                if (accountIdsAsString === null) {
                  this.router.navigateByUrl('/');
                } else {
                  let accountIds = [];

                  try {
                    accountIds = JSON.parse(accountIdsAsString);
                  } catch {}

                  if (accountIds.length === 0) {
                    localStorage.removeItem('savedSelectedAccountIds');
                    this.router.navigateByUrl('/');
                  } else {
                    this.accountsFacade.getAllAndSetSelected(accountIds);
                  }
                }
              } else {
                localStorage.setItem(
                  'savedSelectedAccountIds',
                  JSON.stringify(value.map((x) => x.id))
                );
              }
            })
            .unsubscribe();
        }
      }
    });
  }

  changeSelected(items: fromModel.Account[]) {
    this.accountsFacade.setSelectedItems(items);
  }

  ngOnDestroy() {
    this.changeSelected([]);
    localStorage.removeItem('savedSelectedAccountIds');
    if (this.routeSubscription) {
      this.routeSubscription.unsubscribe();
    }
  }
}
