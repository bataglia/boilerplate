import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BackbaseCoreModule } from '@backbase/foundation-ang/core';

import { SharedModule } from '@rf-shared/shared.module';

import { AccountComponent } from './account.component';

@NgModule({
  declarations: [AccountComponent],
  imports: [
    CommonModule,
    BackbaseCoreModule.withConfig({
      classMap: { AccountComponent }
    }),
    RouterModule,
    SharedModule
  ]
})
export class AccountModule {}
