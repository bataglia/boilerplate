import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BackbaseCoreModule } from '@backbase/foundation-ang/core';

import { SharedModule } from '@rf-shared/shared.module';

import { CardListComponent } from './card-list.component';

@NgModule({
  declarations: [CardListComponent],
  imports: [
    CommonModule,
    BackbaseCoreModule.withConfig({
      classMap: { CardListComponent }
    }),
    RouterModule,
    SharedModule
  ]
})
export class CardListModule {}
