import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

import { combineLatest, zip } from 'rxjs';
import { map } from 'rxjs/operators';

import { AccountsFacade } from '@rf-store/accounts/accounts.facade';
import { CardsFacade } from '@rf-store/cards/cards.facade';
import { UtilsFacade } from '@rf-store/utils/utils.facade';

import { ResizeService } from '@utils/resize.service';
import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-card-list',
  templateUrl: './card-list.component.html',
  styleUrls: ['./card-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardListComponent extends SubscribedComponent implements OnInit {
  items$ = this.cardsFacade.items$;

  cardsLoading$ = this.cardsFacade.loading$;

  loadedDebit$ = this.cardsFacade.loadedDebit$;

  loadedCredit = this.cardsFacade.loadedCredit$;

  accountsLoaded$ = this.accountsFacade.loaded$;

  accountsLoading$ = this.accountsFacade.loading$;

  systemDate$ = this.utilsFacade.systemDate$;

  windowWidth$ = this.resizeService.windowWidth$;

  get isLoading$() {
    return combineLatest(
      this.items$,
      this.accountsLoading$,
      this.cardsLoading$,
      this.windowWidth$
    ).pipe(
      map(([cards, accountsLoading, cardsLoading, windowWidth]) => ({
        cardsLength: cards.length,
        accountsLoading,
        cardsLoading,
        elements: windowWidth > 767 ? 7 : 6
      })),
      map(({ cardsLength, accountsLoading, cardsLoading, elements }) => {
        let result = true;

        if (cardsLength >= elements && result) {
          result = false;
        }

        if (!accountsLoading && !cardsLoading && result) {
          result = false;
        }

        return result;
      })
    );
  }

  constructor(
    private readonly cardsFacade: CardsFacade,
    private readonly utilsFacade: UtilsFacade,
    private readonly accountsFacade: AccountsFacade,
    private readonly resizeService: ResizeService
  ) {
    super();
  }

  ngOnInit() {
    this.registerSubscriptions(
      zip(this.accountsLoaded$, this.loadedDebit$)
        .pipe(
          map(([accounts, debit]) => {
            let requested = false;

            if (!accounts) {
              this.accountsFacade.resetStore();
              this.cardsFacade.resetStore();
              this.cardsFacade.loadCreditCards();
              this.accountsFacade.loadAccounts();
              this.cardsFacade.loadDebitCards();
              requested = true;
            }

            if (!debit && !requested) {
              this.cardsFacade.loadDebitCards();
            }
          })
        )
        .subscribe()
    );
  }
}
