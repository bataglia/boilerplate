import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BackbaseCoreModule } from '@backbase/foundation-ang/core';
import { TestBed } from '@angular/core/testing';
import { ComponentFixture } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { RfStoreModule } from '@rf-store/store.module';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from '@rf-shared/shared.module';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DashboardComponent],
      imports: [
        BackbaseCoreModule.forRoot({}),
        TranslateModule.forRoot(),
        RfStoreModule,
        SharedModule,
        HttpClientTestingModule,
        RouterModule.forRoot([])
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    });

    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
  });

  it('should create the component', () => {
    expect(component).toBeDefined();
  });

  it('should start with error empty', async () => {
    component.items$.subscribe((value) => expect(value).toEqual([]));
  });

  it('should start with loading false', async () => {
    component.itemsLoading$.subscribe((value) => expect(value).toBeFalsy());
  });
});
