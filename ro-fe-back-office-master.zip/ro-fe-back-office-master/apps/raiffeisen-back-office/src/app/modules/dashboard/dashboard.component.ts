import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AccountsFacade } from '@rf-store/accounts/accounts.facade';
import * as fromModel from '@rf-store/accounts/accounts.model';
import { AuthFacade } from '@rf-store/auth/auth.facade';
import { CardsFacade } from '@rf-store/cards/cards.facade';
import { UtilsFacade } from '@rf-store/utils/utils.facade';
import { ResizeService } from '@utils/resize.service';

import { APP_VERSION } from '@version';

@Component({
  selector: 'ui-rzbr-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit {
  appVersion: string = APP_VERSION;

  items$ = this.accountsFacade.items$;

  itemsLoading$ = this.accountsFacade.loading$;

  itemsLoaded$ = this.accountsFacade.loaded$;

  cards$ = this.cardsFacade.items$;

  cardsLoading$ = this.cardsFacade.loading$;

  legalEntityName$ = this.authFacade.legalEntityName$;

  windowWidth$ = this.resizeService.windowWidth$;

  systemDate$ = this.utilsFacade.systemDate$;

  constructor(
    private readonly accountsFacade: AccountsFacade,
    private readonly cardsFacade: CardsFacade,
    private readonly authFacade: AuthFacade,
    private readonly resizeService: ResizeService,
    private readonly utilsFacade: UtilsFacade,
    private readonly router: Router
  ) {}

  ngOnInit() {
    this.cardsFacade.resetStore();
    this.accountsFacade.resetStore();
    this.accountsFacade.loadAccounts();
    this.cardsFacade.loadCreditCards();

    if (this.resizeService.windowWidth > 767) {
      this.cardsFacade.loadDebitCards();
    }
  }

  goToAccountStatement(item: fromModel.Account) {
    this.accountsFacade.setSelectedItems([item]);
    this.router.navigateByUrl('/accounts/statement');
  }

  goToAccountOverview(item: fromModel.Account) {
    this.accountsFacade.setSelectedItems([item]);
    this.router.navigateByUrl('/accounts/transaction-history');
  }
}
