import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BackbaseCoreModule } from '@backbase/foundation-ang/core';

import { SharedModule } from '@rf-shared/shared.module';

import { DashboardComponent } from './dashboard.component';

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    BackbaseCoreModule.withConfig({
      classMap: { DashboardComponent }
    }),
    RouterModule,
    SharedModule
  ]
})
export class DashboardModule {}
