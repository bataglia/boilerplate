import { PreloaderComponent } from './../../shared/components/preloader/preloader.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { LoginFormComponent } from '@rf-shared/components/login-form/login-form.component';
import { TranslateModule } from '@ngx-translate/core';
import { LanguageToggleComponent } from '@rf-shared/components/language-toggle/language-toggle.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RfStoreModule } from '@rf-store/store.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterModule } from '@angular/router';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('LoginComponent: ', () => {
  let fixture: ComponentFixture<LoginComponent>;
  let comp: LoginComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        LoginComponent,
        LoginFormComponent,
        PreloaderComponent,
        LanguageToggleComponent
      ],
      providers: [],
      imports: [
        TranslateModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        RfStoreModule,
        HttpClientTestingModule,
        RouterModule.forRoot([])
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    comp = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should instantiate the component', async () => {
    expect(comp).toBeTruthy();
  });

  it('should start with error empty', async () => {
    comp.error$.subscribe((value) => expect(value).toEqual(''));
  });

  it('should start with loading false', async () => {
    comp.loading$.subscribe((value) => expect(value).toBeFalsy());
  });
});
