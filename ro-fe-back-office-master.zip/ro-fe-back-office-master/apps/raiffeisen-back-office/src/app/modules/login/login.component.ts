import { ChangeDetectionStrategy, Component } from '@angular/core';

import { AuthFacade } from '@rf-store/auth/auth.facade';
import * as fromModel from '@rf-store/auth/auth.model';

import { APP_VERSION } from '@version';

import { environment } from '@env/environment';

@Component({
  selector: 'ui-rzbr-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent {
  loading$ = this.authFacade.loading$;

  error$ = this.authFacade.error$;

  appVersion = APP_VERSION;

  cdnPath = environment.cdnPath;

  constructor(private readonly authFacade: AuthFacade) {}

  login(data: fromModel.LoginPostData) {
    this.authFacade.login(data);
  }

  resetStore() {
    this.authFacade.resetStore();
  }
}
