import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { BackbaseCoreModule } from '@backbase/foundation-ang/core';
import { DataHttpModule } from '@backbase/foundation-ang/data-http';

import { SharedModule } from '@rf-shared/shared.module';

import { LoginComponent } from './login.component';

@NgModule({
  declarations: [LoginComponent],
  imports: [
    CommonModule,
    BackbaseCoreModule.withConfig({
      classMap: { LoginComponent }
    }),
    DataHttpModule,
    SharedModule
  ]
})
export class LoginModule {}
