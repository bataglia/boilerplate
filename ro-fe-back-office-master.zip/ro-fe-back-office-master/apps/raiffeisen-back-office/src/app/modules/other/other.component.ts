import { ChangeDetectionStrategy, Component } from '@angular/core';
import { StoreResetService } from '@rf-store/store-reset.service';

import { environment } from '@env/environment';

@Component({
  selector: 'ui-rzbr-other',
  templateUrl: './other.component.html',
  styleUrls: ['./other.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OtherComponent {

  environment = environment.isEnv;

  constructor(private readonly storeResetService: StoreResetService) {}

  goToPf() {
    this.storeResetService.redirectToPf();
  }
}
