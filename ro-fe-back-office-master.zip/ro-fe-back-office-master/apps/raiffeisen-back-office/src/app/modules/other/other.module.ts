import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BackbaseCoreModule } from '@backbase/core-ang';

import { SharedModule } from '@rf-shared/shared.module';

import { OtherComponent } from './other.component';

@NgModule({
  declarations: [OtherComponent],
  imports: [
    CommonModule,
    BackbaseCoreModule.withConfig({
      classMap: { OtherComponent }
    }),
    RouterModule,
    SharedModule
  ]
})
export class OtherModule {}
