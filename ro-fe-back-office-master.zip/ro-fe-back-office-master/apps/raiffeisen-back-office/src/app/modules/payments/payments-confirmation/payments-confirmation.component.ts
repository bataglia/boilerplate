import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'ui-rzbr-payments-confirmation',
  templateUrl: './payments-confirmation.component.html',
  styleUrls: ['./payments-confirmation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsConfirmationComponent {}
