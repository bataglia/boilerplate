import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { PaymentsFacade } from '@rf-store/payments/payments.facade';
import * as fromModel from '@rf-store/payments/payments.model';
import { SubscribedComponent } from '@utils/subscribed-component';

import { distinctUntilChanged, map } from 'rxjs/operators';

@Component({
  selector: 'ui-rzbr-currency-form',
  templateUrl: './currency-form.component.html',
  styleUrls: ['./currency-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CurrencyFormComponent extends SubscribedComponent {
  private _item: fromModel.ClassificationFields;

  private _form: FormGroup;

  postFormCurrency$ = this.paymentsFacade.postFormCurrency$;

  /**
   * Due to data keys being all over the place we need to manually treat them
   * In this input we're creating the form with corresponding validators and registering it into the store with 2-way communication
   */
  @Input() set item(value: fromModel.ClassificationFields) {
    if (value) {
      let selectedValue = '';

      if (value.values) {
        selectedValue = value.values
          .map((item) => (item.selected ? item.value : ''))
          .reduce((_, curr) => {
            return curr;
          }, '');
      }

      const validators = [];

      if (value.mandatory) {
        validators.push(Validators.required);
      }

      this._form = new FormGroup({
        data: this.fb.control(selectedValue, validators)
      });

      this.paymentsFacade.updateFormCurrency(selectedValue);

      this.registerSubscriptions(
        this.form.valueChanges
          .pipe(map((group) => group.data))
          .subscribe((data) => {
            this.paymentsFacade.updateFormCurrency(data);
          }),

        this.paymentsFacade.postFormCurrency$
          .pipe(distinctUntilChanged((x, y) => x !== y))
          .subscribe((data) => {
            this.form.setValue({ data });
          })
      );

      this._item = value;
    }
  }

  get item() {
    return this._item;
  }

  get form() {
    return this._form;
  }

  constructor(
    private readonly fb: FormBuilder,
    private readonly paymentsFacade: PaymentsFacade
  ) {
    super();
  }
}
