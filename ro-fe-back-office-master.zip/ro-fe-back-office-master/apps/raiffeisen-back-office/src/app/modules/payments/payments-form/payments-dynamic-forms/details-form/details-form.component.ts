import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { TranslateService } from '@ngx-translate/core';

import { distinctUntilChanged, map } from 'rxjs/operators';

import { PaymentsFacade } from '@rf-store/payments/payments.facade';
import * as fromModel from '@rf-store/payments/payments.model';

import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-details-form',
  templateUrl: './details-form.component.html',
  styleUrls: ['./details-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DetailsFormComponent extends SubscribedComponent {
  private _item: fromModel.ClassificationFields;

  private _form: FormGroup;

  /**
   * Due to data keys being all over the place we need to manually treat them
   * In this input we're creating the form with corresponding validators and registering it into the store with 2-way communication
   */
  @Input() set item(value: fromModel.ClassificationFields) {
    if (value) {
      let selectedValue = this.translateService.instant(value.placeholderId);

      const reg = value.rules
        .filter((rule) => rule.ruleId === 'REGEX')
        .reduce((_, curr) => {
          return curr.value;
        }, '');

      const maxRows = value.rules
        .filter((rule) => rule.ruleId === 'MAX_ROWS')
        .reduce((_, curr) => {
          return curr.value;
        }, '');

      const maxSize = value.rules
        .filter((rule) => rule.ruleId === 'MAX_SIZE')
        .reduce((_, curr) => {
          return curr.value;
        }, '');

      const regex = new RegExp(reg);

      const validators = [Validators.pattern(regex)];

      if (value.mandatory) {
        validators.push(Validators.required);
      }

      this._form = new FormGroup({
        data: this.fb.control(selectedValue, validators)
      });

      this.registerSubscriptions(
        this.translateService
          .getTranslation(value.placeholderId)
          .subscribe((text) => {
            selectedValue = text;
          }),

        // TODO: the value saved into the store must be an array and the 2-way registration must be set like that
        this.form.valueChanges
          .pipe(map((group) => group.data))
          .subscribe((data) => {
            this.paymentsFacade.updateDetails([data, data]);
            console.log('form.ValueChanges', data);
          }),

        this.paymentsFacade.postFormDetails$
          .pipe(distinctUntilChanged((x, y) => x.join() !== y.join()))
          .subscribe((data) => {
            console.log('store.PaymentsFacade', data);
            //   this.form.setValue({data})
          })
      );

      this._item = value;
    }
  }

  get item() {
    return this._item;
  }

  get form() {
    return this._form;
  }

  constructor(
    private readonly fb: FormBuilder,
    private readonly paymentsFacade: PaymentsFacade,
    private readonly translateService: TranslateService
  ) {
    super();
  }
}
