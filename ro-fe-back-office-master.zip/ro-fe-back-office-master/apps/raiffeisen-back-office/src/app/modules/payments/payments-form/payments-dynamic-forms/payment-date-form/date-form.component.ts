import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { PaymentsFacade } from '@rf-store/payments/payments.facade';
import * as fromModel from '@rf-store/payments/payments.model';
import { SubscribedComponent } from '@utils/subscribed-component';

import { distinctUntilChanged, map } from 'rxjs/operators';
@Component({
  selector: 'ui-rzbr-date-form',
  templateUrl: './date-form.component.html',
  styleUrls: ['./date-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DateFormComponent extends SubscribedComponent {
  private _item: fromModel.ClassificationFields;

  private _form: FormGroup;

  postFormBasicPaymentDate$ = this.paymentsFacade.postFormBasicPaymentDate$;

  /**
   * Due to data keys being all over the place we need to manually treat them
   * In this input we're creating the form with corresponding validators and registering it into the store with 2-way communication
   */
  @Input() set item(value: fromModel.ClassificationFields) {
    if (value) {
      const validators = [];

      if (value.mandatory) {
        validators.push(Validators.required);
      }

      this._form = new FormGroup({
        data: this.fb.control('', validators)
      });

      /// item.rules is an array that will create 2 more components like this, you should take that in consideration
      /// this component represents the minimum amount of work, will need to expand

      this.registerSubscriptions(
        this.form.valueChanges
          .pipe(map((group) => group.data))
          .subscribe((data) => {
            this.paymentsFacade.updatePaymentDate(data);
          }),

        this.paymentsFacade.postFormBasicPaymentDate$
          .pipe(distinctUntilChanged((x, y) => x !== y))
          .subscribe((data) => {
            this.form.setValue({ data });
          })
      );

      this._item = value;
    }
  }

  get item() {
    return this._item;
  }

  get form() {
    return this._form;
  }

  constructor(
    private readonly fb: FormBuilder,
    private readonly paymentsFacade: PaymentsFacade
  ) {
    super();
  }
}
