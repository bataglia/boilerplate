import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import * as fromModel from '@rf-store/payments/payments.model';
/**
 * 
 * Using ClassificationFields[] it's separating each field to individual variable and passing it to the corresponding component.
 * The template of this component is used to order the fields correctly
 * 
 */
@Component({
  selector: 'ui-rzbr-payments-dynamic-forms',
  templateUrl: './payments-dynamic-forms.component.html',
  styleUrls: ['./payments-dynamic-forms.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsDynamicFormsComponent {
  private _items: fromModel.ClassificationFields[] = [];

  private _currencyField: fromModel.ClassificationFields;
  private _paymentDateField: fromModel.ClassificationFields;
  private _detailsField: fromModel.ClassificationFields;

  @Input() set items(value: fromModel.ClassificationFields[]) {
    for (const item of value) {
      switch (item.name) {
        case 'currency':
          this._currencyField = item;
          break;
        case 'paymentDate':
          this._paymentDateField = item;
          break;
        case 'details':
          this._detailsField = item;
          break;
        default:
          break;
      }
    }
    this._items = value;
  }

  get items() {
    return this._items;
  }

  get currencyField() {
    return this._currencyField;
  }

  get paymentDateField() {
    return this._paymentDateField;
  }

  get detailsField() {
    return this._detailsField;
  }
}
