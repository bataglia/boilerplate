import { ChangeDetectionStrategy, Component } from '@angular/core';

import { FormatAmountPipe } from '@rf-shared/pipes/format-amount.pipe';
import { IbanDisplayPipe } from '@rf-shared/pipes/iban-display.pipe';
import { PaymentsFacade } from '@rf-store/payments/payments.facade';

@Component({
  selector: 'ui-rzbr-payments-form',
  templateUrl: './payments-form.component.html',
  styleUrls: ['./payments-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsFormComponent {
  classificationFields$ = this.paymentsFacade.classifyFields$;

  postFormFromAccountIban$ = this.paymentsFacade.postFormFromAccountIban$;

  postFormToAccountIban$ = this.paymentsFacade.postFormToAccountIban$;

  postFormAmount$ = this.paymentsFacade.postFormToAccountIban$;

  selectedFromAccount$ = this.paymentsFacade.selectedFromAccount$;

  constructor(
    private readonly paymentsFacade: PaymentsFacade,
    private readonly formatAmount: FormatAmountPipe,
    private readonly ibanDisplay: IbanDisplayPipe
  ) {}

  postPayment() {
    this.paymentsFacade.postPayment();
  }

  validate() {
    this.paymentsFacade.validate();
  }
}
