import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from '@angular/forms';
import { distinctUntilChanged, map } from 'rxjs/operators';

import { PaymentsFacade } from '@rf-store/payments/payments.facade';

import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-payments-amount-form',
  templateUrl: './payments-amount-form.component.html',
  styleUrls: ['./payments-amount-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsAmountFormComponent extends SubscribedComponent
  implements OnInit {
  form = new FormGroup({
    data: this.fb.control(null, [Validators.required, Validators.min(0)])
  });

  constructor(
    private readonly paymentsFacade: PaymentsFacade,
    private readonly fb: FormBuilder
  ) {
    super();
  }

  // /**
  //  *
  //  * @param iban
  //  * Using IBAN is selecting the ballance of the account and updates the amount validator.
  //  */
  // updateAmountFormValidators(iban: string) {
  //   this.registerSubscriptions(
  //     this.paymentsFacade.fromAccountsBalance$(iban).subscribe((balance) => {
  //       const control = this.form.get('data') as FormControl;

  //       control.setValidators([Validators.max(balance)]);
  //       control.updateValueAndValidity();
  //     })
  //   );
  // }

  ngOnInit() {
    this.registerSubscriptions(
      this.form.valueChanges
        .pipe(map((group) => group.data))
        .subscribe((value) => {
          this.paymentsFacade.updateAmount(value);
        }),

      this.paymentsFacade.postFormAmount$
        .pipe(distinctUntilChanged((x, y) => x !== y))
        .subscribe((data) => {
          this.form.setValue({ data });
        })

      // this.paymentsFacade.postFormFromAccountIban$.subscribe((data) => {
      //   if (data) {
      //     this.updateAmountFormValidators(data);
      //   }
      // })
    );
  }
}
