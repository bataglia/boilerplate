import {
  ChangeDetectionStrategy,
  Component,
  forwardRef,
  Input
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import * as fromModel from '@rf-store/payments/payments.model';

@Component({
  selector: 'ui-rzbr-payments-from-select',
  templateUrl: './payments-from-select.component.html',
  styleUrls: ['./payments-from-select.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      // tslint:disable-next-line: no-forward-ref
      useExisting: forwardRef(() => PaymentsFromSelectComponent),
      multi: true
    }
  ]
})
export class PaymentsFromSelectComponent implements ControlValueAccessor {
  private _options: fromModel.Account[];

  private _selected: fromModel.Account | null;

  @Input() set options(value: fromModel.Account[]) {
    this._options = value;

    if (value.length === 1) {
      this.opened = false;
    }
  }

  get options() {
    return this._options;
  }

  @Input() set selected(value: fromModel.Account | null) {
    this._selected = value;

    if (!value) {
      this.opened = true;
    }
  }

  get selected() {
    return this._selected;
  }

  @Input() disabled = false;

  opened = true;

  outsideClickListener: () => void;

  onChange: (data: any) => void = () => undefined;
  onTouched: () => void = () => undefined;

  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean) {
    this.disabled = isDisabled;
  }

  writeValue(value: fromModel.Account) {
    this.onChange(value);
  }
}
