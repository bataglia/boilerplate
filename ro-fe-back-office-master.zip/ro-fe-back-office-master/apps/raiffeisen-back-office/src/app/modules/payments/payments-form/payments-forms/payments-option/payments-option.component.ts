import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

import * as fromModel from '@rf-store/payments/payments.model';

@Component({
  selector: 'ui-rzbr-payments-option',
  templateUrl: './payments-option.component.html',
  styleUrls: ['./payments-option.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsOptionComponent {
  @Input() item: fromModel.Account;
  @Input() avatar: string;
  @Input() placeholder: string;
  @Input() ownAccount = false;
  @Input() select = false;
  @Input() caretDirection = false;
  @Input() hover = false;
  @Input() showCaret = true;

  @Output() private readonly valueChanged = new EventEmitter();

  selectItem() {
    this.valueChanged.emit(this.item);
  }
}
