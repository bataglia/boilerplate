import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { PaymentsFacade } from '@rf-store/payments/payments.facade';

import { SubscribedComponent } from '@utils/subscribed-component';
import { distinctUntilChanged, map } from 'rxjs/operators';

import * as fromModel from '@rf-store/payments/payments.model';

import { isDistinctData } from '@rf-shared/helpers/form-helpers';

@Component({
  selector: 'ui-rzbr-payments-to-form',
  templateUrl: './payments-to-form.component.html',
  styleUrls: ['./payments-to-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsToFormComponent extends SubscribedComponent
  implements OnInit {
  toAccounts$ = this.paymentsFacade.toAccounts$;

  selectedToAccount$ = this.paymentsFacade.selectedToAccount$;

  form = new FormGroup({
    data: this.fb.control(null, [Validators.required])
  });

  constructor(
    private readonly paymentsFacade: PaymentsFacade,
    private readonly fb: FormBuilder
  ) {
    super();
  }

  ngOnInit() {
    this.registerSubscriptions(
      this.form.valueChanges
        .pipe(map((group) => group.data as fromModel.Account))
        .subscribe((data) => {
          this.paymentsFacade.selectToAccount(data);
        }),

      this.paymentsFacade.selectedToAccount$
        .pipe(distinctUntilChanged(isDistinctData))
        .subscribe((data) => {
          this.form.setValue({ data });

          if (data) {
            this.paymentsFacade.classifyPayment();
          }
        })

    );
  }
}
