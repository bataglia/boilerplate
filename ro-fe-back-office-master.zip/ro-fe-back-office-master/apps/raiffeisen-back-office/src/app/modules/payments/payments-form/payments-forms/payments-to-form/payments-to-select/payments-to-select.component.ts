import {
  ChangeDetectionStrategy,
  Component,
  forwardRef,
  Input
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import { PaymentsFacade } from '@rf-store/payments/payments.facade';
import * as fromModel from '@rf-store/payments/payments.model';
import { SubscribedComponent } from '@utils/subscribed-component';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'ui-rzbr-payments-to-select',
  templateUrl: './payments-to-select.component.html',
  styleUrls: ['./payments-to-select.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      // tslint:disable-next-line: no-forward-ref
      useExisting: forwardRef(() => PaymentsToSelectComponent),
      multi: true
    }
  ]
})
export class PaymentsToSelectComponent extends SubscribedComponent
  implements ControlValueAccessor {
  private _options: fromModel.Account[];

  private _selected: fromModel.Account | null;

  @Input() set options(value: fromModel.Account[]) {
    this._options = value;
  }

  get options() {
    return this._options;
  }

  @Input() set selected(value: fromModel.Account | null) {
    this._selected = value;
  }

  get selected() {
    return this._selected;
  }

  @Input() disabled = false;

  opened = true;

  constructor(private readonly paymentsFacade: PaymentsFacade) {
    super();
  }

  outsideClickListener: () => void;

  onChange: (data: any) => void = () => undefined;
  onTouched: () => void = () => undefined;

  searchDisabled$(): Observable<boolean> {
    return this.paymentsFacade.selectedFromAccount$.pipe(
      map((selected) => (selected ? selected.typeId === '26' : false))
    );
  }

  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean) {
    this.disabled = isDisabled;
  }

  writeValue(value: fromModel.Account | null) {
    this.onChange(value);
  }
}
