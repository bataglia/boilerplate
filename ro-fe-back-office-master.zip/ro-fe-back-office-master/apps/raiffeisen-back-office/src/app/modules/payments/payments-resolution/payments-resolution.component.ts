import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'ui-rzbr-payments-resolution',
  templateUrl: './payments-resolution.component.html',
  styleUrls: ['./payments-resolution.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsResolutionComponent {}
