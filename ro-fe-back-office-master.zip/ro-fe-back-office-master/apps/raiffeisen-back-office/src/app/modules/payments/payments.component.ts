import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';

import { Subscription } from 'rxjs';
import { withLatestFrom } from 'rxjs/operators';

import * as moment from 'moment';

import { DynamicComponentInterface } from '@rf-shared/components/dynamic-factory/dynamic-factory.service';
import { PaymentDetailsComponent } from '@rf-shared/components/payment-details/payment-details.component';
import { WizardFormStepComponent } from '@rf-shared/components/wizard/wizard-form-step/wizard-form-step.component';

import { PaymentsConfirmationComponent } from './payments-confirmation/payments-confirmation.component';
import { PaymentsFormComponent } from './payments-form/payments-form.component';
import { PaymentsResolutionComponent } from './payments-resolution/payments-resolution.component';

import { AccountsFacade } from '@rf-store/accounts/accounts.facade';
import { PaymentsFacade } from '@rf-store/payments/payments.facade';
import { UtilsFacade } from '@rf-store/utils/utils.facade';

import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsComponent extends SubscribedComponent
  implements OnInit, OnDestroy {
  accountsLoaded$ = this.accountsFacade.loaded$;

  accountsLoading$ = this.accountsFacade.loading$;

  accountItems$ = this.accountsFacade.items$;

  fromAccounts$ = this.paymentsFacade.fromAccounts$;

  dbLoading$ = this.paymentsFacade.dbLoading$;

  dbLoaded$ = this.paymentsFacade.dbLoaded$;

  wizardIndex = 0;

  subscription: Subscription;

  dynamicPaymentForm: DynamicComponentInterface = {
    component: PaymentsFormComponent
  };
  dynamicPaymentDetails: DynamicComponentInterface = {
    component: PaymentDetailsComponent
  };

  wizardSteps: DynamicComponentInterface[] = [
    {
      component: WizardFormStepComponent,
      input: {
        formComponent: this.dynamicPaymentForm,
        detailsComponent: this.dynamicPaymentDetails
      }
    },
    {
      component: PaymentsConfirmationComponent
    },
    {
      component: PaymentsResolutionComponent
    }
  ];

  constructor(
    private readonly accountsFacade: AccountsFacade,
    private readonly paymentsFacade: PaymentsFacade,
    private readonly utilsFacade: UtilsFacade
  ) {
    super();
  }

  ngOnInit() {
    this.subscription = this.accountsLoaded$
      .pipe(withLatestFrom(this.accountsLoading$, this.accountItems$, this.utilsFacade.systemDate$))
      .subscribe(([loaded, loading, accounts, date]) => {
        if (loaded && accounts.length && !loading) {
          this.paymentsFacade.loadEligibleStandardPayment();
        } else if (!loaded && !loading) {
          this.accountsFacade.loadAccounts();
        }

        this.paymentsFacade.updatePaymentDate(date as moment.Moment);
      });
  }

  ngOnDestroy() {
    this.paymentsFacade.resetStore();
    this.subscription.unsubscribe();
  }
}
