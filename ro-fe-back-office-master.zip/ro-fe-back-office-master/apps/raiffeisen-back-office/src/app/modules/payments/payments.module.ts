import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { BackbaseCoreModule } from '@backbase/foundation-ang/core';

import { FormatAmountPipe } from '@rf-shared/pipes/format-amount.pipe';
import { IbanDisplayPipe } from '@rf-shared/pipes/iban-display.pipe';
import { SharedModule } from '@rf-shared/shared.module';

import { PaymentsConfirmationComponent } from './payments-confirmation/payments-confirmation.component';
import { PaymentsFormComponent } from './payments-form/payments-form.component';
import { PaymentsResolutionComponent } from './payments-resolution/payments-resolution.component';
import { PaymentsComponent } from './payments.component';

import { CurrencyFormComponent } from './payments-form/payments-dynamic-forms/currency-form/currency-form.component';
import { DetailsFormComponent } from './payments-form/payments-dynamic-forms/details-form/details-form.component';
import { DateFormComponent } from './payments-form/payments-dynamic-forms/payment-date-form/date-form.component';
import { PaymentsDynamicFormsComponent } from './payments-form/payments-dynamic-forms/payments-dynamic-forms.component';
import { PaymentsAmountFormComponent } from './payments-form/payments-forms/payments-amount-form/payments-amount-form.component';
import { PaymentsFromFormComponent } from './payments-form/payments-forms/payments-from-form/payments-from-form.component';
import { PaymentsFromSelectComponent } from './payments-form/payments-forms/payments-from-form/payments-from-select/payments-from-select.component';
import { PaymentsOptionComponent } from './payments-form/payments-forms/payments-option/payments-option.component';
import { PaymentsToFormComponent } from './payments-form/payments-forms/payments-to-form/payments-to-form.component';
import { PaymentsToSelectComponent } from './payments-form/payments-forms/payments-to-form/payments-to-select/payments-to-select.component';

@NgModule({
  declarations: [
    PaymentsComponent,
    PaymentsDynamicFormsComponent,
    PaymentsFormComponent,
    PaymentsConfirmationComponent,
    PaymentsResolutionComponent,
    PaymentsFromFormComponent,
    PaymentsToFormComponent,
    PaymentsAmountFormComponent,
    PaymentsFromSelectComponent,
    PaymentsToSelectComponent,
    PaymentsOptionComponent,
    CurrencyFormComponent,
    DateFormComponent,
    DetailsFormComponent
  ],
  imports: [
    CommonModule,
    BackbaseCoreModule.withConfig({
      classMap: { PaymentsComponent }
    }),
    RouterModule,
    ReactiveFormsModule,
    SharedModule
  ],
  providers: [FormatAmountPipe, IbanDisplayPipe],
  entryComponents: [
    PaymentsFormComponent,
    PaymentsResolutionComponent,
    PaymentsConfirmationComponent
  ]
})
export class PaymentsModule {}
