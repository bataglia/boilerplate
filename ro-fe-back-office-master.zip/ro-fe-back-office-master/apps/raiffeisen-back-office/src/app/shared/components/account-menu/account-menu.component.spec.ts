import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';

import { SharedModule } from '@rf-shared/shared.module';

import { AccountMenuComponent } from './account-menu.component';

describe('AccountMenuComponent', () => {
  let component: AccountMenuComponent;
  let fixture: ComponentFixture<AccountMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [TranslateModule.forRoot(), SharedModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountMenuComponent);
    component = fixture.componentInstance;
    component.accounts = [];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should hide account tile', () => {
    expect(
      fixture.debugElement.nativeElement.querySelector('.account-menu-tile')
    ).toBeNull();
  });
});
