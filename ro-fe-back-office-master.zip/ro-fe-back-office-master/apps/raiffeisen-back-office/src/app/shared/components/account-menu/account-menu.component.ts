import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';

import * as fromModel from '@rf-store/accounts/accounts.model';

@Component({
  selector: 'ui-rzbr-account-menu',
  templateUrl: './account-menu.component.html',
  styleUrls: ['./account-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class AccountMenuComponent implements OnInit {
  @Input() accounts: fromModel.Account[];
  @Input() selected: fromModel.Account[] = [];
  @Input() legalEntityName: string;
  @Input() singleMode = false;

  @Output() readonly selectedChange: EventEmitter<
    fromModel.Account[]
  > = new EventEmitter();

  constructor() {}

  ngOnInit() {}
}
