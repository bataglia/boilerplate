import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TranslateModule } from '@ngx-translate/core';

import { SafePipe } from '@rf-shared/pipes/safe.pipe';
import { SharedModule } from '@rf-shared/shared.module';

import { AccountSelectionComponent } from './account-selection.component';

describe('AccountSelectionComponent', () => {
  let component: AccountSelectionComponent;
  let fixture: ComponentFixture<AccountSelectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), SharedModule],
      providers: [SafePipe]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should cancel selection and set searchKey = ""', () => {
    spyOn(component['selectedChange'], 'emit');
    component.searchKey = 'test';
    component.cancelSelection();
    expect(component['selectedChange'].emit).toHaveBeenCalled();
    expect(component.searchKey).toEqual('');
  });
});
