import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

import { SimpleFilterPipe } from '@rf-shared/pipes/simple-filter.pipe';
import { ModalService } from '../modal/modal.service';

import * as fromModel from '@rf-store/accounts/accounts.model';

@Component({
  selector: 'ui-rzbr-account-selection',
  templateUrl: './account-selection.component.html',
  styleUrls: ['./account-selection.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountSelectionComponent {
  @Input() set accounts(items: fromModel.Account[]) {
    this._accounts = items;
    this.filterAccounts(this.activeTab);
  }
  get accounts() {
    return this._accounts;
  }
  @Input() set selected(items: fromModel.Account[]) {
    this._selected = items;
  }
  get selected() {
    return this._selected;
  }

  @Output() readonly selectedChange: EventEmitter<
    fromModel.Account[]
  > = new EventEmitter();

  get dropdownLabel() {
    switch (this._selected.length) {
      case 0:
        return 'account_statement__label__choose_accounts';
      case 1:
        return 'async__account_selected';
      default:
        return 'async__accounts_selected';
    }
  }

  private _accounts: fromModel.Account[] = [];
  private _selected: fromModel.Account[] = [];
  searchKey = '';
  expanded = true;
  minKeyLength = 1;
  filterKeys = ['iban', 'currency', 'nickname'];
  activeTab = 20;
  filteredAccounts: fromModel.Account[];

  constructor(
    private readonly simpleFilterPipe: SimpleFilterPipe,
    private readonly modalService: ModalService
  ) {}

  showAccountTab(catId: string) {
    return this._accounts.some((x) => x.typeId === catId);
  }

  filterAccounts(key: number) {
    this.activeTab = key;
    this.filteredAccounts = this._accounts.filter(
      (x) => x.typeId === key.toString()
    );
  }

  cancelSelection() {
    this.selectedChange.emit([]);
    this.searchKey = '';
  }

  getSearchResults(items: fromModel.Account[]) {
    return this.simpleFilterPipe.transform(
      items,
      this.filterKeys,
      this.searchKey
    );
  }

  showPopUp() {
    this.modalService.open('accounts__labels__no_change_category', 'general__actions__ok', true).subscribe().unsubscribe();
  }
}
