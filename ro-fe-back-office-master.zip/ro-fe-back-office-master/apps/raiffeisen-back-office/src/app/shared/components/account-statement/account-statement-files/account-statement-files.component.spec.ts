import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountStatementFilesComponent } from './account-statement-files.component';

describe('AccountStatementFilesComponent', () => {
  let component: AccountStatementFilesComponent;
  let fixture: ComponentFixture<AccountStatementFilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountStatementFilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountStatementFilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
