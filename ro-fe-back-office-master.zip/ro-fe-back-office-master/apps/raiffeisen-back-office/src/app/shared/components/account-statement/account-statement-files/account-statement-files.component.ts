import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import * as fromAccountStatementsModel from '@rf-store/account-statements/account-statements.model';
import * as fromAccountModel from '@rf-store/accounts/accounts.model';

@Component({
  selector: 'ui-rzbr-account-statement-files',
  templateUrl: './account-statement-files.component.html',
  styleUrls: ['./account-statement-files.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementFilesComponent {
  @Input() selectedAccounts: fromAccountModel.SimpleAccount[];
  @Input() set availableStatements(
    items: fromAccountStatementsModel.AccountStatement[]
  ) {
    this.selectedStatements = JSON.parse(JSON.stringify(items));
    this._availableStatements = items;
  }
  get availableStatements() {
    return this._availableStatements;
  }
  selectedStatements: fromAccountStatementsModel.AccountStatement[];
  get totalFiles() {
    return this.selectedStatements.reduce((acc, curr) => {
      return acc + curr.dates.length;
    }, 0);
  }
  get showSecondDownloadBtn() {
    if (this.selectedStatements.length < 2) {
      return false;
    }
    const longItems = this.selectedStatements.filter(
      (x) => x.dates.length >= 4
    );

    if (longItems.length > 1) {
      return true;
    }

    return this.selectedStatements.length > 5;
  }
  private _availableStatements: fromAccountStatementsModel.AccountStatement[];

  getAccountName(accountId: string) {
    const account = this.selectedAccounts.find((x) => x.id === accountId);

    return account ? account.nickname : '';
  }

  getSelectedStatementsWithAccountId(accountId: string) {
    return this.selectedStatements
      .filter((x) => x.accountId === accountId)
      .reduce(
        (_, curr) => {
          return curr.dates;
        },
        [] as string[]
      );
  }

  changeSelectedStatementsWithAccountId(accountId: string, dates: string[]) {
    for (const selected of this.selectedStatements) {
      if (selected.accountId === accountId) {
        selected.dates = dates;
        break;
      }
    }
  }
}
