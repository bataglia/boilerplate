import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';

import { DOCUMENT } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@rf-shared/shared.module';
import { AccountStatementOptionDefaultComponent } from './account-statement-option-default.component';

describe('AccountStatementOptionDefaultComponent', () => {
  let component: AccountStatementOptionDefaultComponent;
  let fixture: ComponentFixture<AccountStatementOptionDefaultComponent>;
  let document: Document;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [TranslateModule.forRoot(), SharedModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountStatementOptionDefaultComponent);
    component = fixture.componentInstance;
  });

  beforeEach(inject([DOCUMENT], (doc: Document) => {
    document = doc;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have class --disabled if not active or disabled', () => {
    component.disabled = false;
    component.active = false;
    fixture.detectChanges();
    expect(
      document.querySelector('.account-statement-option--disabled')
    ).not.toBeNull();

    component.disabled = true;
    component.active = false;
    fixture.detectChanges();
    expect(
      document.querySelector('.account-statement-option--disabled')
    ).not.toBeNull();
  });

  it('should have footer if active is true', () => {
    component.active = true;
    fixture.detectChanges();
    expect(
      document.querySelector('.account-statement-option-footer')
    ).not.toBeNull();
  });
});
