import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { AccountStatementOptionComponent } from '../account-statement-option.component';

@Component({
  selector: 'ui-rzbr-account-statement-option-default',
  templateUrl: './account-statement-option-default.component.html',
  styleUrls: ['./account-statement-option-default.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementOptionDefaultComponent extends AccountStatementOptionComponent {
  @Input() showMT942 = false;
  @Input() tmOrLnSelected = false;

  constructor() {
    super();
  }
}
