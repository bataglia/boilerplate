import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';

import { AccountStatementOptionOnDemandComponent } from './account-statement-option-on-demand.component';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@rf-shared/shared.module';
import { DOCUMENT } from '@angular/common';

describe('AccountStatementOptionOnDemandComponent', () => {
  let component: AccountStatementOptionOnDemandComponent;
  let fixture: ComponentFixture<AccountStatementOptionOnDemandComponent>;
  let document: Document;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [TranslateModule.forRoot(), SharedModule]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountStatementOptionOnDemandComponent);
    component = fixture.componentInstance;
  });

  beforeEach(inject([DOCUMENT], (doc: Document) => {
    document = doc;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have class --disabled if not active or disabled', () => {
    component.disabled = false;
    component.active = false;
    fixture.detectChanges();
    expect(
      document.querySelector('.account-statement-option--disabled')
    ).not.toBeNull();

    component.disabled = true;
    component.active = false;
    fixture.detectChanges();
    expect(
      document.querySelector('.account-statement-option--disabled')
    ).not.toBeNull();
  });
});
