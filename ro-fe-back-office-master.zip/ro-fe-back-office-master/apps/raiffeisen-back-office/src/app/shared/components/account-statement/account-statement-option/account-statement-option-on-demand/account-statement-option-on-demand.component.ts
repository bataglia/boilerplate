import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

import * as moment from 'moment';

import { AccountStatementTypes } from '@rf-store/account-statements/account-statements.model';
import * as fromModel from '@rf-store/accounts/accounts.model';
import { AccountStatementOptionComponent } from '../account-statement-option.component';

@Component({
  selector: 'ui-rzbr-account-statement-option-on-demand',
  templateUrl: './account-statement-option-on-demand.component.html',
  styleUrls: ['./account-statement-option-on-demand.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementOptionOnDemandComponent extends AccountStatementOptionComponent {
  @Input() startDate: moment.Moment;
  @Input() endDate: moment.Moment;
  @Input() activeType: AccountStatementTypes;
  @Input() isTmOrLnSelected = false;
  @Input() set selected(items: fromModel.Account[]) {
    this._selected = items;
    delete this.startDate;
    delete this.endDate;
    this.error = '';
  }
  get selected() {
    return this._selected;
  }
  @Output() readonly startDateChange: EventEmitter<
    moment.Moment
  > = new EventEmitter();
  @Output() readonly endDateChange: EventEmitter<
    moment.Moment
  > = new EventEmitter();
  @Output() readonly activeTypeChange: EventEmitter<
    AccountStatementTypes
  > = new EventEmitter();
  today = moment();
  yesterday = moment().subtract(1, 'days');
  fiveYearsAgo = moment().subtract(5, 'years');
  error = '';
  readonly AccountStatementTypes = AccountStatementTypes;
  private _selected: fromModel.Account[] = [];

  constructor() {
    super();
  }

  getMin(start = true) {
    if (!start && this.startDate) {
      return this.startDate.isBefore(this.yesterday)
        ? this.startDate.toDate()
        : this.yesterday.toDate();
    }
    const maxOpeningDate = this.getMaxOpeningDate();
    const abs = this.fiveYearsAgo.isBefore(maxOpeningDate)
      ? moment(maxOpeningDate)
      : this.fiveYearsAgo;

    return abs.toDate();
  }

  getMax(start = true) {
    if (start && this.endDate) {
      return this.yesterday.isBefore(this.endDate)
        ? this.yesterday.toDate()
        : this.endDate.toDate();
    }

    return this.yesterday.toDate();
  }

  getMaxOpeningDate() {
    return this.selected.reduce((acc, curr) => {
      if (acc > curr.openingDate) {
        return curr.openingDate;
      }

      return acc;
    }, moment().format('YYYY-MM-DD'));
  }

  isDownloadsDisabled() {
    return !this.startDate || !this.endDate || this.error !== '';
  }

  changeType(value: AccountStatementTypes) {
    this.error = '';
    if (value === AccountStatementTypes.INTRADAY) {
      if (this.activeType !== AccountStatementTypes.INTRADAY) {
        this.startDate = this.today;
        this.endDate = this.today;
        this.activeType = value;
      } else {
        this.activeType = AccountStatementTypes.INDIVIDUAL;
        delete this.startDate;
        delete this.endDate;
      }
    } else {
      this.activeType = value;
      if (this.startDate !== undefined && this.endDate !== undefined) {
        const diffDays = this.endDate.diff(this.startDate, 'days');

        this.error =
          value === AccountStatementTypes.CUMULATIVE &&
          this.selected.length > 1 &&
          diffDays > 31
            ? 'account_statement__label__cumulative__error'
            : diffDays > 380
            ? 'account_statement__label__individual__error'
            : '';
      }
    }
  }

  changeDate(date: Date, start = true) {
    if (!date) {
      return;
    }
    const momentDate = moment(date);

    if (start) {
      this.startDate = momentDate;
      if (this.activeType === AccountStatementTypes.INTRADAY) {
        delete this.endDate;
      }
      if (this.endDate) {
        this.error =
          this.selected.length > 1 &&
          this.activeType === AccountStatementTypes.CUMULATIVE && !this.isTmOrLnSelected
            ? moment(this.endDate)
                .subtract('31', 'days')
                .isAfter(this.startDate, 'days')
              ? 'account_statement__label__cumulative__error'
              : ''
            : moment(this.endDate)
                .subtract('380', 'days')
                .isAfter(this.startDate, 'days')
            ? 'account_statement__label__individual__error'
            : '';
      }
    } else {
      this.endDate = momentDate;
      if (this.activeType === AccountStatementTypes.INTRADAY) {
        delete this.startDate;
      }
      if (this.startDate) {
        this.error =
          this.selected.length > 1 &&
          this.activeType === AccountStatementTypes.CUMULATIVE && !this.isTmOrLnSelected
            ? moment(this.startDate)
                .add('31', 'days')
                .isBefore(this.endDate, 'days')
              ? 'account_statement__label__cumulative__error'
              : ''
            : moment(this.startDate)
                .add('380', 'days')
                .isBefore(this.endDate, 'days')
            ? 'account_statement__label__individual__error'
            : '';
      }
    }

    if (this.activeType === AccountStatementTypes.INTRADAY) {
      this.activeType = AccountStatementTypes.INDIVIDUAL;
    }
  }

  getDate(start = true) {
    if (start) {
      if (this.startDate) {
        return this.startDate.toDate();
      }
    } else {
      if (this.endDate) {
        return this.endDate.toDate();
      }
    }

    return;
  }

  downloadBtnClick(ev: EventEmitter<any>) {
    if (this.isDownloadsDisabled()) {
      return;
    }

    this.startDateChange.emit(this.startDate);
    this.endDateChange.emit(this.endDate);
    this.activeTypeChange.emit(this.activeType);
    ev.emit();
  }
}
