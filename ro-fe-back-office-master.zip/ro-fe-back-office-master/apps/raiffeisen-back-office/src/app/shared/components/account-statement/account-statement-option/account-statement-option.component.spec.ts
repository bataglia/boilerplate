import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountStatementOptionComponent } from './account-statement-option.component';

describe('AccountStatementOptionComponent', () => {
  let component: AccountStatementOptionComponent;
  let fixture: ComponentFixture<AccountStatementOptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountStatementOptionComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountStatementOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event clicked', () => {
    spyOn(component['clicked'], 'emit');

    component.emitItemClick();

    expect(component['clicked'].emit).toHaveBeenCalled();
  });

  it('should emit event disabledclick', () => {
    spyOn(component['clickedOnDisable'], 'emit');
    component.disabled = true;
    component.emitItemClick();

    expect(component['clickedOnDisable'].emit).toHaveBeenCalled();
  });
});
