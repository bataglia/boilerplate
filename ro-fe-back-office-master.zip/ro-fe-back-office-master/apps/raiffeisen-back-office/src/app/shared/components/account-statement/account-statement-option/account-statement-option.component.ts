import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

import * as fromModel from '@rf-store/accounts/accounts.model';

@Component({
  selector: 'ui-rzbr-account-statement-option',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementOptionComponent {
  @Input() active = false;
  @Input() disabled = false;
  @Input() disabledDownloads = false;
  @Input() show = true;
  @Input() title = '';
  @Input() description = '';
  @Input() selected: fromModel.Account[] = [];

  @Output() readonly clicked = new EventEmitter();
  @Output() readonly clickedOnDisable = new EventEmitter();
  @Output() readonly pdfClicked = new EventEmitter();
  @Output() readonly xlsClicked = new EventEmitter();
  @Output() readonly mt940Clicked = new EventEmitter();
  @Output() readonly mt942Clicked = new EventEmitter();

  constructor() {}

  emitItemClick() {
    if (this.disabled) {
      this.clickedOnDisable.emit();

      return;
    }

    this.clicked.emit();
  }
}
