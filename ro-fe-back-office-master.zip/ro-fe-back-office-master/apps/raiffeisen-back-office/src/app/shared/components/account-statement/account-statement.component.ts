import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

import * as moment from 'moment';

import { AccountStatementsFacade } from '@rf-store/account-statements/account-statements.facade';
import * as fromAccountStatementsModel from '@rf-store/account-statements/account-statements.model';
import { AccountsFacade } from '@rf-store/accounts/accounts.facade';
import * as fromAccountModel from '@rf-store/accounts/accounts.model';

import { ModalService } from '@rf-shared/components/modal/modal.service';
import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-account-statement',
  templateUrl: './account-statement.component.html',
  styleUrls: ['./account-statement.component.scss'],
  // tslint:disable-next-line: prefer-on-push-component-change-detection
  changeDetection: ChangeDetectionStrategy.Default
})
export class AccountStatementComponent extends SubscribedComponent
  implements OnInit {
  selectedAccounts$ = this.accountsFacade.selectedAccounts$;
  isRequesting$ = this.accountStatementsFacade.loading$;
  availableStatements$ = this.accountStatementsFacade.items$;
  accountLoading$ = this.accountsFacade.loading$;
  statementLoading$ = this.accountStatementsFacade.loading$;
  selectedAccounts: fromAccountModel.Account[];
  selectedSimpleAccounts: fromAccountModel.SimpleAccount[];
  activeTab = 1;
  isTmOrLnSelected = false;
  startDate: moment.Moment;
  endDate: moment.Moment;
  activeType = fromAccountStatementsModel.AccountStatementTypes.INDIVIDUAL;

  constructor(
    private readonly accountsFacade: AccountsFacade,
    private readonly accountStatementsFacade: AccountStatementsFacade,
    private readonly modalService: ModalService
  ) {
    super();
  }

  ngOnInit() {
    this.registerSubscriptions(
      this.selectedAccounts$.subscribe((value) => {
        this.selectedAccounts = value;
        this.selectedSimpleAccounts = this.selectedAccounts.map((x) => {
          return { id: x.id, nickname: x.nickname || '' };
        });
        if (
          this.selectedAccounts.some(
            (account) => account.typeId === '30' || account.typeId === '50'
          )
        ) {
          this.activeTab = 2;
          this.isTmOrLnSelected = true;
          this.activeType =
            fromAccountStatementsModel.AccountStatementTypes.CUMULATIVE;
        } else {
          this.activeTab = 1;
          this.isTmOrLnSelected = false;
          this.activeType = fromAccountStatementsModel.AccountStatementTypes.INDIVIDUAL;
        }

        this.accountStatementsFacade.reset();
      })
    );
  }

  downloadFilesOnRequesting(type: string) {
    if (this.selectedAccounts.length === 0) {
      return;
    }
    if (this.selectedAccounts.length === 1) {
      const account = this.selectedAccounts[0];

      if (
        this.activeType !==
        fromAccountStatementsModel.AccountStatementTypes.INDIVIDUAL
      ) {
        this.accountStatementsFacade.downloadStatementFile({
          accountId: account.id,
          accountType: account.typeId,
          fileFormat: type,
          onRequest: true,
          startDate: this.startDate.format('YYYY-MM-DD'),
          endDate: this.endDate.format('YYYY-MM-DD')
        });
      } else {
        this.accountStatementsFacade.getStatementsList({
          accountId: account.id,
          accountType: account.typeId,
          fileFormat: type,
          onRequest: true,
          startDate: this.startDate.format('YYYY-MM-DD'),
          endDate: this.endDate.format('YYYY-MM-DD')
        });
      }
    } else {
      alert(`Download ${type}: to be continued...`);
    }
  }

  downloadFile(type: string) {
    if (this.selectedAccounts.length === 0) {
      return;
    }
    if (this.selectedAccounts.length === 1) {
      const account = this.selectedAccounts[0];

      this.accountStatementsFacade.downloadStatementFile({
        accountId: account.id,
        accountType: account.typeId,
        fileFormat: type,
        onRequest: false
      });
    }
  }

  showPopUp() {
    this.modalService
      .open(
        'general__actions__account_statement_default_disabled_tab',
        'general__actions__ok',
        true
      )
      .subscribe()
      .unsubscribe();
  }
}
