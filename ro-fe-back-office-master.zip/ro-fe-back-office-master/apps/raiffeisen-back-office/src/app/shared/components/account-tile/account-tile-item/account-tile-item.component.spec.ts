import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RzbrAccountTileItemComponent } from './account-tile-item.component';

describe('AccountTileItemComponent', () => {
  let component: RzbrAccountTileItemComponent;
  let fixture: ComponentFixture<RzbrAccountTileItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RzbrAccountTileItemComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RzbrAccountTileItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
