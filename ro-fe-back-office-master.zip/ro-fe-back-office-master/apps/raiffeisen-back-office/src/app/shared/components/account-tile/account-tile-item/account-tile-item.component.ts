import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';

import * as fromModel from '@rf-store/accounts/accounts.model';

@Component({
  selector: 'ui-rzbr-account-tile-item',
  templateUrl: './account-tile-item.component.html',
  styleUrls: ['./account-tile-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RzbrAccountTileItemComponent {
  @Input() legalEntityName: string;
  @Input() item: fromModel.Account;
  @Input() hideAlertBtn = false;
  @Input() fullWidthPrimaryBtn = false;

  @Output() readonly selectAccount = new EventEmitter();
  @Output() readonly statementBtn = new EventEmitter();
}
