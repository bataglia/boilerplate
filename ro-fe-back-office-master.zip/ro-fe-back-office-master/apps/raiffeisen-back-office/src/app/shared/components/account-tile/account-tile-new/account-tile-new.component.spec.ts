import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { BackbaseCoreModule } from '@backbase/foundation-ang/core';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@rf-shared/shared.module';
import { RfStoreModule } from '@rf-store/store.module';
import { RzbrAccountTileNewComponent } from './account-tile-new.component';

describe('RzbrAccountTileNewComponent', () => {
  let component: RzbrAccountTileNewComponent;
  let fixture: ComponentFixture<RzbrAccountTileNewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        BackbaseCoreModule.forRoot({}),
        TranslateModule.forRoot(),
        RfStoreModule,
        SharedModule,
        HttpClientTestingModule,
        RouterModule.forRoot([])
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    });

    fixture = TestBed.createComponent(RzbrAccountTileNewComponent);
    component = fixture.componentInstance;
  });

  it('should create the component', () => {
    expect(component).toBeDefined();
  });
});
