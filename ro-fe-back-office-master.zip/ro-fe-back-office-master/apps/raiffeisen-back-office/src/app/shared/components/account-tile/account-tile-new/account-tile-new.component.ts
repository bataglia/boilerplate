import { ChangeDetectionStrategy, Component } from '@angular/core';

/* tslint:disable:relative-url-prefix */

@Component({
  selector: 'ui-rzbr-account-tile-new',
  templateUrl: './account-tile-new.component.html',
  styleUrls: ['../account-tile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RzbrAccountTileNewComponent {}
