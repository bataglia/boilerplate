import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { SubscribedComponent } from '@utils/subscribed-component';

import * as fromModel from '@rf-store/accounts/accounts.model';

import { ToasterService } from '../toaster/toaster.service';

@Component({
  selector: 'ui-rzbr-account-tile',
  template: '',
  styleUrls: ['./account-tile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RzbrAccountTileComponent extends SubscribedComponent {
  @Input() account: fromModel.Account;
  @Input() hideAlertBtn = false;
  @Input() fullWidthPrimaryBtn = false;

  @Input() legalEntityName = '';

  @Output() readonly selectAccount = new EventEmitter();
  @Output() readonly statementBtn = new EventEmitter();

  shareTemplateKeywords = [
    'general__labels__owner',
    'general__labels__iban',
    'general__labels__bank_name',
    'general__labels__bank_swift_code',
    'general__labels__currency',
    'general__labels__rzbrrobu',
    'general__labels__raiffeisen_bank'
  ];

  constructor(
    private readonly toasterService: ToasterService,
    private readonly translate: TranslateService
  ) {
    super();
  }

  shareAccountDetails() {
    this.registerSubscriptions(
      this.translate.get(this.shareTemplateKeywords).subscribe((labels) => {
        const template = `${labels.general__labels__owner} ${this.legalEntityName}
${labels.general__labels__iban} ${this.account.iban}
${labels.general__labels__currency}: ${this.account.currency}
${labels.general__labels__bank_name} ${labels.general__labels__raiffeisen_bank}
${labels.general__labels__bank_swift_code} ${labels.general__labels__rzbrrobu}`;

        this.copyToClipboard(template);
        this.toasterService.success('general__labels__copied_to_clipboard');
      })
    );
  }

  copyToClipboard(str: string) {
    const el = document.createElement('textarea');

    el.value = str;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
  }

  setSelectedAccount(e: HTMLElement) {
    if (e.tagName.toLowerCase() === 'button') {
      return;
    }
    this.selectAccount.emit();
  }
}
