import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BackbaseCoreModule } from '@backbase/foundation-ang/core';
import { TestBed } from '@angular/core/testing';
import { ComponentFixture } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { RfStoreModule } from '@rf-store/store.module';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { SharedModule } from '@rf-shared/shared.module';
import { RzbrAccountTile26Component } from './account-tile26.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('RzbrAccountTile26Component', () => {
  let component: RzbrAccountTile26Component;
  let fixture: ComponentFixture<RzbrAccountTile26Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        BackbaseCoreModule.forRoot({}),
        TranslateModule.forRoot(),
        RfStoreModule,
        SharedModule,
        HttpClientTestingModule,
        RouterModule.forRoot([])
      ],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }],
      schemas: [NO_ERRORS_SCHEMA]
    });

    fixture = TestBed.createComponent(RzbrAccountTile26Component);
    component = fixture.componentInstance;
  });

  it('should create the component', () => {
    expect(component).toBeDefined();
  });
});
