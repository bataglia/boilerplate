import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ToasterService } from '@rf-shared/components/toaster/toaster.service';
import { RzbrAccountTileComponent } from '../account-tile.component';

/* tslint:disable:relative-url-prefix */

@Component({
  selector: 'ui-rzbr-account-tile26',
  templateUrl: './account-tile26.component.html',
  styleUrls: ['../account-tile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RzbrAccountTile26Component extends RzbrAccountTileComponent {
  constructor(toasterService: ToasterService, translate: TranslateService) {
    super(toasterService, translate);
  }
}
