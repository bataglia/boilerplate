import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

import { Alert } from '@rf-shared/interfaces/alert';

@Component({
  selector: 'ui-rzbr-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AlertComponent {
  @Input() alert: Alert;
  @Output() readonly clicked = new EventEmitter();

  constructor() {}
}
