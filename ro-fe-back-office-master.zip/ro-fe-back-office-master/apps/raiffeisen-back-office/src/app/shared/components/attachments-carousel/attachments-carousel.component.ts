import { DOCUMENT } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Inject,
  Input,
  Output
} from '@angular/core';

import * as moment from 'moment';

import * as fromModel from '@rf-store/inbox/inbox.model';

import * as helpers from '@utils/helper.functions';

@Component({
  selector: 'ui-rzbr-attachments-carousel',
  templateUrl: './attachments-carousel.component.html',
  styleUrls: ['./attachments-carousel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AttachmentsCarouselComponent {
  utils = helpers;

  @Input() systemDate: moment.Moment;

  @Input() attachments: fromModel.Attachment[] = [];

  @Input() current = 0;

  @Output() readonly currentChange: EventEmitter<number> = new EventEmitter();

  @Output()
  readonly attachmentClick = new EventEmitter();

  constructor(@Inject(DOCUMENT) private readonly document: Document) {}

  getElementWidth() {
    return (this.document.querySelector(`.attachment`) as HTMLElement)
      .clientWidth;
  }

  change(index: number) {
    if (index >= this.attachments.length || index === -1) {
      return;
    }

    const carousel = this.document.querySelector(`.carousel`);

    (carousel as HTMLElement).scrollLeft +=
      this.getElementWidth() * (index - this.current);
    this.current = index;
    this.currentChange.emit(index);
  }

  downloadFile(id: number) {
    this.attachmentClick.emit(id);
  }
}
