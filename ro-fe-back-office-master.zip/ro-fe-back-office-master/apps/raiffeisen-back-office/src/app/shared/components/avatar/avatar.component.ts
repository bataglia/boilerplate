import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'ui-avatar',
  templateUrl: './avatar.component.html',
  styleUrls: ['./avatar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AvatarComponent {
  static MAX_INITIALS_LENGTH = 2;

  @Input() customClass: string;
  @Input() image: string;
  @Input() name = '';

  constructor() {}

  get initials() {
    return this.name
      .replace(/[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]/g, '')
      .split(' ')
      .reduce((initials, word) => `${initials}${word.charAt(0)}`, '')
      .substr(0, AvatarComponent.MAX_INITIALS_LENGTH)
      .toUpperCase();
  }
}
