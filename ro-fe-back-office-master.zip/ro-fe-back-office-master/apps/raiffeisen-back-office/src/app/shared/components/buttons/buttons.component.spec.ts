import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ButtonsComponent } from './buttons.component';
import { TranslateModule } from '@ngx-translate/core';

describe('ButtonsComponent: ', () => {
  let fixture: ComponentFixture<ButtonsComponent>;
  let comp: ButtonsComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ButtonsComponent],
      imports: [TranslateModule.forRoot()]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonsComponent);
    comp = fixture.componentInstance;
  });

  it('should instantiate the component', async () => {
    expect(comp).toBeTruthy();
  });
});
