import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

/**
 *
 * Available Types:
 *  primary
 *  primary-big
 *  primary-bigger
 *  primary-logout
 *  secondary
 *  secondary-big
 *  secondary-bigger
 *  icon-plus
 *  icon-share
 *  icon-alert
 *  icon-logout
 *  fab
 *  dropdown
 *  simple
 *  download
 *  tab
 *
 * <ui-rzbr-buttons
 *      type="primary"
 *      [disabled]="true"
 *      label="general__labels__account_statement"
 *      (clicked)="buttonWasClicked()"
 *      color="red/green/yellow"
 * ></ui-rzbr-buttons>
 *
 *
 */

@Component({
  selector: 'ui-rzbr-buttons',
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ButtonsComponent {
  private _green = false;
  private _red = false;
  private _yellow = false;

  @Input() type = 'primary';

  @Input() label = '';

  @Input() disabled = false;

  @Input() title = '';

  @Input() set color(value: string) {
    switch (value) {
      case 'green':
        this._green = true;
        this._red = false;
        this._yellow = false;
        break;
      case 'red':
        this._green = false;
        this._red = true;
        this._yellow = false;
        break;
      case 'yellow':
        this._green = false;
        this._red = false;
        this._yellow = true;
        break;
      default:
        this._green = false;
        this._red = false;
        this._yellow = false;
    }
  }

  get green() {
    return this._green;
  }

  get red() {
    return this._red;
  }

  get yellow() {
    return this._yellow;
  }

  @Output() private readonly clicked = new EventEmitter();
  @Output() private readonly clickedOnDisable = new EventEmitter();

  click() {
    if (!this.disabled) {
      this.clicked.emit();
    } else {
      this.clickedOnDisable.emit();
    }
  }
}
