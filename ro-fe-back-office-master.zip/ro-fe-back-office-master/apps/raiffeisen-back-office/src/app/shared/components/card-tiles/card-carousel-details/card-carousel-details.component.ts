import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import * as fromModel from '@rf-store/cards/cards.model';

import * as moment from 'moment';

@Component({
  selector: 'ui-rzbr-card-carousel-details',
  templateUrl: './card-carousel-details.component.html',
  styleUrls: ['./card-carousel-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardCarouselDetailsComponent {
  private _items: fromModel.CardData[];

  @Input() set items(value: fromModel.CardData[]) {
    this.item = value[this.index];
    this._items = value;
  }
  get items() {
    return this._items;
  }

  @Input() systemDate: moment.Moment;

  index = 0;

  item: fromModel.CardData;

  setIndex(value: number) {
    this.index = value;

    this.item = this.items[this.index];
  }
}
