import { DOCUMENT } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Inject,
  Input,
  Output
} from '@angular/core';

import * as moment from 'moment';

import * as fromModel from '@rf-store/cards/cards.model';

@Component({
  selector: 'ui-rzbr-card-carousel',
  templateUrl: './card-carousel.component.html',
  styleUrls: ['./card-carousel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardCarouselComponent {
  @Input() systemDate: moment.Moment;

  @Input() height = 400;

  @Input() items: fromModel.CardData[] = [];

  @Input() current = 0;

  @Output() readonly currentChange: EventEmitter<number> = new EventEmitter();

  constructor(@Inject(DOCUMENT) private readonly document: Document) {}

  expireSoon(item: fromModel.CardData) {
    const date = moment(item.expirationDate);

    return date.month() === this.systemDate.month() &&
      date.year() === this.systemDate.year();
  }

  getElementWidth(index: number) {
    return (this.document.querySelector(
      `.carousel-item-${index}`
    ) as HTMLElement).clientWidth;
  }

  change(index: number) {
    if (index >= this.items.length || index === -1) {
      return;
    }

    const carousel = this.document.querySelector(`.carousel`);

    (carousel as HTMLElement).scrollLeft +=
      this.getElementWidth(index) * (index - this.current);
    this.current = index;
    this.currentChange.emit(index);
  }
}
