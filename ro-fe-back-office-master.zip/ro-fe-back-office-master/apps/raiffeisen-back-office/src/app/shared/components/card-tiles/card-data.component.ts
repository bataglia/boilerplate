import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import * as moment from 'moment';

import * as fromModel from '@rf-store/cards/cards.model';

@Component({
  selector: 'ui-rzbr-card-data',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardDataComponent {
  private _item: fromModel.CardData;

  private _disabled = false;

  private _redExpirationDate = false;

  @Input() lastElement = false;

  @Input() systemDate: moment.Moment;

  @Input() set item(value: fromModel.CardData) {
    this._item = value;

    const date = moment(value.expirationDate);

    const month =
      String(date.month() + 1).length === 2
        ? String(date.month() + 1)
        : `0${String(date.month() + 1)}`;

    const year = String(date.year()).substr(2);

    this._item.expirationDateDisplay = `${month}/${year}`;

    this._redExpirationDate =
      date.month() === this.systemDate.month() &&
      date.year() === this.systemDate.year()
        ? true
        : false;

    /// Use this if to find out if the card should be in a disabled state
    this._disabled = false;
  }

  get item() {
    return this._item;
  }

  get redExpirationDate() {
    return this._redExpirationDate;
  }

  get disabled() {
    return this._disabled;
  }
}
