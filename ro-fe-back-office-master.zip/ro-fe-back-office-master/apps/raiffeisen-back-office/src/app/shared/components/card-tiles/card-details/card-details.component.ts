import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { CardDataComponent } from '../card-data.component';

@Component({
  selector: 'ui-rzbr-card-details',
  templateUrl: './card-details.component.html',
  styleUrls: ['./card-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardDetailsComponent extends CardDataComponent {
  constructor() {
    super();
  }
}
