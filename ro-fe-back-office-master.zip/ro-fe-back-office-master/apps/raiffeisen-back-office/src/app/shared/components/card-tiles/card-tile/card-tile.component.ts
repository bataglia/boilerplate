import { ChangeDetectionStrategy, Component } from '@angular/core';

import { CardDataComponent } from '../card-data.component';

@Component({
  selector: 'ui-rzbr-card-tile',
  templateUrl: './card-tile.component.html',
  styleUrls: ['./card-tile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardTileComponent extends CardDataComponent {
  opened = false;

  constructor() {
    super();
  }

  open() {
    if (!this.opened) {
      this.opened = true;
    }
  }

  clickOutside() {
    if (this.opened) {
      this.opened = false;
    }
  }
}
