import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import * as moment from 'moment';

import * as fromModel from '@rf-store/cards/cards.model';

@Component({
  selector: 'ui-rzbr-card-tiles-row',
  templateUrl: './card-tiles-row.component.html',
  styleUrls: ['./card-tiles-row.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class CardTilesRowComponent {
  private _visibleElements = 0;

  private _totalElements = 0;

  private _width = 0;

  @Input() items: fromModel.CardData[];

  @Input() systemDate: moment.Moment;

  @Input() set width(value: number) {
    this._width = value < 1920 ? value : 1920;

    const pagePadding = this.padding * 2;
    const elementPadding = this.padding * 2;

    const cardWidth = elementPadding + this.elementWidth;
    const containerWidth = this._width - pagePadding;
    const moreWidth = elementPadding + this.moreBtnWidth;

    this._visibleElements = Math.floor(
      (containerWidth - moreWidth) / cardWidth
    );

    this._totalElements = Math.floor(containerWidth / cardWidth);
  }

  get width() {
    return this._width;
  }

  get lastElement() {
    return this._totalElements;
  }

  get visibleElements() {
    return this._visibleElements;
  }

  get totalElements() {
    return this._totalElements;
  }

  showMore = false;

  elementWidth = 200;

  moreBtnWidth = 100;

  padding = 32;

}
