import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxComponent } from './checkbox.component';

describe('CheckboxComponent', () => {
  let component: CheckboxComponent;
  let fixture: ComponentFixture<CheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CheckboxComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event checkedChange', () => {
    spyOn(component['checkedChange'], 'emit');

    (document.querySelector('.checkmark') as HTMLElement).click();

    expect(component['checkedChange'].emit).toHaveBeenCalled();
  });

  it('should emit event clicked', () => {
    spyOn(component['clicked'], 'emit');

    (document.querySelector('.checkbox-container') as HTMLElement).click();

    expect(component['clicked'].emit).toHaveBeenCalled();
  });
});
