import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

@Component({
  selector: 'ui-rzbr-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CheckboxComponent {
  @Input() checked = false;

  @Output() readonly checkedChange = new EventEmitter();
  @Output() readonly clicked = new EventEmitter();

  emitClicked(e: Event) {
    e.preventDefault();
    if ((e.target as HTMLElement).classList.contains('checkmark')) {
      this.checkedChange.emit();

      return;
    }
    this.clicked.emit();
  }
}
