import { CommonModule, DecimalPipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';

import { TranslateModule } from '@ngx-translate/core';
import { BsDatepickerModule, CarouselModule, TooltipModule} from 'ngx-bootstrap';

import { RzbrDirectivesModule } from '@rf-shared/directives/directives.module';
import { RzbrPipesModule } from '@rf-shared/pipes/pipes.module';

import { InboxIconComponent } from '@rf-shared/components/inbox-icon/inbox-icon.component';
import { InboxListComponent } from '@rf-shared/components/inbox-list/inbox-list.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { NgArrayPipesModule, NgObjectPipesModule } from 'ngx-pipes';
import { AccountMenuComponent } from './account-menu/account-menu.component';
import { AccountSelectionComponent } from './account-selection/account-selection.component';
import { AccountStatementFilesComponent } from './account-statement/account-statement-files/account-statement-files.component';
import { AccountStatementOptionDefaultComponent } from './account-statement/account-statement-option/account-statement-option-default/account-statement-option-default.component';
import { AccountStatementOptionOnDemandComponent } from './account-statement/account-statement-option/account-statement-option-on-demand/account-statement-option-on-demand.component';
import { AccountStatementOptionComponent } from './account-statement/account-statement-option/account-statement-option.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { RzbrAccountTileItemComponent } from './account-tile/account-tile-item/account-tile-item.component';
import { RzbrAccountTileNewComponent } from './account-tile/account-tile-new/account-tile-new.component';
import { RzbrAccountTileComponent } from './account-tile/account-tile.component';
import { RzbrAccountTile20_531Component } from './account-tile/account-tile20-531/account-tile20-531.component';
import { RzbrAccountTile20Component } from './account-tile/account-tile20/account-tile20.component';
import { RzbrAccountTile26Component } from './account-tile/account-tile26/account-tile26.component';
import { RzbrAccountTile30Component } from './account-tile/account-tile30/account-tile30.component';
import { RzbrAccountTile50Component } from './account-tile/account-tile50/account-tile50.component';
import { AlertComponent } from './alert/alert.component';
import { AvatarComponent } from './avatar/avatar.component';
import { ButtonsComponent } from './buttons/buttons.component';
import { CardCarouselDetailsComponent } from './card-tiles/card-carousel-details/card-carousel-details.component';
import { CardCarouselComponent } from './card-tiles/card-carousel/card-carousel.component';
import { CardDataComponent } from './card-tiles/card-data.component';
import { CardDetailsComponent } from './card-tiles/card-details/card-details.component';
import { CardListItemComponent } from './card-tiles/card-list-item/card-list-item.component';
import { CardTileComponent } from './card-tiles/card-tile/card-tile.component';
import { CardTilesRowComponent } from './card-tiles/card-tiles-row/card-tiles-row.component';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { DatepickerComponent } from './datepicker/datepicker.component';
import { DialogComponent } from './dialog/dialog.component';
import { DialogService } from './dialog/dialog.service';
import { DropdownComponent } from './dropdown/dropdown.component';
import { FooterComponent } from './footer/footer.component';
import { FormatAmountComponent } from './format-amount/format-amount.component';
import { GroupItemComponent } from './group-item/group-item.component';
import { InputComponent } from './input/input.component';
import { LanguageToggleComponent } from './language-toggle/language-toggle.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { MobileNavTileComponent } from './mobile-nav-tile/mobile-nav-tile.component';
import { ModalComponent } from './modal/modal.component';
import { ModalService } from './modal/modal.service';
import { RzbrNavigationMenuComponent } from './navigation-menu/navigation-menu.component';
import { NoInfoComponent } from './no-info/no-info.component';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
import { PdfModalComponent } from './pdf-modal/pdf-modal.component';
import { PDFModalService } from './pdf-modal/pdf-modal.service';
import { PreloaderComponent } from './preloader/preloader.component';
import { RadioButtonComponent } from './radio-button/radio-button.component';
import { SearchBarComponent } from './search-bar/search-bar.component';
import { RzbrToasterComponent } from './toaster/toaster.component';
import { ToggleComponent } from './toggle/toggle.component';
import { TransactionHistoryComponent } from './transaction-history/transaction-history.component';
import { TransactionItemComponent } from './transaction-history/transaction-item/transaction-item.component';
import { TransactionListComponent } from './transaction-history/transaction-list/transaction-list.component';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { WizardFormStepComponent } from './wizard/wizard-form-step/wizard-form-step.component';
import { WizardComponent } from './wizard/wizard.component';
import { AttachmentsCarouselComponent } from '@rf-shared/components/attachments-carousel/attachments-carousel.component';
import { InboxMessageComponent } from '@rf-shared/components/inbox-message/inbox-message.component';

const declarationsAndExport = [
  NoInfoComponent,
  PreloaderComponent,
  LanguageToggleComponent,
  UserMenuComponent,
  FormatAmountComponent,
  AvatarComponent,
  LoginFormComponent,
  RzbrAccountTileComponent,
  RzbrAccountTileItemComponent,
  RzbrAccountTile20Component,
  RzbrAccountTile26Component,
  RzbrAccountTile30Component,
  RzbrAccountTile50Component,
  RzbrAccountTile20_531Component,
  RzbrAccountTileNewComponent,
  RzbrNavigationMenuComponent,
  RzbrToasterComponent,
  ModalComponent,
  DialogComponent,
  PdfModalComponent,
  FooterComponent,
  ButtonsComponent,
  CardTilesRowComponent,
  CardTileComponent,
  MobileNavTileComponent,
  AccountMenuComponent,
  AccountStatementComponent,
  AccountSelectionComponent,
  CheckboxComponent,
  SearchBarComponent,
  AccountStatementFilesComponent,
  AccountStatementOptionComponent,
  AccountStatementOptionOnDemandComponent,
  AccountStatementOptionDefaultComponent,
  CardListItemComponent,
  CardDetailsComponent,
  CardDataComponent,
  CardCarouselComponent,
  CardCarouselDetailsComponent,
  AlertComponent,
  GroupItemComponent,
  DatepickerComponent,
  ToggleComponent,
  RadioButtonComponent,
  PaymentDetailsComponent,
  WizardComponent,
  WizardFormStepComponent,
  TransactionHistoryComponent,
  TransactionItemComponent,
  TransactionListComponent,
  InboxIconComponent,
  InboxListComponent,
  InputComponent,
  DropdownComponent,
  AttachmentsCarouselComponent,
  InboxMessageComponent
];

const entryComponents = [
  AccountStatementComponent,
  TransactionHistoryComponent,
  PaymentDetailsComponent,
  WizardFormStepComponent,
  InboxListComponent,
  InboxMessageComponent
];

@NgModule({
  imports: [
    BrowserAnimationsModule,
    CommonModule,
    TranslateModule,
    RzbrDirectivesModule,
    RzbrPipesModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule,
    BsDatepickerModule.forRoot(),
    InfiniteScrollModule,
    NgArrayPipesModule,
    NgObjectPipesModule,
    TooltipModule.forRoot()
  ],
  exports: [...declarationsAndExport, FormsModule, ReactiveFormsModule],
  declarations: [...declarationsAndExport],
  entryComponents: [...entryComponents],
  providers: [DecimalPipe, ModalService, DialogService, PDFModalService]
})
export class RzbrComponentsModule {}
