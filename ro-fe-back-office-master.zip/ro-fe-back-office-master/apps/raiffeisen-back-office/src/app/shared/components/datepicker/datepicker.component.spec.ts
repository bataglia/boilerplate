import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RzbrComponentsModule } from '../components.module';

import { DatepickerComponent } from './datepicker.component';

describe('DatepickerComponent', () => {
  let component: DatepickerComponent;
  let fixture: ComponentFixture<DatepickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RzbrComponentsModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatepickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit clickEvent', () => {
    spyOn(component['clicked'], 'emit');

    component.click(document.createElement('div'));

    expect(component['clicked'].emit).toHaveBeenCalled();
  });

  it('should emit event when disabled', () => {
    spyOn(component['clickOnDisabled'], 'emit');
    component.disabled = true;
    component.click(document.createElement('div'));

    expect(component['clickOnDisabled'].emit).toHaveBeenCalled();
  });
});
