import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  forwardRef,
  Input,
  Output,
  ViewChild
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import { BsDatepickerDirective } from 'ngx-bootstrap';

import { DynamicLocaleService } from '@utils/dynamic-locale.service';

@Component({
  selector: 'ui-rzbr-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      // tslint:disable-next-line: no-forward-ref
      useExisting: forwardRef(() => DatepickerComponent),
      multi: true
    }
  ]
})
export class DatepickerComponent implements ControlValueAccessor {
  @ViewChild('dp', { static: false }) dp: BsDatepickerDirective;
  @Input() placeholder = '';
  @Input() disabled = false;
  @Input() readonly = false;
  @Input() minDate: Date;
  @Input() maxDate: Date;
  @Input() set date(date: Date) {
    if (this.dp !== undefined) {
      if (date !== undefined) {
        this.dp._bsValue = date;
      } else {
        delete this.dp._bsValue;
      }
    }
    this._date = date;
  }
  get date() {
    return this._date;
  }

  @Output() readonly valueChange: EventEmitter<Date> = new EventEmitter();
  @Output() readonly clickOnDisabled = new EventEmitter();
  @Output() readonly clicked = new EventEmitter();
  @Output() readonly hidden = new EventEmitter();
  @Output() readonly shown = new EventEmitter();

  private _date: Date;
  locale$ = this.dynamicLocaleService.locale$;

  bsConfig = {
    adaptivePosition: true,
    isAnimated: true,
    containerClass: 'ui-rzbr-datepicker',
    customTodayClass: 'today',
    dateInputFormat: 'DD MMMM YYYY',
    showWeekNumbers: false
  };

  constructor(private readonly dynamicLocaleService: DynamicLocaleService) {}

  outsideClickListener: () => void;

  click(e: HTMLElement) {
    if (this.disabled) {
      this.clickOnDisabled.emit();
    } else {
      if (e.tagName.toLowerCase() === 'div') {
        this.dp.toggle();
        this.clicked.emit();
      }
    }
  }

  onChange: (data: any) => void = () => undefined;
  onTouched: () => void = () => undefined;

  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean) {
    this.disabled = isDisabled;
  }

  writeValue(value: Date) {
    this.onChange(value);
    this.valueChange.emit(value);
  }
}
