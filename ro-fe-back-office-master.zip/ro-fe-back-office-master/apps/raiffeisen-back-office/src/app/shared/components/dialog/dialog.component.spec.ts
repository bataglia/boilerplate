import { DialogService } from './dialog.service';
import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';

import { DialogComponent } from './dialog.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('DialogComponent', () => {
  let component: DialogComponent;
  let fixture: ComponentFixture<DialogComponent>;
  let dialogService: DialogService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [DialogComponent],
      providers: [DialogService],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(inject([DialogService], (ms: DialogService) => {
    fixture = TestBed.createComponent(DialogComponent);
    component = fixture.componentInstance;
    dialogService = ms;
  }));

  it('should be initialized dialog service', () => {
    expect(dialogService).toBeTruthy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the dialog if show is true', async () => {
    dialogService.open('');
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal')
    ).toBeTruthy();
  });

  it('should display the dialog backdrop if show is true', async () => {
    dialogService.open('');
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal-backdrop')
        .classList
    ).toContain('in');
  });

  it('should remove the dialog if show is false', async () => {
    dialogService.onClose(false);
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal')
    ).toBeNull();
  });

  it('should close the dialog', async () => {
    dialogService.open('');
    fixture.detectChanges();

    component.close(false);

    fixture.detectChanges();
    component.show$.subscribe((value) => {
      expect(value).toBeFalsy();
    });
  });
});
