import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { DialogService } from './dialog.service';

@Component({
  selector: 'ui-rzbr-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DialogComponent {
  @Input() closeOnBackDrop = false;

  show$ = this.dialogService.show$;

  btnCancelText$ = this.dialogService.btnCancelText$;

  text$ = this.dialogService.text$;

  btnText$ = this.dialogService.btnText$;

  constructor(private readonly dialogService: DialogService) {}

  close(value: boolean) {
    this.dialogService.onClose(value);
  }
}
