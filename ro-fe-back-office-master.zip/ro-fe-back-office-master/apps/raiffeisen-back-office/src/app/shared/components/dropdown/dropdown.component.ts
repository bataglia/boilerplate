import {
  AfterContentInit,
  ChangeDetectionStrategy,
  Component,
  ContentChildren,
  EventEmitter,
  forwardRef,
  Input,
  OnInit,
  Output,
  QueryList,
  TemplateRef
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import { SelectorDirective } from '@rf-shared/directives/selector.directive';

/* example

items = accounts
<ui-rzbr-dropdown [items]="items$ | async" [(selectedItem)]="x">
  <ng-template let-item rzbrSelector="item">
    {{item.nickname}}
    </ng-template>
    <ng-template let-item rzbrSelector="selectedItem">
    {{item.iban}}
    </ng-template>
</ui-rzbr-dropdown>

*/

@Component({
  selector: 'ui-rzbr-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      // tslint:disable-next-line: no-forward-ref
      useExisting: forwardRef(() => DropdownComponent),
      multi: true
    }
  ]
})
export class DropdownComponent
  implements OnInit, AfterContentInit, ControlValueAccessor {
  @ContentChildren(SelectorDirective) templates: QueryList<SelectorDirective>;
  @Input() dataKey = 'id';
  @Input() dataLabel = 'label';
  @Input() defaultLabel = '';
  @Input() disabled = false;
  @Input() readonly = false;
  @Input() items: any[];
  @Input() selectedItem: any;
  @Input() expanded = false;
  @Output() readonly selectedItemChange = new EventEmitter<any>();
  @Output() readonly showEvent = new EventEmitter();
  @Output() readonly hideEvent = new EventEmitter();
  itemTemplate: TemplateRef<any>;
  selectedItemTemplate: TemplateRef<any>;

  get label() {
    return this.selectedItem
      ? this.selectedItem[this.dataLabel]
      : this.defaultLabel
      ? this.defaultLabel
      : '';
  }

  constructor() {}

  outsideClickListener: () => void;

  ngOnInit() {}

  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.selector) {
        case 'item':
          this.itemTemplate = item.template;
          break;

        case 'selectedItem':
          this.selectedItemTemplate = item.template;
          break;

        default:
          this.itemTemplate = item.template;
          break;
      }
    });
  }

  onChange: (data: any) => void = () => undefined;

  onTouched: () => void = () => undefined;

  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean) {
    this.disabled = isDisabled;
  }

  writeValue(value: any) {
    if (this.disabled || this.readonly) {
      return;
    }
    this.onChange(value);
    this.selectedItemChange.emit(value);
  }

  toggle() {
    if (this.disabled || this.readonly) {
      return;
    }
    this.expanded =
      !this.items || this.items.length < 1 ? false : !this.expanded;
  }
}
