import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input, NgModule, Output,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DynamicComponentInterface, DynamicFactoryService } from './dynamic-factory.service';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'dynamic-test-component',
  template: `<div class="title">{{title}}</div>
            <div class="id">{{id}}</div>`,
  changeDetection: ChangeDetectionStrategy.OnPush
})
class DynamicTestComponent {
  @Input() title = '';
  @Input() id = '';
  @Output() readonly updateTitle = new EventEmitter();
  @Output() readonly updateId = new EventEmitter();
  emitTitle(){
    this.updateTitle.emit();
  }
  emitId(){
    this.updateId.emit();
  }
}

@Component({
  selector: 'test-component',
  template: '<ng-template #placeholder></ng-template>',
  changeDetection: ChangeDetectionStrategy.OnPush
})
class TestComponent {
  @ViewChild('placeholder', { static: true, read: ViewContainerRef })
  placeholder: ViewContainerRef;
}

@NgModule({
  imports: [CommonModule, BrowserModule],
  declarations: [DynamicTestComponent],
  entryComponents: [
    DynamicTestComponent,
  ]
})
class TestModule {}

fdescribe('DynamicFactoryComponent', () => {
  let service: DynamicFactoryService;
  let fixture: ComponentFixture<TestComponent>;
  let component: TestComponent;
  let componentElement: HTMLElement;

  let triggerEffect = '';
  let emitEffect = '';

  let dynamicComponent: DynamicComponentInterface;


  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent
      ],
      providers: [DynamicFactoryService],
      imports: [TestModule]
    }).compileComponents();

    service = TestBed.get(DynamicFactoryService);
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;

    componentElement = fixture.nativeElement as HTMLElement;

    dynamicComponent = {
      component: DynamicTestComponent,
      input: {
        title: 'Component',
        id: 'Dynamic'
      },
      output: {
        updateTitle: () => { triggerEffect = 'First' },
        updateId: () => { emitEffect = 'Second' }
      },
    };
    fixture.detectChanges();
  });

  it('should create the service', () => {
    expect(service).toBeDefined();
  });

  it('should insert dynamic component in placeholder', () => {

    service.loadComponent(dynamicComponent, component.placeholder);
    fixture.detectChanges();

    const dynamic = componentElement.getElementsByTagName('dynamic-test-component');

    expect(dynamic[0]).toBeTruthy();

  });

  //ToDo Test input and output bindings

  // it('should bind inputs to dynamic component', () => {
  //
  //   service.loadComponent(dynamicComponent, component.placeholder);
  //   fixture.detectChanges();
  //
  //   titleElement = componentElement.querySelector('.title') as HTMLElement;
  //   idElement = componentElement.querySelector('.id') as HTMLElement;
  //
  //
  //   expect(titleElement.innerText).toBe('Component');
  //   expect(idElement.innerText).toBe('Dynamic');
  //
  // });

});
