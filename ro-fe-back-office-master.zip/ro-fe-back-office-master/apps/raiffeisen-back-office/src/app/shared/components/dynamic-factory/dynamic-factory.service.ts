import {
  ComponentFactoryResolver, Injectable,
  Type,
  ViewContainerRef,
} from '@angular/core';

export interface DynamicComponentInterface {
  component: Type<any>;
  input?: {[key:string]:any};
  output?: {[key:string]:(event: any) => void};
}

@Injectable({ providedIn: 'root' })
export class DynamicFactoryService {

  constructor(private componentFactoryResolver: ComponentFactoryResolver) {}

  loadComponent(component: DynamicComponentInterface, placeholder: ViewContainerRef) {

    const componentClass = component.component;
    const componentInputs = component.input;
    const componentOutputs = component.output;

    // Create component factory from component class
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentClass);

    // Clear placeholder
    placeholder.clear();

    // Insert component in DOM and keep it in a reference
    const componentRef = placeholder.createComponent(componentFactory);

    // Use reference to bind inputs
    if(componentInputs) {
      const inputs = Object.keys(componentInputs);

      if(inputs.length) {
        inputs.forEach((key) => {
          componentRef.instance[key] = componentInputs[key];
        })
      }
    }

    // Use reference to bind outputs
    if(componentOutputs) {
      const outputs = Object.keys(componentOutputs);

      if(outputs.length) {
        outputs.forEach((key) => {
          (componentRef.instance[key]).subscribe(componentOutputs[key]);
        })
      }
    }
  }
}
