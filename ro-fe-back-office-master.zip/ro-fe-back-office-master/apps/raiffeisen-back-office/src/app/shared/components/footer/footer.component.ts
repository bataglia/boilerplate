import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { environment } from '@env/environment';
import * as fromModel from '@rf-store/utils/utils.model';

@Component({
  selector: 'ui-rzbr-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FooterComponent {
  @Input() footerGeneral: fromModel.UsefulLink;
  @Input() footerTechnical: fromModel.UsefulLink;
  @Input() footerUserGuide: fromModel.UsefulLink;
  @Input() footerTerms: fromModel.UsefulLink;

  isLive: boolean = environment.isEnv === 'live';
  cdnPath = environment.cdnPath;
  constructor() {}
}
