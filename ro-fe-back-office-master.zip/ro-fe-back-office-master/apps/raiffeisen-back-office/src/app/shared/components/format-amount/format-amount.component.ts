import { DecimalPipe } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit
} from '@angular/core';

import { CONSTANTS } from '@utils/constants';
import { DynamicLocaleService } from '@utils/dynamic-locale.service';
import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-format-amount',
  templateUrl: './format-amount.component.html',
  styleUrls: ['./format-amount.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FormatAmountComponent extends SubscribedComponent
  implements OnInit {
  @Input() currency = '';
  @Input() formatClass = '';
  @Input() decimalCount = 2;
  @Input() sign: '+' | '-' | '' = '';
  @Input() allDecimals = false;
  @Input() set amount(value: number) {
    this._amount = value;
    if (this._locale) {
      this.processAmountByLocale(this._amount, this._locale);
    }
  }

  private _amount = 0;
  private _locale: string;

  integerPart = '';
  decimalSeparator = '';
  decimals = '';

  constructor(
    private readonly dynamicLocaleService: DynamicLocaleService,
    private readonly decimalPipe: DecimalPipe
  ) {
    super();
  }

  ngOnInit(): void {
    this.registerSubscriptions(
      this.dynamicLocaleService.locale$.subscribe((locale: string) => {
        this._locale = locale;
        this.processAmountByLocale(this._amount, locale);
      })
    );
  }

  /**
   * Splits the provided amount into its 3 components
   * -> integer, separator, digits
   * @param amount
   * 1000.00
   * @param locale
   * ro/en
   */
  processAmountByLocale(amount: number, locale: string) {
    let decimalFormat = '1.2-2';

    if (this.allDecimals) {
      decimalFormat = '1.2-9';
    }

    const localeSeparators = CONSTANTS.LOCALE[locale.toUpperCase()];
    const parsedAmount: string =
      this.decimalPipe.transform(amount, decimalFormat, locale) || '';
    const amountPieces = parsedAmount.split(localeSeparators.DECIMAL_SEPARATOR);

    this.integerPart = amountPieces[0];
    this.decimalSeparator = localeSeparators.DECIMAL_SEPARATOR;
    this.decimals = amountPieces[1];
  }
}
