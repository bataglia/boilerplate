import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedModule } from '@rf-shared/shared.module';

import { GroupItemComponent } from './group-item.component';

describe('GroupItemComponent', () => {
  let component: GroupItemComponent;
  let fixture: ComponentFixture<GroupItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit changeEvent', () => {
    spyOn(component['selectedChange'], 'emit');

    component.select([]);

    expect(component['selectedChange'].emit).toHaveBeenCalled();
  });
});
