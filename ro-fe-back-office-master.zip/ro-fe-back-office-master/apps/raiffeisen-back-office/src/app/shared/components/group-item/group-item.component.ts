import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

@Component({
  selector: 'ui-rzbr-group-item',
  templateUrl: './group-item.component.html',
  styleUrls: ['./group-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GroupItemComponent {
  @Input() title = '';
  @Input() searchKey = '';
  @Input() titleKey = '';
  @Input() subtitleKey = '';
  @Input() subtitle: string;
  @Input() rightDetailKey = '';
  @Input() idKey = '';
  @Input() toggleShow = false;
  @Input() showTitle = true;
  @Input() items: any[] = [];
  @Input() set selected(items: any[]) {
    this._selected = items;
    if (this._selected) {
      this.selectedIds = this._selected.map((x) => this.getIdKeyValue(x));
    }
  }
  get selected() {
    return this._selected;
  }
  @Output() readonly selectedChange = new EventEmitter();

  private _selected: any[] = [];
  selectedIds: any[] = [];
  expanded = true;
  constructor() {}

  getIdKeyValue(item: any) {
    return this.idKey === '' ? item : item[this.idKey];
  }

  isChecked(item: any = null) {
    if (item === null) {
      if (
        !this.items ||
        this.items.length === 0 ||
        !this.selected ||
        this.selected.length === 0
      ) {
        return false;
      }

      return this.items.every((x) => this.selectedIds.includes(this.getIdKeyValue(x)));
    }

    return this.selectedIds.some((x) => x === this.getIdKeyValue(item));
  }

  itemClick() {
    if (this.toggleShow) {
      this.expanded = !this.expanded;
    } else {
      this.toggleSelected();
    }
  }

  toggleSelected(item: any = null) {
    if (this.isChecked(item)) {
      if (item === null) {
        this.select(this.selected.filter((x) => !this.items.some(y => this.getIdKeyValue(y) === this.getIdKeyValue(x))));
      } else {
        this.select(
          this.selected.filter((x) => this.getIdKeyValue(x) !== this.getIdKeyValue(item))
        );
      }
    } else {
      if (item === null) {
        const selected = [...this.items];

        this.selected.forEach((s) => {
          if (!selected.some((x) => this.getIdKeyValue(x) === this.getIdKeyValue(s))) {
            selected.push(s);
          }
        });
        this.select(selected);
      } else {
        this.select([...this.selected, item]);
      }
    }
  }

  select(items: any[]) {
    this.selectedChange.emit(items || this.items || []);
  }
}
