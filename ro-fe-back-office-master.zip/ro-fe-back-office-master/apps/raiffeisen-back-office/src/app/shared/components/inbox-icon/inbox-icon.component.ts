import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';

import { filter, map, tap, withLatestFrom } from 'rxjs/operators';

import { AuthFacade } from '@rf-store/auth/auth.facade';
import { InboxFacade } from '@rf-store/inbox/inbox.facade';

import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-inbox-icon',
  templateUrl: './inbox-icon.component.html',
  styleUrls: ['./inbox-icon.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InboxIconComponent extends SubscribedComponent implements OnInit {
  constructor(
    private readonly inboxFacade: InboxFacade,
    private readonly router: Router,
    private readonly authFacade: AuthFacade
  ) {
    super();
  }

  totalCount$ = this.inboxFacade.total$;

  ngOnInit(): void {
    this.inboxFacade.getTotal();
    this.registerSubscriptions(
      this.router.events
        .pipe(
          filter((event) => event instanceof NavigationStart),
          map((event) => event as NavigationStart),
          tap((route: NavigationStart) => {
            if (!route.url.includes('inbox')) {
              this.inboxFacade.resetStore();
            }
          }),
          withLatestFrom(this.authFacade.isLoggedIn$),
          map(([_, isLoggedId]) => isLoggedId)
        )
        .subscribe((isLoggedId) => {
          if (isLoggedId) {
            this.inboxFacade.getTotal();
          }
        })
    );
  }
}
