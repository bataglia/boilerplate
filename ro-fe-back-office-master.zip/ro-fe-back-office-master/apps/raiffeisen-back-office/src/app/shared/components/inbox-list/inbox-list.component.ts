import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';

import { Subscription } from 'rxjs';

import * as moment from 'moment';

import { InboxFacade } from '@rf-store/inbox/inbox.facade';
import { UtilsFacade } from '@rf-store/utils/utils.facade';
import { SubscribedComponent } from '@utils/subscribed-component';
import { Message } from '@rf-store/inbox/inbox.model';
import { DynamicLocaleService } from '@utils/dynamic-locale.service';
import { map, withLatestFrom } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'ui-rzbr-inbox-list',
  templateUrl: './inbox-list.component.html',
  styleUrls: ['./inbox-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InboxListComponent implements OnInit {
  private STATUS = 'NEW';
  pagedResponse$ = this.inboxFacade.pagedResponse$;
  systemDate$ = this.utilsFacade.systemDate$;
  loading$ = this.inboxFacade.loading$;
  noMoreMessagesLabel$ = this.inboxFacade.pagedResponseNoMoreMessagesLabel$;
  isCurrentMonth$ = this.utilsFacade.isCurrentMonth$;
  isCurrentYear$ = this.utilsFacade.isCurrentYear$;

  constructor(
    private readonly dynamicLocaleService: DynamicLocaleService,
    private readonly inboxFacade: InboxFacade,
    private readonly utilsFacade: UtilsFacade,
    private readonly router: Router,
    private readonly route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.inboxFacade.getMessages();
  }

  loadMoreMessages() {
    this.inboxFacade.getMessages();
  }

  showMonth$(date: string) {
    return this.dynamicLocaleService.locale$.pipe(
      withLatestFrom(this.isCurrentYear$),
      map(([locale, isCurrentYear]) => {
        return isCurrentYear(date)
          ? this.getFormatedMonth(date, locale)
          : this.getFormatedMonthAndYear(date, locale);
      })
    );
  }

  showContent(id: number): void {
    this.router.navigate(['message', id], { relativeTo: this.route });
  }

  getFormatedMonthAndYear(date: string, locale: string) {
    return moment(date)
      .locale(locale)
      .format('MMMM YYYY');
  }

  getFormatedMonth(date: string, locale: string) {
    return moment(date)
      .locale(locale)
      .format('MMMM');
  }

  trackByFn(index: number, item: Message) {
    return item.id;
  }
}
