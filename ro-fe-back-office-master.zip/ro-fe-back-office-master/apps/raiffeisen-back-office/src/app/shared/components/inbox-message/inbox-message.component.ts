import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Observable } from 'rxjs';
import { map, pluck, switchMap } from 'rxjs/operators';

import { InboxFacade } from '@rf-store/inbox/inbox.facade';
import * as fromModel from '@rf-store/inbox/inbox.model';

@Component({
  selector: 'ui-rzbr-inbox-message',
  templateUrl: './inbox-message.component.html',
  styleUrls: ['./inbox-message.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InboxMessageComponent implements OnInit {
  message$: Observable<fromModel.Message | null>;

  constructor(
    private readonly inboxFacade: InboxFacade,
    private readonly router: Router,
    private readonly route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.message$ = this.route.params.pipe(
      pluck('id'),
      map(Number),
      switchMap((id: number) => {
        this.inboxFacade.getMessageWithId(id);

        return this.inboxFacade.pagedResponseMesageWithId(id);
      })
    );
  }

  goBack() {
    this.router.navigate(['inbox']);
  }

  downloadAttachment(id: number) {
    this.inboxFacade.downloadMessageWithId(id);
  }
}
