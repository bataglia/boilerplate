import {
  AfterViewChecked,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  PipeTransform,
  QueryList,
  ViewChildren
} from '@angular/core';
import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InputComponent extends SubscribedComponent implements AfterViewChecked {
  @Input() button?: string;
  @Input() errorMsg?: string;
  @Input() infoMsg?: string;
  @Input() warningMsg?: string;
  @Input() maxlength?: number;
  @Input() pattern?: string;
  @Input() pipe?: PipeTransform;
  @Input() placeholderPrimary?: string;
  @Input() placeholderSecondary?: string;
  @Input() type = 'text';
  @Input() iconLeft?: string;
  @Input() iconRight?: string;
  @Input() separatorLeft?: boolean;
  @Input() separatorRight?: boolean;
  @Input() disabled?: boolean;

  @ViewChildren('input') input:QueryList<ElementRef>;

  inputValue = '';
  error = false;
  showInput = true;
  content = 'This is a tooltip';

  constructor() {
    super();
  }

  ngAfterViewChecked(){
    this.registerSubscriptions(this.input.changes.subscribe(() => {
      this.setFocus();
    }));
  }

  activateInput() {
    this.showInput = true;
    this.error = false;
  }

  setFocus() {
    if (this.input.length > 0) {
      this.input.first.nativeElement.focus();
    }
  }

  inputBlur(){
    if(this.inputValue.length){
      this.showInput = false;
    }
    if (this.input.length > 0){
      this.error = this.input.first.nativeElement.error;
    }
  }
}
