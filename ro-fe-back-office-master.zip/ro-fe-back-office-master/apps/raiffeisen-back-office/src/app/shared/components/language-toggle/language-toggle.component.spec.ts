import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';

import { HttpLoaderFactory } from '../../../app.module';
import { RzbrComponentsModule } from '../components.module';
import { LanguageToggleComponent } from './language-toggle.component';

describe('LanguageToggle: ', () => {
  let fixture: ComponentFixture<LanguageToggleComponent>;
  let comp: LanguageToggleComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClientTestingModule]
          }
        }),
        RzbrComponentsModule
      ],
      providers: [HttpClientTestingModule]
    });
    fixture = TestBed.createComponent(LanguageToggleComponent);
  }));

  it('should get the active language from storage on init', async () => {
    comp = fixture.componentInstance;
    comp.activeLanguage$.subscribe((value) => {
      expect(value).not.toBeNull();
    });
  });
});
