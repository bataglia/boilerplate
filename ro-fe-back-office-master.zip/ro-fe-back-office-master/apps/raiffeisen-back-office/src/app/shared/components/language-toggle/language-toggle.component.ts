import { ChangeDetectionStrategy, Component } from '@angular/core';
import { DynamicLocaleService } from '@utils/dynamic-locale.service';

@Component({
  selector: 'ui-rzbr-language-toggle',
  templateUrl: './language-toggle.component.html',
  styleUrls: ['./language-toggle.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LanguageToggleComponent {
  languages = this.dynamicLocaleService.languages;
  activeLanguage$ = this.dynamicLocaleService.locale$;

  constructor(private readonly dynamicLocaleService: DynamicLocaleService) {}

  changeLanguage(lang: string) {
    this.dynamicLocaleService.setLocale(lang);
  }
}
