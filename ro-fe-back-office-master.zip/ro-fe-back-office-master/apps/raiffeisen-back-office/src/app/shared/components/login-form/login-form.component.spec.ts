import { PreloaderComponent } from './../preloader/preloader.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginFormComponent } from './login-form.component';
import { LanguageToggleComponent } from '../language-toggle/language-toggle.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('LoginFormComponent: ', () => {
  let fixture: ComponentFixture<LoginFormComponent>;
  let comp: LoginFormComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        LoginFormComponent,
        LanguageToggleComponent,
        PreloaderComponent
      ],
      imports: [TranslateModule.forRoot(), FormsModule, ReactiveFormsModule],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginFormComponent);
    comp = fixture.componentInstance;
  });

  it('should instantiate the component', async () => {
    expect(comp).toBeTruthy();
  });

  it('should display the loader if loading is true', async () => {
    comp.loading = true;
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('ui-rzbr-preloader')
    ).toBeTruthy();
  });

  it('should remove the loader if loading is false', async () => {
    comp.loading = false;
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('ui-rzbr-preloader')
    ).not.toBeNull();
  });

  it('formGroup should be invalid if empty', async () => {
    expect(comp.loginForm.invalid).toEqual(true);
  });

  it('userName field required', async () => {
    const name = comp.loginForm.controls['username'];
    expect(name.valid).toBeFalsy();

    name.setValue('');
    expect(name.hasError('required')).toBeTruthy();
  });

  it('userName field maxLength', async () => {
    const name = comp.loginForm.controls['username'];
    expect(name.valid).toBeFalsy();

    name.setValue('123456789012345678901234567890123456789012345678900'); //51 chars
    expect(name.hasError('maxlength')).toBeTruthy();
  });

  it('password field required', async () => {
    const pass = comp.loginForm.controls['password'];
    expect(pass.valid).toBeFalsy();

    pass.setValue('');
    expect(pass.hasError('required')).toBeTruthy();
  });

  it('password field maxLength', async () => {
    const pass = comp.loginForm.controls['password'];
    expect(pass.valid).toBeFalsy();

    pass.setValue('123456789012345678900'); //21 chars
    expect(pass.hasError('maxlength')).toBeTruthy();
  });

  it('submit btn should be enabled if form is valid, loading is false and error is empty', async () => {
    comp.loading = false;
    comp.error = '';
    comp.loginForm.controls['username'].setValue('1');
    comp.loginForm.controls['password'].setValue('1');
    expect(
      fixture.nativeElement.querySelector('ui-rzbr-buttons').disabled
    ).toBeFalsy();
  });
});
