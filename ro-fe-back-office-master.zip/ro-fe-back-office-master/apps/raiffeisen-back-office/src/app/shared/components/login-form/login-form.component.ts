import { DOCUMENT } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Inject,
  Input,
  Output
} from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';

import { APP_VERSION } from '@version';

@Component({
  selector: 'ui-rzbr-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginFormComponent {
  @Input() loading: boolean;

  @Input() error: string;

  @Output() private readonly submits: EventEmitter<{
    username: string;
    password: string;
  }> = new EventEmitter();

  @Output() private readonly errorChange: EventEmitter<
    string
  > = new EventEmitter();

  revealPassword = false;

  minUsername = 1;
  maxUsername = 50;
  minPassword = 1;
  maxPassword = 20;

  appVersion = APP_VERSION;

  loginForm: FormGroup = new FormGroup({
    username: new FormControl('', [
      Validators.required,
      Validators.minLength(this.minUsername),
      Validators.maxLength(this.maxUsername)
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(this.minPassword),
      Validators.maxLength(this.maxPassword)
    ])
  });

  constructor(@Inject(DOCUMENT) private readonly document: Document) {}

  emitSubmit() {
    const { username, password } = this.loginForm.value;

    this.submits.emit({ username, password });
  }

  onEnter(event: KeyboardEvent, form: NgForm) {
    if (
      form.invalid ||
      this.loading ||
      this.error !== '' ||
      event.key !== 'Enter'
    ) {
      return;
    }
    if (this.document.activeElement) {
      (this.document.activeElement as HTMLElement).blur();
    }
    this.emitSubmit();
  }

  toggleFocus(e: Element) {
    e.classList.toggle('focus');
    if (this.error !== '') {
      this.errorChange.emit('');
    }
  }
}
