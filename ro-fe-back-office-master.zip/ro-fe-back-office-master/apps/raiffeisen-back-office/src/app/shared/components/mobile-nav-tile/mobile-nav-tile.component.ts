import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'ui-rzbr-mobile-nav-tile',
  templateUrl: './mobile-nav-tile.component.html',
  styleUrls: ['./mobile-nav-tile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MobileNavTileComponent {
  @Input() label: string;
  @Input() background: string;
  @Input() image: string;
  @Input() icon: string;
}
