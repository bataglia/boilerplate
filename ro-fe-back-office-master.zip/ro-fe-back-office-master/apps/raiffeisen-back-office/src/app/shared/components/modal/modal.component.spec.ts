import { ModalService } from './modal.service';
import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';

import { ModalComponent } from './modal.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ModalComponent', () => {
  let component: ModalComponent;
  let fixture: ComponentFixture<ModalComponent>;
  let modalService: ModalService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [ModalComponent],
      providers: [ModalService],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(inject([ModalService], (ms: ModalService) => {
    fixture = TestBed.createComponent(ModalComponent);
    component = fixture.componentInstance;
    modalService = ms;
  }));

  it('should be initialized modal service', () => {
    expect(modalService).toBeTruthy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the modal if show is true', async () => {
    modalService.open('');
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal')
    ).toBeTruthy();
  });

  it('should display the modal backdrop if show is true', async () => {
    modalService.open('');
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal-backdrop')
        .classList
    ).toContain('in');
  });

  it('should remove the modal if show is false', async () => {
    modalService.onClose(false);
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal')
    ).toBeNull();
  });

  it('should close the modal when the button is clicked', async () => {
    modalService.open('');
    fixture.detectChanges();
    component.close(false);
    fixture.detectChanges();
    component.show$.subscribe((value) => {
      expect(value).toBeFalsy();
    });
  });
});
