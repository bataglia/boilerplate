import { ChangeDetectionStrategy, Component } from '@angular/core';
import { ModalService } from './modal.service';

@Component({
  selector: 'ui-rzbr-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ModalComponent {
  closeOnBackDrop = this.modalService.closeOnBackdrop;

  show$ = this.modalService.show$;

  text$ = this.modalService.text$;

  btnText$ = this.modalService.btnText$;

  constructor(private readonly modalService: ModalService) {}

  close(value: boolean) {
    if (value) {
      this.modalService.onClose(value);
    }
  }
}
