import { ModalService } from './modal.service';
import { TestBed, getTestBed, inject } from '@angular/core/testing';
import { combineLatest } from 'rxjs';
import { DOCUMENT } from '@angular/common';

describe('ModalService', () => {
  let injector: TestBed;
  let service: ModalService;
  let document: Document;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ModalService]
    });

    injector = getTestBed();
    service = injector.get(ModalService);
  });

  beforeEach(inject([DOCUMENT], (doc: Document) => {
    document = doc;
  }));

  it('should open modal', async () => {
    service.open('test');
    combineLatest(service.show$, service.text$, service.btnText$).subscribe(
      ([show, text, btnText]) => {
        expect(show).toBeTruthy();
        expect(text).toEqual('test');
        expect(btnText).toEqual('general__actions__ok');
        expect(document.body.classList).toContain('modal-open');
      }
    );
  });

  it('should set show & action false', async () => {
    service.onClose(false);

    combineLatest([service.show$, service.action$]).subscribe(
      ([show, action]) => {
        expect(show).toBeFalsy();
        expect(action).toBeFalsy();
        expect(document.body.classList).not.toContain('modal-open');
      }
    );
  });
});
