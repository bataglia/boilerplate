import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs';

/**
 * Usage:
 *
 * declare subscription variable
 *
 * subscription:Subscription;
 *
 * inject service into component/service ...
 *
 * constructor(private readonly: modalService:ModalService){}
 *
 * usage
 *
 * @param text label from translate files ro.json/en/json
 * @param btnText label from translate, default = 'general__actions__ok'
 * this.subscription = modalService.open('user__labels__logout__confirm_message')
 *    .subscribe(ok =>{
 *
 *        if(ok){
 *            // do ok stuff
 *        }
 *
 *        if(ok !== null){
 *            this.subscription.unsubscribe();
 *        }
 *    })
 */

@Injectable()
export class ModalService {
  private readonly showSubject$ = new BehaviorSubject<boolean>(false);

  private readonly textSubject$ = new BehaviorSubject<string>('');

  private readonly btnTextSubject$ = new BehaviorSubject<string>('');

  private readonly actionSubject$ = new BehaviorSubject<boolean | null>(null);

  private readonly closeOnBackdropSubject$ = new BehaviorSubject<boolean>(
    false
  );

  get action$() {
    return this.actionSubject$.asObservable();
  }

  get show$() {
    return this.showSubject$.asObservable();
  }

  get text$() {
    return this.textSubject$.asObservable();
  }

  get btnText$() {
    return this.btnTextSubject$.asObservable();
  }

  get closeOnBackdrop$() {
    return this.closeOnBackdropSubject$.asObservable();
  }

  get closeOnBackdrop() {
    return this.closeOnBackdropSubject$.value;
  }

  constructor(@Inject(DOCUMENT) private readonly document: Document) {}

  open(
    text: string,
    btnText = 'general__actions__ok',
    closeOnBackdrop = false
  ) {
    this.actionSubject$.next(null);
    this.showSubject$.next(true);
    this.textSubject$.next(text);
    this.btnTextSubject$.next(btnText);
    this.closeOnBackdropSubject$.next(closeOnBackdrop);
    this.document.body.classList.add('modal-open');

    return this.action$;
  }

  onClose(value: boolean) {
    this.actionSubject$.next(value);
    this.showSubject$.next(false);
    this.document.body.classList.remove('modal-open');
  }
}
