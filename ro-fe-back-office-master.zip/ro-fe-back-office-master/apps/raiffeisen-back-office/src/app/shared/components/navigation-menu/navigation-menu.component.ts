import { ChangeDetectionStrategy, Component, OnInit, Input } from '@angular/core';
import { getRoutes, Navigation } from '@utils/navigation-routes';

import { FEATURE_TOGGLE } from '@utils/feature-toggle';

@Component({
  selector: 'ui-rzbr-navigation-menu',
  templateUrl: './navigation-menu.component.html',
  styleUrls: ['./navigation-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RzbrNavigationMenuComponent implements OnInit {
  @Input() headerHeight: number;

  routes: Navigation[] = [];

  isMobileMenuExpanded = false;

  ngOnInit() {
    this.routes = getRoutes();
  }

  toggleMobileMenu() {
    this.isMobileMenuExpanded = !this.isMobileMenuExpanded;
  }

  getFeature(item: Navigation): boolean {
    return item.feature
      ? FEATURE_TOGGLE[item.feature]
        ? FEATURE_TOGGLE[item.feature]
        : false
      : false;
  }
}
