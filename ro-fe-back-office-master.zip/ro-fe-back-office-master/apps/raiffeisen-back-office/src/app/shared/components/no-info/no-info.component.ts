import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'ui-rzbr-no-info',
  templateUrl: './no-info.component.html',
  styleUrls: ['./no-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NoInfoComponent {
  @Input() message?: string;
  @Input() messageBold?: string;
  @Input() highlighted?: boolean;
}
