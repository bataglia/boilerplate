import { ChangeDetectionStrategy, Component } from '@angular/core';

import { PaymentsFacade } from '@rf-store/payments/payments.facade';

import { DynamicLocaleService } from '@utils/dynamic-locale.service';

@Component({
  selector: 'ui-rzbr-payment-details',
  templateUrl: './payment-details.component.html',
  styleUrls: ['./payment-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentDetailsComponent {
  selectedFromAccount$ = this.paymentsFacade.selectedFromAccount$;

  selectedToAccount$ = this.paymentsFacade.selectedToAccount$;

  postFormBasicPaymentDate$ = this.paymentsFacade.postFormBasicPaymentDate$;

  locale$ = this.dynamicLocaleService.locale$;

  constructor(
    private readonly paymentsFacade: PaymentsFacade,
    private readonly dynamicLocaleService: DynamicLocaleService
  ) {}
}
