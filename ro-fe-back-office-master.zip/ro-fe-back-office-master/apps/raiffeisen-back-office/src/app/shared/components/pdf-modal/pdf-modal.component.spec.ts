import {
  async,
  ComponentFixture,
  TestBed,
  inject
} from '@angular/core/testing';

import { PdfModalComponent } from './pdf-modal.component';
import { PDFModalService } from './pdf-modal.service';
import { SafePipe } from '@rf-shared/pipes/safe.pipe';
import { TranslateModule } from '@ngx-translate/core';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('PdfModalComponent', () => {
  let component: PdfModalComponent;
  let fixture: ComponentFixture<PdfModalComponent>;
  let modalService: PDFModalService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PdfModalComponent, SafePipe],
      providers: [PDFModalService],
      imports: [TranslateModule.forRoot()],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(inject([PDFModalService], (ms: PDFModalService) => {
    fixture = TestBed.createComponent(PdfModalComponent);
    component = fixture.componentInstance;
    modalService = ms;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the modal if show is true', async () => {
    modalService.open('');
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal')
    ).toBeTruthy();
  });

  it('should display the modal backdrop if show is true', async () => {
    modalService.open('');
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal-backdrop')
        .classList
    ).toContain('in');
  });

  it('should remove the modal if show is false', async () => {
    modalService.onClose();
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.modal')
    ).toBeNull();
  });

  it('should close the modal when the button is clicked', async () => {
    modalService.open('');
    fixture.detectChanges();
    component.close();
    fixture.detectChanges();
    component.show$.subscribe((value) => {
      expect(value).toBeFalsy();
    });
  });
});
