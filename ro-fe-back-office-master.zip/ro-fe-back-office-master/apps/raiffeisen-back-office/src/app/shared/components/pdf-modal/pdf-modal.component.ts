import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { PDFModalService } from './pdf-modal.service';

@Component({
  selector: 'ui-rzbr-pdf-modal',
  templateUrl: './pdf-modal.component.html',
  styleUrls: ['./pdf-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PdfModalComponent {
  @Input() closeOnBackDrop = false;

  show$ = this.pdfService.show$;

  btnText$ = this.pdfService.btnText$;

  pdf$ = this.pdfService.pdfStringURL$;

  constructor(private readonly pdfService: PDFModalService) {}

  close() {
    this.pdfService.onClose();
  }
}
