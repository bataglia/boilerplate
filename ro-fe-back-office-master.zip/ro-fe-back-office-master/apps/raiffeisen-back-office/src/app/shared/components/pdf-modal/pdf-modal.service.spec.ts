import { PDFModalService } from './pdf-modal.service';
import { TestBed, getTestBed, inject } from '@angular/core/testing';
import { combineLatest } from 'rxjs';
import { DOCUMENT } from '@angular/common';

describe('PdfModalService', () => {
  let injector: TestBed;
  let service: PDFModalService;
  let document: Document;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PDFModalService]
    });

    injector = getTestBed();
    service = injector.get(PDFModalService);
  });

  beforeEach(inject([DOCUMENT], (doc: Document) => {
    document = doc;
  }));

  it('should open modal', async () => {
    service.open('', 'Ok');
    combineLatest(
      service.show$,
      service.btnText$,
      service.pdfStringURL$
    ).subscribe((value) => {
      expect(value[0]).toBeTruthy();
      expect(value[1]).toEqual('Ok');
      expect(value[2]).toEqual('');
      expect(document.body.classList).toContain('modal-open');
    });
  });

  it('should set show false', async () => {
    service.onClose();

    service.show$.subscribe((value) => {
      expect(value).toBeFalsy();
      expect(document.body.classList).not.toContain('modal-open');
    });
  });
});
