import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class PDFModalService {
  private readonly showSubject$ = new BehaviorSubject<boolean>(false);

  private readonly btnTextSubject$ = new BehaviorSubject<string>('');

  private readonly pdfObjectString = new BehaviorSubject<string>('');

  get show$() {
    return this.showSubject$.asObservable();
  }

  get btnText$() {
    return this.btnTextSubject$.asObservable();
  }

  get pdfStringURL$() {
    return this.pdfObjectString.asObservable();
  }

  constructor(@Inject(DOCUMENT) private readonly document: Document) {}

  open(pdf: File | Blob | string, btnText = 'general__actions__ok') {
    this.showSubject$.next(true);
    this.pdfObjectString.next((typeof pdf === 'string' || pdf instanceof String
      ? pdf
      : URL.createObjectURL(pdf)) as string);
    this.btnTextSubject$.next(btnText);
    this.document.body.classList.add('modal-open');
  }

  onClose() {
    this.showSubject$.next(false);
    this.pdfObjectString.subscribe((value) => {
      if (value) {
        URL.revokeObjectURL(value);
      }
    });
    this.document.body.classList.remove('modal-open');
  }
}
