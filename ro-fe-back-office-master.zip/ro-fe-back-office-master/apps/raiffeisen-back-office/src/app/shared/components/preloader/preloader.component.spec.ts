import { DOCUMENT } from '@angular/common';
import {
  async,
  ComponentFixture,
  inject,
  TestBed
} from '@angular/core/testing';
import { PreloaderComponent } from './preloader.component';

describe('PreloaderComponent: ', () => {
  let fixture: ComponentFixture<PreloaderComponent>;
  let comp: PreloaderComponent;
  let document: Document;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PreloaderComponent],
      providers: []
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreloaderComponent);
    comp = fixture.componentInstance;
  });

  beforeEach(inject([DOCUMENT], (doc: Document) => {
    document = doc;
  }));

  it('should instantiate the component', async () => {
    expect(comp).toBeTruthy();
  });

  it('should display the loader if showLoader is true', async () => {
    comp.showLoader = true;
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.preloader-container')
    ).toBeTruthy();
    expect(document.body.classList).toContain('modal-open');
  });

  it('should remove the loader if showLoader is false', async () => {
    comp.showLoader = false;
    fixture.detectChanges();
    expect(
      fixture.debugElement.nativeElement.querySelector('.preloader-container')
    ).toBeNull();
    expect(document.body.classList).not.toContain('modal-open');
  });
});
