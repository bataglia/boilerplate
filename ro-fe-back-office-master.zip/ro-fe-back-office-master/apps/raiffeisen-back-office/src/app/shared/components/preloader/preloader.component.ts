import { DOCUMENT } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  Inject,
  Input,
  OnChanges
} from '@angular/core';

@Component({
  selector: 'ui-rzbr-preloader',
  templateUrl: './preloader.component.html',
  styleUrls: ['./preloader.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PreloaderComponent implements OnChanges {
  @Input() noBackground = false;
  @Input() fullPage = true;
  @Input() set showLoader(value: boolean) {
    this._showLoader = value;
  }
  get showLoader() {
    return this._showLoader;
  }
  private _showLoader: boolean;
  constructor(
    @Inject(DOCUMENT) private readonly document: Document
  ) {}

  ngOnChanges() {
    // if (this.showLoader) {
    //   this.document.body.classList.add('modal-open');
    // } else {
    //   this.document.body.classList.remove('modal-open');
    // }
  }
}
