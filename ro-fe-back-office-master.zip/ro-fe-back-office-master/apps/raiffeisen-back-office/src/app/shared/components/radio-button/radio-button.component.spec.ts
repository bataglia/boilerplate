import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RadioButtonComponent } from './radio-button.component';

describe('RadioButtonComponent', () => {
  let component: RadioButtonComponent;
  let fixture: ComponentFixture<RadioButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RadioButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RadioButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit clickEvent', () => {
    spyOn(component['checkedChange'], 'emit');

    component.click();

    expect(component['checkedChange'].emit).toHaveBeenCalled();
  });

  it('should emit event when disabled', () => {
    spyOn(component['clickOnDisabled'], 'emit');
    component.disabled = true;
    component.click();

    expect(component['clickOnDisabled'].emit).toHaveBeenCalled();
  });
});
