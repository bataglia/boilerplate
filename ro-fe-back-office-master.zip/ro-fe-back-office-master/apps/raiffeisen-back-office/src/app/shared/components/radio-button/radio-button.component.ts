import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

@Component({
  selector: 'ui-rzbr-radio-button',
  templateUrl: './radio-button.component.html',
  styleUrls: ['./radio-button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RadioButtonComponent {
  @Input() name = '';
  @Input() checked = false;
  @Input() disabled = false;

  @Output() readonly checkedChange = new EventEmitter();
  @Output() readonly clickOnDisabled = new EventEmitter();

  constructor() {}

  click() {
    if (this.disabled) {
      this.clickOnDisabled.emit();
    } else {
      this.checkedChange.emit();
    }
  }
}
