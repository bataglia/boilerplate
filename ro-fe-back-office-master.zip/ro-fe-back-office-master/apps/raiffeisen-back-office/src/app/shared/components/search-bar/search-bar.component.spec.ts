import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBarComponent } from './search-bar.component';

describe('SearchBarComponent', () => {
  let component: SearchBarComponent;
  let fixture: ComponentFixture<SearchBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SearchBarComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit a value', () => {
    spyOn(component['keyChange'], 'emit');

    component.emit('test');

    expect(component['keyChange'].emit).toHaveBeenCalled();
  });

  it('should emit on clear', () => {
    spyOn(component['keyChange'], 'emit');

    component.clear();

    expect(component['keyChange'].emit).toHaveBeenCalled();
  });
});
