import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

@Component({
  selector: 'ui-rzbr-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchBarComponent {
  @Input() placeholder = '';
  @Input() key = '';
  @Input() type: 'text' | 'number' = 'text';
  @Input() private readonly min = 0;

  @Output() private readonly keyChange: EventEmitter<
    string | number
  > = new EventEmitter();

  emit(value: string | number) {
    if (value !== undefined) {
      if (typeof value === 'string') {
        if (value.length >= this.min || value.length === 0) {
          this.keyChange.emit(value);
        }
      } else if (typeof value === 'number') {
        if (value >= this.min) {
          this.keyChange.emit(value);
        }
      }
    }
  }

  clear() {
    this.emit(this.type === 'text' ? '' : 0);
  }
}
