import { ChangeDetectionStrategy, Component } from '@angular/core';
import { ToasterService } from './toaster.service';

@Component({
  selector: 'ui-rzbr-toaster',
  templateUrl: './toaster.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RzbrToasterComponent {
  alert$ = this.toasterService.alert$;

  constructor(readonly toasterService: ToasterService) {}
}
