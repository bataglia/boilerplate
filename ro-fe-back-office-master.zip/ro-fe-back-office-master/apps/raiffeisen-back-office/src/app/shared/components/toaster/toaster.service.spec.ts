// import { TestBed, getTestBed } from '@angular/core/testing';
// import { ToasterService } from './toaster.service';
// import { map } from 'rxjs/operators';
// import { AlertType } from '@rf-shared/interfaces/alert';

// describe('ToasterService', () => {
//   let injector: TestBed;
//   let service: ToasterService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [ToasterService]
//     });

//     injector = getTestBed();
//     service = injector.get(ToasterService);
//   });

//   it('should display success alert', async () => {
//     service.success('test');

//     service.alerts
//       .pipe(
//         map((x) =>
//           x.filter((z) => z.type === AlertType.SUCCESS).map((y) => y.message)
//         )
//       )
//       .subscribe((value) => {
//         expect(value).toContain('test');
//       });
//   });

//   it('should display error alert', async () => {
//     service.error('test');

//     service.alerts
//       .pipe(
//         map((x) =>
//           x.filter((z) => z.type === AlertType.ERROR).map((y) => y.message)
//         )
//       )
//       .subscribe((value) => {
//         expect(value).toContain('test');
//       });
//   });

//   it('should display info alert', async () => {
//     service.info('test');

//     service.alerts
//       .pipe(
//         map((x) =>
//           x.filter((z) => z.type === AlertType.INFO).map((y) => y.message)
//         )
//       )
//       .subscribe((value) => {
//         expect(value).toContain('test');
//       });
//   });

//   it('should display warning alert', async () => {
//     service.warn('test');

//     service.alerts
//       .pipe(
//         map((x) =>
//           x.filter((z) => z.type === AlertType.WARN).map((y) => y.message)
//         )
//       )
//       .subscribe((value) => {
//         expect(value).toContain('test');
//       });
//   });

//   it('should clear all alerts', async () => {
//     service.clear();

//     service.alerts.subscribe((value) => {
//       expect(value.length).toEqual(0);
//     });
//   });
// });
