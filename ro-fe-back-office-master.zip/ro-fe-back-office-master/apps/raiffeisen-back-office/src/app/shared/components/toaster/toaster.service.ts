import { Injectable } from '@angular/core';

import { BehaviorSubject, interval, Observable } from 'rxjs';
import { v4 as uuid } from 'uuid';

import { Alert, AlertType } from '@rf-shared/interfaces/alert';
import { SubscribedComponent } from '@utils/subscribed-component';
import { map, withLatestFrom } from 'rxjs/operators';

import * as moment from 'moment';

@Injectable({ providedIn: 'root' })
export class ToasterService extends SubscribedComponent {
  private readonly queueSubject$ = new BehaviorSubject<Alert[]>([]);

  private readonly alertSubject$ = new BehaviorSubject<Alert | null>(null);

  get queue$(): Observable<Alert[]> {
    return this.queueSubject$.asObservable();
  }

  get queue() {
    return this.queueSubject$.value;
  }

  get alert$() {
    return this.alertSubject$.asObservable();
  }

  get alert(): Alert | null {
    return this.alertSubject$.value;
  }

  defaultTimeout = 5;

  constructor() {
    super();
    this.registerSubscriptions(this.startQueue().subscribe());
  }

  startQueue() {
    return interval(1000).pipe(
      withLatestFrom(this.queue$, this.alert$),
      map(([_, queue, activeAlert]) => ({ queue, activeAlert })),
      map((val) => {
        let dismissed = false;

        if (val.activeAlert !== null) {
          if (val.activeAlert.timeout < moment().unix()) {
            dismissed = true;
            this.dismiss(true);
          }
        }

        if (val.queue.length > 0 && (val.activeAlert === null || dismissed)) {
          const alert = val.queue.splice(0, 1);

          const newAlert = alert.length > 0 ? alert[0] : null;

          if (newAlert) {
            newAlert.timeout = newAlert.timeout + moment().unix();
          }

          this.alertSubject$.next(newAlert);
          this.queueSubject$.next(val.queue);
        }
      })
    );
  }

  checkQueue() {
    const queue = this.queue;

    if (queue.length > 0) {
      const alert = queue.splice(0, 1)[0];

      alert.timeout = alert.timeout + moment().unix();
      this.alertSubject$.next(alert);
      this.queueSubject$.next(queue);
    }
  }

  getDuplicateId(message: string, type: AlertType): string {
    return this.queue.reduce((item, curr) => {
      if (curr.message === message && curr.type === type) {
        return curr.uuid;
      }

      return item;
    }, '');
  }

  registerAlert(
    message: string,
    dismissible = true,
    timeout: number,
    type: AlertType
  ) {
    const alerts: Alert[] = this.queueSubject$.getValue();

    const currentAlert: Alert | null = this.alert;

    const duplicateId = this.getDuplicateId(message, type);

    const newAlert: Alert = {
      uuid: uuid(),
      type,
      message,
      dismissible,
      timeout
    };

    if (currentAlert !== null) {
      if (currentAlert.message === message && currentAlert.type === type) {
        currentAlert.timeout = timeout + moment().unix();
        this.alertSubject$.next(currentAlert);
      } else {
        if (duplicateId === '') {
          alerts.push(newAlert);
          this.queueSubject$.next(alerts);
        }
      }
    } else {
      newAlert.timeout = newAlert.timeout + moment().unix();
      this.alertSubject$.next(newAlert);
    }
  }

  success(
    message: string,
    dismissible = true,
    timeout: number = this.defaultTimeout
  ): void {
    this.registerAlert(message, dismissible, timeout, AlertType.SUCCESS);
  }

  error(
    message: string,
    dismissible = true,
    timeout: number = this.defaultTimeout
  ): void {
    this.registerAlert(message, dismissible, timeout, AlertType.ERROR);
  }

  warn(
    message: string,
    dismissible = true,
    timeout: number = this.defaultTimeout
  ): void {
    this.registerAlert(message, dismissible, timeout, AlertType.WARN);
  }

  clear(): void {
    this.queueSubject$.next([]);
    this.alertSubject$.next(null);
  }

  dismiss(dismissed = false) {
    this.alertSubject$.next(null);
    if (!dismissed) {
      this.checkQueue();
    }
  }
}
