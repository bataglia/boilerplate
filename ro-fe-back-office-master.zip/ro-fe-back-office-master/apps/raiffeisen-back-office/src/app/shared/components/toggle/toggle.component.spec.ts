import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToggleComponent } from './toggle.component';

describe('ToggleComponent', () => {
  let component: ToggleComponent;
  let fixture: ComponentFixture<ToggleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToggleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToggleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit clickEvent', () => {
    spyOn(component['checkedChange'], 'emit');

    component.toggleClick();

    expect(component['checkedChange'].emit).toHaveBeenCalled();
  });

  it('should emit event when disabled', () => {
    spyOn(component['clickOnDisabled'], 'emit');
    component.disabled = true;
    component.toggleClick();

    expect(component['clickOnDisabled'].emit).toHaveBeenCalled();
  });
});
