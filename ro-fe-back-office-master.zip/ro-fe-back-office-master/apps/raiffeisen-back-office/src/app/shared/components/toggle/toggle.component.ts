import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

@Component({
  selector: 'ui-rzbr-toggle',
  templateUrl: './toggle.component.html',
  styleUrls: ['./toggle.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ToggleComponent {
  @Input() checked = false;
  @Input() disabled = false;

  @Output() private readonly checkedChange: EventEmitter<boolean> = new EventEmitter();
  @Output() readonly clickOnDisabled = new EventEmitter();
  constructor() {}

  toggleClick() {
    if (this.disabled) {
      this.clickOnDisabled.emit();
      
      return;
    }
    this.checkedChange.emit(!this.checked);
  }
}
