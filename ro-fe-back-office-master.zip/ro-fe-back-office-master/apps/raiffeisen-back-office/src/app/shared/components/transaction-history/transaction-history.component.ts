import { formatDate } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

import { combineLatest } from 'rxjs';
import {
  finalize,
  map,
  withLatestFrom,
  distinctUntilChanged
} from 'rxjs/operators';

import { AccountsFacade } from '@rf-store/accounts/accounts.facade';
import { TransactionHistoryFacade } from '@rf-store/transaction-history/transaction-history.facade';
import * as fromModel from '@rf-store/transaction-history/transaction-history.model';
import { DynamicLocaleService } from '@utils/dynamic-locale.service';

import { SubscribedComponent } from '@utils/subscribed-component';

import * as moment from 'moment';

@Component({
  selector: 'ui-rzbr-transaction-history',
  templateUrl: './transaction-history.component.html',
  styleUrls: ['./transaction-history.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TransactionHistoryComponent extends SubscribedComponent
  implements OnInit {
  currentDate = moment();
  transactionRequest: fromModel.TransactionHistoryRequest;
  transactionStatusTypes: fromModel.TransactionStatusTypes[] = Object.values(
    fromModel.TransactionStatusTypes
  );
  holdTransactions$ = this.transactionHistoryFacade.selectTransactions$(
    fromModel.TransactionStatusTypes.HOLD
  );
  pendingTransactions$ = this.transactionHistoryFacade.selectTransactions$(
    fromModel.TransactionStatusTypes.PENDING
  );
  successTransactions$ = this.transactionHistoryFacade.selectTransactions$(
    fromModel.TransactionStatusTypes.SUCCESS
  );
  isEmpty$ = this.transactionHistoryFacade.isEmpty$;
  selectedAccounts$ = this.accountsFacade.selectedAccounts$;
  accountLoading$ = this.accountsFacade.loading$;
  transactionHistoryLoading$ = this.transactionHistoryFacade.loading$;
  pagingState$ = this.transactionHistoryFacade.pagingState$;
  ready = false;
  loadMore = false;

  constructor(
    private readonly dynamicLocaleService: DynamicLocaleService,
    private readonly accountsFacade: AccountsFacade,
    private readonly transactionHistoryFacade: TransactionHistoryFacade
  ) {
    super();
  }

  ngOnInit() {
    this.registerSubscriptions(
      this.selectedAccounts$
        .pipe(finalize(() => (this.ready = true)))
        .subscribe((value) => {
          if (value.length > 0) {
            this.transactionRequest = {
              accountId: Number(value[0].id),
              size: 10,
              filter: {
                includeCreditTransactions: true,
                includeDebitTransactions: true
              },
              transactionStatusTypes: this.transactionStatusTypes,
              accountType: value[0].typeId
            };
            this.transactionHistoryFacade.reset();
            this.getData();
          }
        }),
      combineLatest(this.pagingState$, this.transactionHistoryLoading$)
        .pipe(
          map(
            ([state, loading]) =>
              (state === undefined || state !== 'LAST_PAGE') && !loading
          ),
          distinctUntilChanged()
        )
        .subscribe((value) => {
          this.loadMore = value;
        })
    );
  }

  getData() {
    this.transactionHistoryFacade.getTransactionsList(this.transactionRequest);
  }

  sort(a: { key: string; value: any }, b: { key: string; value: any }) {
    return a.key > b.key ? -1 : 1;
  }

  getTitle(date: string) {
    return formatDate(
      date,
      this.currentDate.isSame(date, 'year') ? 'dd MMMM' : 'dd MMMM yyyy',
      this.dynamicLocaleService.locale
    );
  }

  getPrefixTitle(date: string) {
    if (this.currentDate.isSame(date, 'day')) {
      return 'general__labels__today_short';
    } else if (
      this.currentDate.isSame(moment(date).subtract(1, 'day'), 'day')
    ) {
      return 'general__labels__yesterday';
    } else {
      return '';
    }
  }
}
