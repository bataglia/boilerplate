import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit
} from '@angular/core';

import * as fromModel from '@rf-store/transaction-history/transaction-history.model';

@Component({
  selector: 'ui-rzbr-transaction-item',
  templateUrl: './transaction-item.component.html',
  styleUrls: ['./transaction-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TransactionItemComponent {
  @Input() item: fromModel.TransactionHistory;

  get sign() {
    return this.item.transactionType === fromModel.TransactionType.CREDIT ? "+" : "-";
  }
}
