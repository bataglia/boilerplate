import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit
} from '@angular/core';

import * as fromModel from '@rf-store/transaction-history/transaction-history.model';

@Component({
  selector: 'ui-rzbr-transaction-list',
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TransactionListComponent {
  @Input() items: fromModel.TransactionHistory[];
  @Input() title = '';
  @Input() prefixTitleString = '';
}
