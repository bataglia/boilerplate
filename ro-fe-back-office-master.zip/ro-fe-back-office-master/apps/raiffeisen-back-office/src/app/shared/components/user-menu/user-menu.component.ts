import { DOCUMENT } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Inject,
  Input,
  Output
} from '@angular/core';

@Component({
  selector: 'ui-rzbr-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserMenuComponent {
  @Input() avatarName: string;

  @Input() avatarUrl: string;

  @Output() readonly logOut: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(DOCUMENT) private readonly document: Document) {}

  expanded = false;

  toggle() {
    this.expanded = !this.expanded;
    this.document.body.classList.toggle('user-menu-open');
  }
}
