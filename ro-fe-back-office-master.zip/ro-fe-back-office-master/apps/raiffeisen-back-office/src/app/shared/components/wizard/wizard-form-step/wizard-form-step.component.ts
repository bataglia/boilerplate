import {
  ChangeDetectionStrategy,
  Component,
  ComponentFactoryResolver,
  Input,
  OnInit,
  ViewChild,
  ViewContainerRef
} from '@angular/core';

import { combineLatest, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { DialogService } from '@rf-shared/components/dialog/dialog.service';
import {
  DynamicComponentInterface,
  DynamicFactoryService
} from '@rf-shared/components/dynamic-factory/dynamic-factory.service';
import { PaymentsFacade } from '@rf-store/payments/payments.facade';
import { SubscribedComponent } from '@utils/subscribed-component';

@Component({
  selector: 'ui-rzbr-wizard-form-step',
  templateUrl: './wizard-form-step.component.html',
  styleUrls: ['./wizard-form-step.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WizardFormStepComponent extends SubscribedComponent
  implements OnInit {
  @Input() formComponent: DynamicComponentInterface;
  @Input() detailsComponent: DynamicComponentInterface;

  @ViewChild('formPlaceholder', { static: true, read: ViewContainerRef })
  formPlaceholder: ViewContainerRef;
  @ViewChild('detailsPlaceholder', { static: true, read: ViewContainerRef })
  detailsPlaceholder: ViewContainerRef;

  shouldDisplayCancel$: Observable<boolean>;

  dialogSubscription: Subscription;

  constructor(
    private factoryResolver: ComponentFactoryResolver,
    private readonly paymentsFacade: PaymentsFacade,
    private readonly dynamicFactory: DynamicFactoryService,
    private readonly dialogService: DialogService
  ) {
    super();
  }

  ngOnInit() {
    this.dynamicFactory.loadComponent(this.formComponent, this.formPlaceholder);
    this.dynamicFactory.loadComponent(
      this.detailsComponent,
      this.detailsPlaceholder
    );

    this.shouldDisplayCancel$ = combineLatest(
      this.paymentsFacade.fromAccounts$,
      this.paymentsFacade.selectedFromAccount$
    ).pipe(
      map(([accounts, selectedAccount]) =>
        accounts.length === 1 ? false : selectedAccount !== null
      )
    );
  }

  resetForm() {
    this.dialogSubscription = this.dialogService
      .open('payments__actions__payment_confirm_reset')
      .subscribe((ok) => {
        if (ok) {
          this.paymentsFacade.resetForm();
        }

        if (ok !== null) {
          this.dialogSubscription.unsubscribe();
          this.removeSubscription(this.dialogSubscription);
        }
      });

    this.registerSubscriptions(this.dialogSubscription);
  }
}
