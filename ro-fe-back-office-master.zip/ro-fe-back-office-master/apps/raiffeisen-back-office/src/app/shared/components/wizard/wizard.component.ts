import {
  ChangeDetectionStrategy,
  Component,
  ComponentFactoryResolver,
  Input,
  ViewChild,
  ViewContainerRef
} from '@angular/core';
import {
  DynamicComponentInterface,
  DynamicFactoryService
} from '@rf-shared/components/dynamic-factory/dynamic-factory.service';

@Component({
  selector: 'ui-rzbr-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WizardComponent {
  private _currentIndex = 0;

  @Input() steps: DynamicComponentInterface[];
  @Input()
  set currentIndex(index: number) {
    this._currentIndex = index;
    this.dynamicFactory.loadComponent(this.steps[index], this.placeholder);
  }
  get currentIndex() {
    return this._currentIndex;
  }

  @ViewChild('placeholder', { static: true, read: ViewContainerRef })
  placeholder: ViewContainerRef;
  constructor(private readonly dynamicFactory: DynamicFactoryService) {}

  goToStep(index: number) {
    if (index === this.currentIndex || index === this.steps.length) {
      return;
    }
    this.currentIndex = index;
  }
}
