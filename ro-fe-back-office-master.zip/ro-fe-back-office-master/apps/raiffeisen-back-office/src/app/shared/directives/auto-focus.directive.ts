import { Directive, ElementRef, OnInit } from '@angular/core';

@Directive({
  selector: '[rzbrAutofocus]'
})
export class AutoFocusDirective implements OnInit {
  constructor(private readonly elementRef: ElementRef) {}

  ngOnInit(): void {
    this.elementRef.nativeElement.focus();
  }
}
