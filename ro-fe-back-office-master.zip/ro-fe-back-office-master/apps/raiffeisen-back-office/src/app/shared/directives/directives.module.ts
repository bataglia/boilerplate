import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AutoFocusDirective } from './auto-focus.directive';
import { ClickOutsideDirective } from './click-outside.directive';
import { HasToRenderDirective } from './has-to-render.directive';
import { ImagePreloadDirective } from './image-preload.directive';
import { KeydownDirective } from './keydown.directive';
import { SelectorDirective } from './selector.directive';

const declarationsAndExport = [
  KeydownDirective,
  AutoFocusDirective,
  HasToRenderDirective,
  ImagePreloadDirective,
  ClickOutsideDirective,
  SelectorDirective
];

@NgModule({
  imports: [CommonModule],
  exports: [...declarationsAndExport],
  declarations: [...declarationsAndExport]
})
export class RzbrDirectivesModule {}
