import {
  Directive,
  Input,
  OnInit,
  TemplateRef,
  ViewContainerRef
} from '@angular/core';

/**
 *
 *
 * Has To Render Directive
 *
 * What does it do?
 * Apply this directive instead of *ngIf to remove the items from the DOM not hide.
 *
 * When?
 * When you have a list of items and you need to show a diffrent component.
 *
 * Example
 * <ng-container *ngFor="let item of items$ | async">
 *      <feature-ipsum *appHasToRender="[item.type, 'ipsum']">Lorem</feature-ipsum>
 *      <feature-lorem *appHasToRender="[item.type, 'lorem']">Ipsum</feature-lorem>
 * </ng-container
 *
 * FeatureComponent keeps methods to implement in both components
 * LoremComponent extends FeatureComponent
 * IpsumComponent extends FeatureComponent
 */

@Directive({
  selector: '[rzbrHasToRender]'
})
export class HasToRenderDirective implements OnInit {
  private data: [] = [];
  private ref: any;

  @Input()
  set rzbrHasToRender(data: []) {
    this.data = data;
    this.ref = data[data.length - data.length];
  }

  rendered = false;

  constructor(
    private readonly templateRef: TemplateRef<any>,
    private readonly viewContainer: ViewContainerRef
  ) {}

  ngOnInit() {
    if (this.data.every((item) => item === this.ref)) {
      if (!this.rendered) {
        this.rendered = true;
        this.viewContainer.createEmbeddedView(this.templateRef);
      }
    } else {
      this.rendered = false;
      this.viewContainer.clear();
    }
  }
}
