import { Directive, EventEmitter, Input, Output } from '@angular/core';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[imagePreload]',
  // tslint:disable-next-line: no-host-metadata-property
  host: {
    '(error)': 'updateUrl()',
    '[src]': 'src'
  }
})
export class ImagePreloadDirective {
  @Input() src: string;
  @Input() default: string;
  @Output() readonly srcChange: EventEmitter<
    string | null
  > = new EventEmitter();

  updateUrl() {
    if (this.default) {
      this.src = this.default;
    } else {
      this.srcChange.emit(null);
    }
  }
}
