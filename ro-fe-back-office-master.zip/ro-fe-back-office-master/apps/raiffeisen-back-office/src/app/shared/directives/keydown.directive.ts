import {
  Directive,
  EventEmitter,
  HostListener,
  Input,
  Output
} from '@angular/core';

@Directive({
  selector: '[rzbrKeydownAction]'
})
export class KeydownDirective {
  @Input() keydownEnabled = true;

  @Input() propagate = false;

  @Input() code: string;

  @Output('rzbrKeydownAction')
  private readonly keydownAction: EventEmitter<
    KeyboardEvent
  > = new EventEmitter<KeyboardEvent>();

  @HostListener('document:keydown', ['$event'])
  onKeyDown($event: KeyboardEvent) {
    if (this.code === $event.key) {
      if (!this.propagate) {
        $event.preventDefault();
      }
      this.keydownAction.emit($event);
    }
  }
}
