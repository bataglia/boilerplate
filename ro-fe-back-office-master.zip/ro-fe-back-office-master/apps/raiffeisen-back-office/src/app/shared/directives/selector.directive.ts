import { Directive, Input, TemplateRef } from '@angular/core';

@Directive({ selector: '[rzbrSelector]' })
export class SelectorDirective {
  constructor(public template: TemplateRef<any>) {}
  @Input('rzbrSelector') selector = '';
}
