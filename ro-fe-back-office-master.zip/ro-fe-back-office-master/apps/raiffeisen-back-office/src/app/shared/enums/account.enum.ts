export enum ACCOUNT_TYPE {
  CURRENT = '20',
  SAVINGS = '26',
  TIME = '30',
  LOAN = '50'
}
