export enum USER_GROUPS {
  RAIFFEISEN_ONLINE = 'RO_PRODUCT',
  ALLOWED = 'RO_ALLOWED',
  TERMS_AND_CONDITIONS = 'RO_TC_AGREED'
}

export enum CHANNELS {
  WEB = 'ROATH',
  MOBILE = 'SMATH'
}

export enum HEADERS {
  GROUPS = 'iv-groups',
  TC_URL = 'tcUrl',
  HAS_EMV = 'has-emv',
  ENROLL_SESSION_ID = 'ENROLL_SESSION_ID'
}

export enum GRANTS {
  AUTHENTICATOR_CLIENT = 'AuthenticatorClient',
  SMART_MOBILE_CLIENT = 'SmartMobileClient'
}
