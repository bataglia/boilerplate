export enum DEVICES {
  MOBILE = 'mobile',
  TABLET = 'tablet',
  DESKTOP = 'desktop',
  ANDROID_MOBILE = 'android mobile',
  ANDROID_TABLET = 'android tablet',
  IPHONE = 'iphone',
  IPAD = 'ipad',
  WINDOWS_PHONE = 'windows phone'
}
