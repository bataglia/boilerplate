export enum LANGUAGES {
  RO = 'ro',
  EN = 'en'
}

export enum DECIMAL_SEPARATORS {
  RO = ',',
  EN = '.'
}

export enum THOUSAND_SEPARATORS {
  RO = '.',
  EN = ','
}
