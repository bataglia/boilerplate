export enum STORAGE {
  CARDS_LIST = 'cards_data_key',
  CREDIT_CARD_LIST = 'credit_card_data_key',
  FIRST_NAME = 'first_name',
  LAST_NAME = 'last_name',
  HASEMV = 'hasEMV',
  USER_PROFILE = 'userProfile',
  IS_LEGAL_ENTITY = 'isLegalEntity',
  ENROLL_SESSION_ID = 'enrollSessionId',
  TERMS_AND_CONDITIONS_FLOW = 'termsAndConditionsFlow',
  GRANTS_LIST = 'grantsList',
  CURRENT_SELECTED_ACCOUNT = 'current_selected_account'
}
