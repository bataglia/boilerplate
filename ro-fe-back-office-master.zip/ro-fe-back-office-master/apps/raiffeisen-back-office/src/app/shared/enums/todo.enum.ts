export enum TODO_STATES {
  ALERT,
  RESULT,
  PENDING
}
