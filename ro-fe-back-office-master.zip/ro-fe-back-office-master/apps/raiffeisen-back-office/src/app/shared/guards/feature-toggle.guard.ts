import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';

import { Observable } from 'rxjs';

import { FEATURE_TOGGLE } from '@utils/feature-toggle';

@Injectable({
  providedIn: 'root'
})
export class FeatureToggleGuard implements CanActivate {
  constructor(private readonly router: Router) {}
  canActivate(
    route: ActivatedRouteSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    return !FEATURE_TOGGLE[route.data.feature];
  }
}
