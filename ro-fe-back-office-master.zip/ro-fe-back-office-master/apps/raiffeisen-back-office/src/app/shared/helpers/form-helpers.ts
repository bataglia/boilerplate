export function isDistinctData(obj1: any = {}, obj2: any = {}): boolean {
  if (obj1 === null || obj2 === null) {
    return false;
  }

  let identical = true;

  for (const key in obj2) {
    if (
      obj2.hasOwnProperty(key) &&
      obj1.hasOwnProperty(key) &&
      obj1[key] !== obj2[key]
    ) {
      identical = false;
    }
  }

  return identical;
}

export function getDistinctData(values: any[]): any {
  const lastValues: any = values[0] || {};
  const currentValues: any = values[1] || {};

  const acc: any = {};

  for (const key in currentValues) {
    if (
      currentValues.hasOwnProperty(key) &&
      lastValues.hasOwnProperty(key) &&
      lastValues[key] !== currentValues[key]
    ) {
      acc[key] = currentValues[key];
    }
  }

  return acc;
}
