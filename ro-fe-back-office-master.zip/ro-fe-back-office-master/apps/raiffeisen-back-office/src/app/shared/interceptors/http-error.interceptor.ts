import {
  HttpErrorResponse,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { LogoutTimerService } from '@rf-shared/services/logout-timer.service';
import { AuthFacade } from '@rf-store/auth/auth.facade';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  isLoggedIn$ = this.authFacade.isLoggedIn$;

  constructor(
    private readonly authFacade: AuthFacade,
    private readonly logoutTimerService: LogoutTimerService
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {
    return next.handle(req).pipe(
      map((event) => {
        if (event instanceof HttpResponse && !req.url.includes('assets/i18n')) {
          this.logoutTimerService.resetDate();
        }

        return event;
      }),
      catchError(this.handleError.bind(this))
    );
  }

  handleError(error: HttpErrorResponse): Observable<any> {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      return throwError('Something bad happened; please try again later.');
    } else {
      if (error.status === 401) {
        this.isLoggedIn$
          .subscribe((loggedIn) => {
            if (loggedIn) {
              this.logoutTimerService.openModal();
            }
          })
          .unsubscribe();
        // change this with pop-up from time
      }

      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      return throwError(error);
    }
  }
}
