import {
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';
import { Injectable } from '@angular/core';

import { DynamicLocaleService } from '@utils/dynamic-locale.service';
import { Observable } from 'rxjs';

@Injectable()
export class HttpTranslateInterceptor implements HttpInterceptor {
  constructor(private readonly localeService: DynamicLocaleService) {}
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {
    if (req.url.includes('assets/i18n')) {
      return next.handle(
        req.clone({
          setHeaders: {
            'Content-Type': 'application/json'
          }
        })
      );
    }
    
    return next.handle(
      req.clone({
        setHeaders: {
          LANGUAGE: this.localeService.locale.toLocaleLowerCase()
        }
      })
    );
  }
}
