export enum AlertType {
  SUCCESS = 'success',
  ERROR = 'danger',
  WARN = 'warning'
}

export interface Alert {
  uuid: string;
  type: AlertType;
  message: string;
  dismissible: boolean;
  timeout: number;
}
