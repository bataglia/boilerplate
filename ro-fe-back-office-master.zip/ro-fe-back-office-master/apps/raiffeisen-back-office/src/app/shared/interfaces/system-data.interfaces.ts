export interface SystemDate {
  timestamp: string;
}
