import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'cardNumberDisplay'
})
export class CardNumberDisplayPipe implements PipeTransform {
  transform(value: string, ...args: any[]): string {
    if (value.length === 16) {
      const arr = value.match(/(\d|\D){1,4}/g) || [];
      let str = arr.join(' ');

      str = str.replace(/\s([0-9]{4})\s+/, ' **** ');
      str = str.replace(/\s([0-9]{4})\s+/, ' **** ');

      return str;
    }

    return value;
  }
}
