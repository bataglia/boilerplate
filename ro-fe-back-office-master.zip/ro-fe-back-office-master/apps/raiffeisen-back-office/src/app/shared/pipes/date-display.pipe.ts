import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';

import { SubscribedComponent } from '@utils/subscribed-component';

@Pipe({
  name: 'datePrefix'
})
export class DateDisplayPipe extends SubscribedComponent
  implements PipeTransform {
  today?: string;
  yesterday?: string;
  tomorrow?: string;

  constructor(private readonly translate: TranslateService) {
    super();
  }

  /*tslint:disable: no-redundant-jsdoc*/
  /**
   * Transforms the moment date provided into a formatted string with an appropriate prefix for
   * today, tomorrow or yesterday.
   *
   * Returns a BehaviorSubject due to the need to translate the prefixes
   *
   * Requires async pipe to be used:
   * {{myDate | prefixDate | async}}
   *
   * @param {moment.Moment} value
   * @param {any[]} args
   */
  transform(value: moment.Moment, ...args: any[]): BehaviorSubject<string> {
    const subject = new BehaviorSubject<string>('');

    if (!this.today) {
      this.registerSubscriptions(
        this.translate
          .get([
            'general__labels__today',
            'general__labels__yesterday',
            'general__labels__tomorrow'
          ])
          .subscribe(
            (result: {
              general__labels__today: string;
              general__labels__tomorrow: string;
              general__labels__yesterday: string;
            }) => {
              this.today = result.general__labels__today;
              this.tomorrow = result.general__labels__tomorrow;
              this.yesterday = result.general__labels__yesterday;

              const output = this.computeDateOutput(value);

              subject.next(`${output}${value.format('D MMM YYYY')}`);
            }
          )
      );
    } else {
      subject.next(`${value.format('D MMM YYYY')}`);
    }

    return subject;
  }

  /**
   * Compares the provided date with today, yesterday and tomorrow
   * and returns a string with the necessary prefix
   * @param {moment.Moment} value
   */
  computeDateOutput(value: moment.Moment): string {
    let output = '';

    const yesterday = moment().subtract(1, 'd');

    const tomorrow = moment().add(1, 'd');

    // if the value date is yesterday, prefix the output with "Yesterday"
    if (yesterday.isSame(value, 'day')) {
      output = `${this.yesterday}, `;
    } else if (tomorrow.isSame(value, 'day')) {
      output = `${this.tomorrow}, `;
    } else if (value.isSame(moment(), 'day')) {
      output = `${this.today}, `;
    }

    return output;
  }
}
