import { Pipe, PipeTransform } from '@angular/core';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import * as moment from 'moment';

import { DynamicLocaleService } from '@utils/dynamic-locale.service';

enum DateFormat {
  RO = 'D MMMM YYYY',
  EN = 'MMMM D, YYYY'
}

@Pipe({
  name: 'dateLongFormat',
  pure: true
})
export class DateFormatLongPipe implements PipeTransform {
  constructor(private readonly dynamicLocaleService: DynamicLocaleService) {}

  transform(value: moment.Moment | string, ...args: any[]): Observable<string> {
    return this.dynamicLocaleService.locale$.pipe(
      map((locale) => this.computeDateOutput(value, locale))
    );
  }

  computeDateOutput(value: moment.Moment | string, lang: string): string {
    // tslint:disable-next-line:ban-ts-ignore
    // @ts-ignore
    return moment(value).format(DateFormat[lang.toUpperCase()]);
  }
}
