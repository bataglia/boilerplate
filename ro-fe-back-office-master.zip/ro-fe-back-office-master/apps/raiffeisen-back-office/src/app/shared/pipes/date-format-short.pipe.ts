import { Pipe, PipeTransform } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import * as moment from 'moment';

import { DynamicLocaleService } from '@utils/dynamic-locale.service';
import { SubscribedComponent } from '@utils/subscribed-component';

import { LANGUAGES } from '@rf-shared/enums';

enum DateFormat {
  RO = 'D MMM',
  EN = 'MMM D'
}

@Pipe({
  name: 'dateShortFormat',
  pure: true
})
export class DateFormatShortPipe extends SubscribedComponent
  implements PipeTransform {
  constructor(private readonly locale: DynamicLocaleService) {
    super();
  }

  transform(value: moment.Moment, ...args: any[]): BehaviorSubject<string> {
    const subject = new BehaviorSubject<string>('');

    this.registerSubscriptions(
      this.locale.locale$.subscribe((result) => {
        const output = this.computeDateOutput(value, result);
        const splittedDate = output.split(' ');

        if (result === LANGUAGES.RO) {
            splittedDate[1] = splittedDate[1].substring(0, 3);
        }

        subject.next(splittedDate.join(' '));
      })
    );

    return subject;
  }

  computeDateOutput(value: moment.Moment, lang: string): string {
    // moment.locale(lang);

    // @ts-ignore
    return moment(value).format(DateFormat[lang.toUpperCase()]);
  }
}
