import { Pipe, PipeTransform } from '@angular/core';

import * as fromModel from '@rf-store/payments/payments.model';

@Pipe({
  name: 'filterAccounts',
  pure: true
})
export class FilterAccountsPipe implements PipeTransform {
  transform(
    items: fromModel.Account[],
    filter: fromModel.Account
  ): fromModel.Account[] {
    if (!items || !filter) {
      return items;
    }

    return items.filter((item) => item.iban !== filter.iban);
  }
}
