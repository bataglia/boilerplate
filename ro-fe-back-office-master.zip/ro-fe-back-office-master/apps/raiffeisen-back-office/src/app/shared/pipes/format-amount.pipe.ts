import { DecimalPipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

import { DynamicLocaleService } from '@utils/dynamic-locale.service';

import { CONSTANTS } from '@utils/constants';

@Pipe({
  name: 'formatAmount'
})
export class FormatAmountPipe implements PipeTransform {
  constructor(
    private readonly dynamicLocaleService: DynamicLocaleService,
    private readonly decimalPipe: DecimalPipe
  ) {}

  processAmountByLocale(amount: number, locale: string) {
    const decimalFormat = '1.2-2';

    const localeSeparators = CONSTANTS.LOCALE[locale.toUpperCase()];

    const parsedAmount: string =
      this.decimalPipe.transform(amount, decimalFormat, locale) || '';

    const amountPieces = parsedAmount.split(localeSeparators.DECIMAL_SEPARATOR);

    const integerPart = amountPieces[0];
    const decimalSeparator = localeSeparators.DECIMAL_SEPARATOR;
    const decimals = amountPieces[1];

    return `${integerPart}${decimalSeparator}${decimals}`;
  }

  transform(value: number): string {
    const locale = this.dynamicLocaleService.locale;

    return this.processAmountByLocale(value, locale);
  }
}
