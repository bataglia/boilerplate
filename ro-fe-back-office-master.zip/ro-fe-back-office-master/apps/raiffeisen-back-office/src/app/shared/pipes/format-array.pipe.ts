import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatArray'
})
export class FormatArrayPipe implements PipeTransform {
  constructor() {}

  transform(values: any[], key: string): any[] {
    if (!values || values.length === 0) {
      return values;
    }

    return values.reduce((acc, curr) => {
      if (acc[curr[key]] === undefined) {
        acc[curr[key]] = [];
      }
      acc[curr[key]].push(curr);

      return acc;
    }, []);
  }
}
