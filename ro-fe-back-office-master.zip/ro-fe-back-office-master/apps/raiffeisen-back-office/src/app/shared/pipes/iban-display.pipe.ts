import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatIban'
})
export class IbanDisplayPipe implements PipeTransform {
  transform(value: string, ...args: any[]): string {
    const findings = value.match(/(\d|\D){1,4}/g) || [];

    return findings.join(' ');
  }
}
