import { Pipe, PipeTransform } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';

import { SafePipe } from './safe.pipe';

@Pipe({
  name: 'markText'
})
export class MarkTextPipe implements PipeTransform {
  constructor(private readonly safePipe: SafePipe) {}

  transform(
    value: string,
    key: string,
    splitIntoWords = true,
    caseSensitive = false
  ): SafeHtml | string {
    if (!value || !key) {
      return value;
    }
    let keys = [key];

    if (splitIntoWords) {
      keys = key.split(' ');
    }

    const regex = new RegExp(
      keys.join('|'),
      `g${caseSensitive ? '' : 'i'}`
    );

    const returnValue = value.replace(regex, (matched) => {
      return `<span class='mark-text'>${matched}</span>`
    });

    return this.safePipe.transform(returnValue, 'html');
  }
}
