import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { CardNumberDisplayPipe } from './card-number-display.pipe';
import { DateDisplayPipe } from './date-display.pipe';
import { FilterAccountsPipe } from './filter-accounts.pipe';
import { FormatAmountPipe } from './format-amount.pipe';
import { FormatArrayPipe } from './format-array.pipe';
import { IbanDisplayPipe } from './iban-display.pipe';
import { MarkTextPipe } from './mark-text.pipe';
import { SafePipe } from './safe.pipe';
import { SignPipe } from './sign.pipe';
import { SimpleFilterPipe } from './simple-filter.pipe';
import { DateFormatShortPipe } from '@rf-shared/pipes/date-format-short.pipe';
import { DateFormatLongPipe } from '@rf-shared/pipes/date-format-long.pipe';

const declarationsAndExport = [
  DateDisplayPipe,
  IbanDisplayPipe,
  SignPipe,
  SafePipe,
  CardNumberDisplayPipe,
  FormatArrayPipe,
  SimpleFilterPipe,
  MarkTextPipe,
  FormatAmountPipe,
  FilterAccountsPipe,
  DateFormatShortPipe,
  DateFormatLongPipe
];

@NgModule({
  imports: [CommonModule],
  exports: [...declarationsAndExport],
  declarations: [...declarationsAndExport],
  providers: [SafePipe, SimpleFilterPipe]
})
export class RzbrPipesModule {}
