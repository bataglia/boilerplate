import { Pipe, PipeTransform } from '@angular/core';

/**
 * Applies a + sign to the provided number value
 * AngularJS equivalent: SignFilter
 */
@Pipe({
  name: 'sign'
})
export class SignPipe implements PipeTransform {
  /*tslint:disable: no-redundant-jsdoc*/

  /**
   * Returns a string of the provided value with '+' prepended if it is positive
   * @param {number} value
   * @param args
   */
  transform(value: number, ...args: any[]): string {
    if (value >= 0) {
      return `+${value}`;
    }

    return `${value}`;
  }
}
