import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'simpleFilter'
})
export class SimpleFilterPipe implements PipeTransform {
  constructor() {}

  transform(
    values: any[],
    keys: string[],
    filterBy: string,
    caseSensitive = false
  ): any[] {
    if (!values || values.length === 0) {
      return values;
    }

    if (!keys || keys.length === 0) {
      return values;
    }

    if (!filterBy) {
      return values;
    }

    const filterByArray = filterBy.split(' ');
    let copyValues = values;

    filterByArray.forEach((searchKey) => {
      copyValues = copyValues.reduce((acc, curr) => {
        if (caseSensitive) {
          if (
            keys.some(
              (k) =>
                curr[k] !== undefined && (curr[k] as string).includes(searchKey)
            )
          ) {
            acc.push(curr);
          }
        } else {
          if (
            keys.some(
              (k) =>
                curr[k] !== undefined &&
                (curr[k] as string)
                  .toLowerCase()
                  .includes(searchKey.toLowerCase())
            )
          ) {
            acc.push(curr);
          }
        }

        return acc;
      }, []);
    });

    return copyValues;
  }
}
