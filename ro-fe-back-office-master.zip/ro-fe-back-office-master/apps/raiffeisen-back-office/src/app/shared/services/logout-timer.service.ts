import { Injectable, OnDestroy } from '@angular/core';

import { interval, Subscription } from 'rxjs';

import { DialogService } from '@rf-shared/components/dialog/dialog.service';
import { ModalService } from '@rf-shared/components/modal/modal.service';
import { AuthFacade } from '@rf-store/auth/auth.facade';
import { StoreResetService } from '@rf-store/store-reset.service';

import * as moment from 'moment';

import { SubscribedComponent } from '@utils/subscribed-component';

@Injectable({ providedIn: 'root' })
export class LogoutTimerService extends SubscribedComponent
  implements OnDestroy {
  private _intervalId: Subscription;

  private _endDate: number;

  isLoggedIn$ = this.authFacade.isLoggedIn$;
  loginSubscription: Subscription;
  time = 60 * 5;

  constructor(
    private readonly modalService: ModalService,
    private readonly dialogService: DialogService,
    private readonly storeResetService: StoreResetService,
    private readonly authFacade: AuthFacade
  ) {
    super();
  }

  ngOnDestroy() {
    if (this.loginSubscription) {
      this.loginSubscription.unsubscribe();
    }
  }

  openModal() {
    this.dialogService.onClose(false);

    const subscription = this.modalService
      .open('user__labels__inactivity_warning')
      .subscribe((ok) => {
        if (ok) {
          this.storeResetService.clear();
          subscription.unsubscribe();
          this.removeSubscription(subscription);
        }
      });

    this.registerSubscriptions(subscription);
  }

  resetInterval() {
    if (this._intervalId) {
      this._intervalId.unsubscribe();
    }
  }

  resetDate() {
    this._endDate = moment().unix() + this.time;

    if (!this.loginSubscription) {
      this.loginSubscription = this.isLoggedIn$.subscribe((isLoggedIn) => {
        if (isLoggedIn) {
          if (!this._intervalId || this._intervalId.closed) {
            this.startTimer();
          }
        } else {
          this.resetInterval();
        }
      });
    }
  }

  startTimer() {
    this._intervalId = interval(1000).subscribe(() => {
      if (moment().unix() > this._endDate) {
        this.storeResetService.logoutWithoutRedirect();

        this.storeResetService.clearStorage();

        this.resetInterval();

        this.openModal();
      }
    });
  }
}
