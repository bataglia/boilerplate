import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';

import { TranslateModule } from '@ngx-translate/core';
import { DragulaModule } from 'ng2-dragula';
import { NgPipesModule } from 'ngx-pipes';
import { ResponsiveModule } from 'ngx-responsive';

import { RzbrComponentsModule } from './components/components.module';
import { RzbrDirectivesModule } from './directives/directives.module';
import { RzbrPipesModule } from './pipes/pipes.module';

const importsExports = [
  TranslateModule,
  NgPipesModule,
  RzbrComponentsModule,
  RzbrPipesModule,
  RzbrDirectivesModule
];

// https://angular.io/guide/styleguide#shared-feature-module
@NgModule({
  imports: [
    CommonModule,
    DragulaModule.forRoot(),
    ResponsiveModule.forRoot(),
    ...importsExports
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [
    DragulaModule,
    ResponsiveModule,
    ...importsExports
  ]
})
export class SharedModule {}
