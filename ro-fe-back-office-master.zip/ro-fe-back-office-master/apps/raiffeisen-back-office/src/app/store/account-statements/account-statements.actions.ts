import { createAction } from '@ngrx/store';

import * as fromModel from './account-statements.model';

export const downloadAccountStatementFile = createAction(
  '[Account Statements] Download account statement File',
  (payload: fromModel.StatementRequest) => ({ payload })
);

export const downloadAccountStatementFileSuccess = createAction(
  '[Account Statements] Download account statement File Success'
);

export const downloadAccountStatementFileFail = createAction(
  '[Account Statements] Download account statement File Fail'
);

export const getAccountStatementsList = createAction(
  '[Account Statements] Get account statements List',
  (payload: fromModel.StatementRequest) => ({ payload })
);

export const getAccountStatementsListSuccess = createAction(
  '[Account Statements] Get account statements List Success',
  (payload: fromModel.AccountStatement[]) => ({ payload })
);

export const getAccountStatementsListFail = createAction(
  '[Account Statements] Get account statements List Fail'
);
