import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';

import { ToasterService } from '@rf-shared/components/toaster/toaster.service';
import { saveAs } from '@utils/helper.functions';

import * as fromActions from './account-statements.actions';
import { AccountStatementsService } from './account-statements.service';

@Injectable()
export class AccountStatementsEffects {
  constructor(
    private readonly $actions: Actions,
    private readonly accountStatementsService: AccountStatementsService,
    private readonly toasterService: ToasterService
  ) {}

  downloadaccountStatementstatementFile$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.downloadAccountStatementFile),
      map((action) => action.payload),
      mergeMap((action) => {
        return this.accountStatementsService
          .downloadAccountStatementFile(
            action.accountId,
            action.accountType,
            action.fileFormat,
            action.onRequest,
            action.startDate,
            action.endDate
          )
          .pipe(
            map((res) => {
              saveAs(
                res,
                action.accountId +
                  (['XLSX', 'PDF'].includes(action.fileFormat)
                    ? `.${action.fileFormat.toLowerCase()}`
                    : '.txt')
              );

              return fromActions.downloadAccountStatementFileSuccess();
            }),
            catchError(() => {
              this.toasterService.error(
                'account_statement__labels__technical_error'
              );

              return of(fromActions.downloadAccountStatementFileFail());
            })
          );
      })
    )
  );

  getAccountStatementsList$ = createEffect(() => {
    return this.$actions.pipe(
      ofType(fromActions.getAccountStatementsList),
      map((action) => action.payload),
      mergeMap((action) => {
        return this.accountStatementsService
          .getAccountStatementList(
            action.accountId,
            action.accountType,
            action.startDate,
            action.endDate
          )
          .pipe(
            map((res) => {
              if (res.length === 1) {
                return fromActions.downloadAccountStatementFile({
                  accountId: action.accountId,
                  accountType: action.accountType,
                  fileFormat: action.fileFormat,
                  onRequest: false,
                  startDate: res[0],
                  endDate: res[0]
                });
              }

              return fromActions.getAccountStatementsListSuccess([
                { accountId: action.accountId, dates: res }
              ]);
            }),
            catchError(() => {
              this.toasterService.error(
                'account_statement__labels__technical_error'
              );

              return of(fromActions.getAccountStatementsListFail());
            })
          );
      })
    );
  });
}
