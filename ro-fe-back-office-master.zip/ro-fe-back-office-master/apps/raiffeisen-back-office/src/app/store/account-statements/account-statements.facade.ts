import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromActions from './account-statements.actions';
import * as fromModel from './account-statements.model';
import * as fromSelectors from './account-statements.selectors';

@Injectable()
export class AccountStatementsFacade {
  items$ = this.store.pipe(select(fromSelectors.selectItems));

  loading$ = this.store.pipe(select(fromSelectors.selectLoading));

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  downloadStatementFile(payload: fromModel.StatementRequest) {
    this.store.dispatch(fromActions.downloadAccountStatementFile(payload));
  }

  getStatementsList(payload: fromModel.StatementRequest) {
    this.store.dispatch(fromActions.getAccountStatementsList(payload));
  }

  reset() {
    this.store.dispatch(fromActions.getAccountStatementsListSuccess([]));
  }
}
