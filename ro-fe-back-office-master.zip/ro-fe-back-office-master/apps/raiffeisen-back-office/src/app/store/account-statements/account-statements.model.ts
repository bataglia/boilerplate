export interface AccountStatement {
  accountId: string;
  dates: string[];
}

export interface StatementRequest {
  accountId: string;
  accountType: string;
  fileFormat: string;
  startDate?: string;
  endDate?: string;
  onRequest?: boolean;
}


export interface InitialState {
  items: AccountStatement[];
  loading: boolean;
}

export enum AccountStatementTypes {
  INTRADAY = 'intraday',
  CUMULATIVE = 'cumulative',
  INDIVIDUAL = 'individual'
};