import { NgModule } from '@angular/core';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { AccountStatementsEffects } from './account-statements.effects';
import { AccountStatementsFacade } from './account-statements.facade';
import { reducer } from './account-statements.reducer';
import { AccountStatementsService } from './account-statements.service';

@NgModule({
  imports: [
    StoreModule.forFeature('account-statements', reducer),
    EffectsModule.forFeature([AccountStatementsEffects])
  ],
  providers: [AccountStatementsService, AccountStatementsFacade]
})
export class AccountStatementsStateModule {}
