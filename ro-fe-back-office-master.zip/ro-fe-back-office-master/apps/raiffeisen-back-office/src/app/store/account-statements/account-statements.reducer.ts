import { Action, createReducer, on } from '@ngrx/store';

import * as fromActions from './account-statements.actions';
import * as fromModel from './account-statements.model';

export const initialState: fromModel.InitialState = {
  items: [],
  loading: false
};

export const reducerFn = createReducer(
  initialState,
  on(fromActions.downloadAccountStatementFile, fromActions.getAccountStatementsList, (state) => ({
    ...state,
    loading: true
  })),
  on(
    fromActions.downloadAccountStatementFileSuccess,
    fromActions.downloadAccountStatementFileFail,
    fromActions.getAccountStatementsListFail,
    fromActions.getAccountStatementsListSuccess,
    (state) => ({
      ...state,
      loading: false,
      items: []
    })
  ),
  on(fromActions.getAccountStatementsListSuccess, (state, { payload }) => ({
    ...state,
    items: payload
  }))
);

export function reducer(
  state: fromModel.InitialState,
  action: Action
): fromModel.InitialState {
  return reducerFn(state, action);
}
