import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromModel from './account-statements.model';

export const selectAccountsState = createFeatureSelector<
  fromModel.InitialState
>('account-statements');

export const selectItems = createSelector(
  selectAccountsState,
  (state: fromModel.InitialState) => state.items
);

export const selectLoading = createSelector(
  selectAccountsState,
  (state: fromModel.InitialState) => state.loading
);
