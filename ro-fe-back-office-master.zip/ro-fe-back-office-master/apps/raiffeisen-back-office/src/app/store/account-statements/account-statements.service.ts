import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { buildQueryParams, getBaseUrl } from '@utils/helper.functions';

@Injectable()
export class AccountStatementsService {
  version = 'v1';

  constructor(private readonly http: HttpClient) {}

  downloadAccountStatementFile(
    accountId: string,
    accountType: string,
    fileFormat: string,
    onRequest?: boolean,
    startDate?: string,
    endDate?: string
  ): Observable<Blob> {
    const httpParams: HttpParams = buildQueryParams({
      accountId,
      accountType,
      fileFormat,
      onRequest,
      startDate,
      endDate
    });

    return this.http.get(
      `${getBaseUrl()}services/account-statement/${
        this.version
      }/debit/report/download`,
      {
        params: httpParams,
        withCredentials: true,
        responseType: 'blob'
      }
    );
  }

  getAccountStatementList(
    accountId: string,
    accountType: string,
    startDate?: string,
    endDate?: string
  ): Observable<string[]> {
    const httpParams: HttpParams = buildQueryParams({
      accountId,
      accountType,
      startDate,
      endDate
    });

    return this.http.get<string[]>(
      `${getBaseUrl()}services/account-statement/${
        this.version
      }/debit/report/activity`,
      {
        params: httpParams,
        withCredentials: true
      }
    );
  }
}
