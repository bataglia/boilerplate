import { createAction } from '@ngrx/store';

import * as fromModel from './accounts.model';

export const loadAccounts = createAction('[Accounts] Load Accounts');

export const loadAccountsSuccess = createAction(
  '[Accounts] Load Accounts Success',
  (payload: fromModel.Account[]) => ({ payload })
);

export const loadAccountsFail = createAction('[Accounts] Load Accounts Fail');

export const resetStore = createAction('[Accounts] Reset Store');

export const selectAccounts = createAction(
  '[Accounts] Select Accounts',
  (payload: fromModel.Account[]) => ({ payload })
);

export const addCreditAccounts = createAction(
  '[Accounts] Add accounts from credit request',
  (payload: fromModel.Account[]) => ({ payload })
);

export const getAllAndSetSelected = createAction(
  '[Accounts] Get All & Set Selected',
  (payload: string[]) => ({ payload })
);