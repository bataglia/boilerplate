import { provideMockActions } from '@ngrx/effects/testing';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable } from 'rxjs';
import * as fromActions from './accounts.actions';
import { AccountsService } from './accounts.service';
import { AccountsEffects } from './accounts.effects';
import { cold, hot } from 'jasmine-marbles';
import { ToasterService } from '@rf-shared/components/toaster/toaster.service';

describe('Accounts Effects', () => {
  let actions: Observable<any>;
  let effects: AccountsEffects;
  let service: AccountsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        AccountsEffects,
        AccountsService,
        ToasterService,
        provideMockActions(() => actions)
      ]
    });

    effects = TestBed.get(AccountsEffects);
    service = TestBed.get(AccountsService);
  });

  it('[Accounts] loadAccounts -> loadAccountsSuccess', () => {
    const mockPayload = [
      {
        accountKey: '00000',
        balance: 0,
        branchId: '00000',
        currency: '00000',
        eligibleForFeed: false,
        iban: '00000',
        id: '00000',
        interestRate: '00000',
        nickname: '00000',
        maturityDate: '00000',
        olp: false,
        openingDate: '00000',
        overdraftLimit: '00000',
        owner: false,
        ownerCif: '00000',
        productId: '00000',
        productName: '00000',
        representative: false,
        status: '00000',
        typeId: '00000'
      }
    ];

    const action = fromActions.loadAccounts();
    const outcome = fromActions.loadAccountsSuccess(mockPayload);

    actions = hot('-a', { a: action });
    const response = cold('-a|', { a: mockPayload });
    spyOn(service, 'loadAccountsApi').and.returnValue(response);

    const expected = cold('--b', { b: outcome });

    expect(effects.loadAccounts$).toBeObservable(expected);
  });

  it('[Accounts] loadAccounts -> loadAccountsFail', () => {
    const action = fromActions.loadAccounts();
    const outcome = fromActions.loadAccountsFail();
    const error = new Error('failed') as any;

    actions = hot('-a', { a: action });

    const response = cold('-#|', {}, error);

    spyOn(service, 'loadAccountsApi').and.returnValue(response);

    const expected = cold('--b', { b: outcome });

    expect(effects.loadAccounts$).toBeObservable(expected);
  });
});
