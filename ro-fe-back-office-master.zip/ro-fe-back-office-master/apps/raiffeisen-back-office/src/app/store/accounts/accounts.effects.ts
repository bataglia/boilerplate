import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import { of } from 'rxjs';
import { catchError, map, mergeMap, withLatestFrom } from 'rxjs/operators';

import { ToasterService } from '@rf-shared/components/toaster/toaster.service';
import { CardsFacade } from '@rf-store/cards/cards.facade';
import { CardsService } from '@rf-store/cards/cards.service';

import * as fromActions from './accounts.actions';
import { AccountsService } from './accounts.service';

@Injectable()
export class AccountsEffects {
  constructor(
    private readonly $actions: Actions,
    private readonly accountsService: AccountsService,
    private readonly toasterService: ToasterService,
    private readonly cardsFacade: CardsFacade,
    private readonly cardsService: CardsService
  ) {}

  loadAccounts$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.loadAccounts),
      mergeMap(() =>
        this.accountsService.loadAccountsApi().pipe(
          withLatestFrom(this.cardsFacade.rawCredit$),
          map(([data, rawCredit]) => {
            if (rawCredit.length > 0) {
              const {
                cardsData,
                accountsData
              } = this.cardsService.processResponse(rawCredit, data);

              this.cardsFacade.loadCreditCardsSuccess(cardsData);

              return fromActions.addCreditAccounts([...accountsData, ...data]);
            } else {
              return fromActions.loadAccountsSuccess(data);
            }
          }),
          catchError(() => {
            this.toasterService.error('general__label__tehnical_error');

            return of(fromActions.loadAccountsFail());
          })
        )
      )
    )
  );

  getAllAndSetSelected$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.getAllAndSetSelected),
      mergeMap((action) =>
        this.accountsService.loadAccountsApi().pipe(
          mergeMap((data) => {
            const selected = data.filter((x) => action.payload.includes(x.id));

            return of(
              fromActions.selectAccounts(selected),
              fromActions.loadAccountsSuccess(data)
            );
          }),
          catchError(() => {
            this.toasterService.error('general__label__no_information');

            return of(fromActions.loadAccountsFail());
          })
        )
      )
    )
  );
}
