import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromActions from './accounts.actions';
import * as fromModel from './accounts.model';
import * as fromSelectors from './accounts.selectors';

@Injectable()
export class AccountsFacade {
  items$ = this.store.pipe(select(fromSelectors.selectItems));

  loading$ = this.store.pipe(select(fromSelectors.selectLoading));

  loaded$ = this.store.pipe(select(fromSelectors.selectLoaded));

  selectedAccounts$ = this.store.pipe(select(fromSelectors.selectedItems));

  selectAccount$(id: string) {
    return this.store.pipe(select(fromSelectors.selectItem(id)));
  }

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  loadAccounts() {
    this.store.dispatch(fromActions.loadAccounts());
  }

  addCreditAccounts(items: fromModel.Account[]) {
    this.store.dispatch(fromActions.addCreditAccounts(items));
  }

  setSelectedItems(items: fromModel.Account[]) {
    this.store.dispatch(fromActions.selectAccounts(items));
  }

  getAllAndSetSelected(itemIds: string[]) {
    this.store.dispatch(fromActions.getAllAndSetSelected(itemIds));
  }

  resetStore() {
    this.store.dispatch(fromActions.resetStore());
  }
}
