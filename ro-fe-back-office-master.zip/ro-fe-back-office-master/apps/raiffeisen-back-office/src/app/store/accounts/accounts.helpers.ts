import * as fromModel from './accounts.model';

export const patchAccounts = (x: fromModel.Account) => {
  if (x.currency.toLowerCase() === 'ron') {
    x.currency = 'Lei';
  }

  if (!x.nickname) {
    x.nickname = x.productName ? x.productName : x.iban;
  }

  return x;
};
