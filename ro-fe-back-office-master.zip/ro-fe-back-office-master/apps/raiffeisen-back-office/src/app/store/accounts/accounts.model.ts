export interface InitialState {
  items: Account[];
  loading: boolean;
  loaded: boolean;
  selectedItems: Account[];
}

export interface Account {
  accountKey: string;
  balance: number;
  branchId: string;
  currency: string;
  eligibleForFeed: boolean;
  iban: string;
  id: string;
  interestRate?: string;
  nickname?: string;
  maturityDate?: string;
  olp: boolean;
  openingDate: string;
  overdraftLimit?: string;
  owner: boolean;
  ownerCif: string;
  productId: string;
  productName: string;
  representative: boolean;
  status: string;
  typeId: string;
}

export interface SimpleAccount {
  id: string;
  nickname: string;
}
