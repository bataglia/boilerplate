import { NgModule } from '@angular/core';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { AccountsEffects } from './accounts.effects';
import { AccountsFacade } from './accounts.facade';
import { reducer } from './accounts.reducer';
import { AccountsService } from './accounts.service';

@NgModule({
  imports: [
    StoreModule.forFeature('accounts', reducer),
    EffectsModule.forFeature([AccountsEffects])
  ],
  providers: [AccountsService, AccountsFacade]
})
export class AccountsStateModule {}
