import { reducer, initialState } from './accounts.reducer';
import * as fromActions from './accounts.actions';

const mockData = [
  {
    accountKey: '20|7259061',
    id: '7259061',
    typeId: '20',
    iban: 'RO02RZBR0000060007259061',
    balance: 10031362774.55,
    status: '1',
    nickname: 'pachet 00 tst',
    currency: 'RON',
    ownerCif: '0002901926',
    productId: '151',
    branchId: '40',
    productName: 'Pachet Zero Simplu',
    openingDate: '2005-11-21',
    owner: true,
    olp: false,
    eligibleForFeed: false,
    representative: false,
    overdraftLimit: '4410.00'
  }
];

describe('Accounts Reducer', () => {
  it('[Accounts] undefined action - should return the default state', () => {
    const action = {} as any;
    const state = reducer(initialState, action);

    expect(state).toEqual(initialState);
  });

  it('[Accounts] Load Accounts - should set loading to true', () => {
    const action = fromActions.loadAccounts();
    const state = reducer(initialState, action);

    const newState = {
      ...initialState,
      loading: true
    };

    expect(state.loading).toEqual(true);
    expect(state).toEqual(newState);
  });

  it('[Accounts] Load Accounts Success - should populate items in state, and set loading to false', () => {
    const action = fromActions.loadAccountsSuccess(mockData);
    const state = reducer(initialState, action);

    const newState = {
      ...initialState,
      items: mockData
    };

    expect(state.loading).toEqual(false);
    expect(state.items).toEqual(mockData);
    expect(state).toEqual(newState);
  });

  it('[Accounts] Load Accounts Fail - should set loading to false', () => {
    const action = fromActions.loadAccountsFail();
    const state = reducer(initialState, action);

    const newState = {
      ...initialState,
      loading: false
    };

    expect(state.loading).toEqual(false);
    expect(state).toEqual(newState);
  });
});
