import { Action, createReducer, on } from '@ngrx/store';

import * as fromActions from './accounts.actions';
import * as fromModel from './accounts.model';

import { patchAccounts } from './accounts.helpers';

export const initialState: fromModel.InitialState = {
  items: [],
  loading: false,
  loaded: false,
  selectedItems: []
};

export const reducerFn = createReducer(
  initialState,
  on(fromActions.loadAccountsFail, (state) => ({
    ...state,
    loading: false,
    loaded: false,
    items: []
  })),

  on(fromActions.resetStore, () => ({ ...initialState })),

  on(fromActions.loadAccounts, (state) => ({
    ...state,
    loading: true,
    loaded: false
  })),

  on(fromActions.loadAccountsSuccess, (state, { payload }) => ({
    ...state,
    items: [...state.items, ...payload].map(patchAccounts),
    loading: false,
    loaded: true
  })),

  on(fromActions.addCreditAccounts, (state, { payload }) => {
    return {
      ...state,
      items: [...state.items, ...payload.map(patchAccounts)],
      loading: false,
      loaded: payload.length > 0 ? true : state.loaded
    };
  }),

  on(fromActions.selectAccounts, (state, { payload }) => ({
    ...state,
    selectedItems: payload
  })),

  on(fromActions.getAllAndSetSelected, (state) => ({
    ...state,
    loading: true
  }))
);

export function reducer(
  state: fromModel.InitialState,
  action: Action
): fromModel.InitialState {
  return reducerFn(state, action);
}
