import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromModel from './accounts.model';

export const selectAccountsState = createFeatureSelector<
  fromModel.InitialState
>('accounts');

export const selectItems = createSelector(
  selectAccountsState,
  (state: fromModel.InitialState) => state.items
);

export const selectLoading = createSelector(
  selectAccountsState,
  (state: fromModel.InitialState) => state.loading
);

export const selectLoaded = createSelector(
  selectAccountsState,
  (state: fromModel.InitialState) => state.loaded
);

export const selectedItems = createSelector(
  selectAccountsState,
  (state: fromModel.InitialState) => state.selectedItems
);

export const selectItem = (id: string) =>
  createSelector(
    selectAccountsState,
    (state: fromModel.InitialState) =>
      state.items.filter((item) => item.accountKey === id)
  );
