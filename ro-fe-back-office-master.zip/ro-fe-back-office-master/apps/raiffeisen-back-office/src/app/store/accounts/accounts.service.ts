import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { buildQueryParams, getBaseUrl } from '@utils/helper.functions';

import * as fromModel from './accounts.model';

@Injectable()
export class AccountsService {
  version = 'v1';

  constructor(private readonly http: HttpClient) {}

  loadAccountsApi(): Observable<fromModel.Account[]> {
    const url = `${getBaseUrl()}services/accounts-ws/${
      this.version
    }/accounts/list`;

    const httpParams: HttpParams = buildQueryParams({
      fetchOptions: ['NICKNAME', 'PRODUCT', 'GARNISHMENT_HOLDS']
    });

    return this.http.get<fromModel.Account[]>(url, {
      params: httpParams,
      withCredentials: true
    });
  }
}
