Auth store has 3 actions:

1.  login:

    - from component you will dispatch(using facade) this action with {username, password}
    - in reducer modify the store with loading:true
    - in effects you will do your checks and add the rest of the data from CONSTANTS
    - Success: route the user, emit new action loginSuccess
    - Fail: throw error, emit new action loginFail (you have to keep the observable chain on)

2.  loginSuccess

    - Action emited by login effect on success with the payload response
    - in reducer grab the data and add it into your state
    - in reducer set loading: false

3.  loginFail - in the same catchError function

    - Action emited by login effect on failing with an error message
    - throw the error to ui using error throwing components with translate and other stuff
    - in the reducer set loading: false

4.  checkLoginStatus
    - Action emitted on Init of the app.component
    - in reducer check if the value is set in session and put it to Store if needed.
