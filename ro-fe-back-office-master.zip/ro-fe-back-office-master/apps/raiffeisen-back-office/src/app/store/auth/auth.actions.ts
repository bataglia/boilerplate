import { createAction } from '@ngrx/store';
import * as fromModel from './auth.model';

// Create actions
// Login action will need LoginPostData as a parameter that will come from the template form and extend to full version in effects
export const login = createAction(
  '[Auth] Login',
  (payload: fromModel.LoginPostData) => ({ payload })
);

// LoginSuccess action has a response type of `Observable<HttpResponse<fromModel.AuthData>>` and you need to put | null
// It represends the response data from the http request
export const loginSuccess = createAction(
  '[Auth] Login Success',
  (payload: fromModel.AuthData | null) => ({ payload })
);

// In case the login will fail, this action will return to keep the observable chain going but the effect will manage the error
export const loginFail = createAction(
  '[Auth] Login Fail',
  (payload: string) => ({ payload })
);

// This action check the localStorage to see if the user if logged in and save the value as boolean in Store
export const checkLoginStatus = createAction('[Auth] Check Login Status');

export const resetStore = createAction('[Auth] Reset Store');
