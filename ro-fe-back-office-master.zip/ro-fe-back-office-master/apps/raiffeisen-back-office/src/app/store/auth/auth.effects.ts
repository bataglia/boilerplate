import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Actions, createEffect, ofType } from '@ngrx/effects';

import { of } from 'rxjs';
import { catchError, map, mergeMap, withLatestFrom } from 'rxjs/operators';

import * as fromActions from './auth.actions';
import * as fromModel from './auth.model';
import { AuthService } from './auth.service';

import { ToasterService } from '@rf-shared/components/toaster/toaster.service';

import { CONSTANTS } from '@utils/constants';
import { DynamicLocaleService } from '@utils/dynamic-locale.service';

@Injectable()
export class AuthEffects {
  constructor(
    private readonly $actions: Actions,
    private readonly authService: AuthService,
    private readonly router: Router,
    private readonly localeService: DynamicLocaleService,
    private readonly toaster: ToasterService
  ) {}

  // this effect will run when an action ofType login will run
  // will use mergeMap to get the payload parameter (the one sent from component -> facade ->effect)
  // build the LoginPostData payload and request data from the service(API)
  // Success: map the data, route the user, return loginSuccess action with the response for the reducer to modify the state
  // Fail: catchError, manage error here, return fail action so that the reducer will reflect the fail. (loading:false)
  login$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.login),
      withLatestFrom(this.localeService.locale$),
      map(([payload, language]) => ({ ...payload.payload, language })),
      mergeMap((payload) => {
        const username = payload.username.trim();
        const password = payload.password;

        this.toaster.clear();

        return this.authService
          .loginApi({
            username,
            password,
            channelSubtype: CONSTANTS.CHANNELS.WEB,
            language: payload.language
          })
          .pipe(
            map((data) => {
              this.router.navigate(['/']);
              localStorage.setItem('userProfile', JSON.stringify(data.body));

              return fromActions.loginSuccess(data.body);
            }),
            catchError((err) => {
              const message = this.authService.setErrorMessage(err);

              return of(fromActions.loginFail(message));
            })
          );
      })
    )
  );

  // this effect is triggered when checkLoginStatus runs and send the data in session to loginSuccess action.
  checkLoginStatus$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.checkLoginStatus),
      mergeMap(() => {
        const userProfile = localStorage.getItem('userProfile');

        return of(
          fromActions.loginSuccess(JSON.parse(
            userProfile as string
          ) as fromModel.AuthData)
        );
      })
    )
  );
}
