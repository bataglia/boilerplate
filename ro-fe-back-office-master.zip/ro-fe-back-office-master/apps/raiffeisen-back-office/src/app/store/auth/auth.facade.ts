import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromActions from './auth.actions';
import * as fromModel from './auth.model';
import * as fromSelectors from './auth.selectors';

@Injectable()
export class AuthFacade {
  // create an observable using the selectors
  loading$ = this.store.pipe(select(fromSelectors.selectLoading));

  user$ = this.store.pipe(select(fromSelectors.selectUser));

  isLoggedIn$ = this.store.pipe(select(fromSelectors.selectIsLoggedIn));

  error$ = this.store.pipe(select(fromSelectors.selectError));

  legalEntityName$ = this.store.pipe(
    select(fromSelectors.selectLegalEntityName)
  );

  avatarUrl$ = this.store.pipe(select(fromSelectors.selectAvatarUrl));

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  // dispatch login action with {username,password} LoginPostData has keys,
  // the other 2 will be added into the effect that will run with this action
  login(postData: fromModel.LoginPostData) {
    this.store.dispatch(fromActions.login(postData));
  }

  checkLoginStatus() {
    this.store.dispatch(fromActions.checkLoginStatus());
  }

  resetStore() {
    this.store.dispatch(fromActions.resetStore());
  }
}
