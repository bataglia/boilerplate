export interface InitialState {
  authData: AuthData;
  loading: boolean;
  isLoggedIn: boolean;
  error: string;
}

export interface AuthData {
  user: UserProfile;
  accountsListOrder: number[];
  accountKeysListOrder: string[];
  branchName: string;
  groups: string[];
  hasEMV: boolean;
  hasEtoken:boolean;
  tcUrl: string;
  isLegalEntity: boolean;
  company?: {
    companyName: string;
  };
}

export interface UserProfile {
  id: string;
  avatarName: string;
  avatarUrl: string;
  segmentation: Segmentation;
  phoneNumbers: string[];
  primaryMobilePhone: string;
  cui: string;
  leName: string;
  legalEntitiesContactInfo: LegalEntitiesContactInfo;
}

export interface Segmentation {
  root: string;
  business: string;
  treasury: string;
}

export interface LegalEntitiesContactInfo {
  techSupportPhone: string;
  techSupportEmail: string;
  salesTeamEmail: string;
  businessSegmentation: string;
}

export interface LoginPostData {
  username: string;
  password: string;
  language?: string;
  channelSubtype?: string;
}

// export interface Token {
//     type: string;
//     subType: string;
//     dateCreated: Date;
//     lifetime: number;
//     lastUsed: Date;
//     scope: string;
//   }

//   export interface GrantAttribute {
//     name: string;
//     readonly: boolean;
//     sensitive: boolean;
//     value: string;
//   }

//   export interface Grant {
//     id: string;
//     isEnabled: boolean;
//     clientId: string;
//     tokens: Array<Token>;
//     attributes: Array<GrantAttribute>;
//   }

//   export interface UserData {
//     id: string;
//     avatarName: string;
//     firstName: string;
//     lastName: string;
//     cnp: string;
//     segmentation: {
//       root: string;
//       business: string;
//     };
//     phoneNumbers: Array<string>;
//     primaryMobilePhone: string;
//     email: string;
//   }

//   export interface UserProfile {
//     user: UserData;
//     accountsListOrder: Array<number>;
//     branchName: number;
//     groups: Array<string>;
//     hasEMV: boolean;
//     rcUrl: string;
//     isLegalEntity: boolean;
//     company: {
//       companyName: string;
//     };
//   }

//   export interface LoginPostData {
//     username: string;
//     password: string;
//     language: string;
//     channelSubtype: string;
//   }
