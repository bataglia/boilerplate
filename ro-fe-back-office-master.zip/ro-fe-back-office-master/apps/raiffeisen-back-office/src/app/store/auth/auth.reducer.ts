import { Action, createReducer, on } from '@ngrx/store';

import * as fromActions from './auth.actions';
import * as fromModel from './auth.model';

import { environment } from '@env/environment';

// Define an initial sate of the auth store
export const initialState: fromModel.InitialState = {
  authData: {
    accountKeysListOrder: [],
    accountsListOrder: [],
    branchName: '',
    groups: [],
    hasEMV: false,
    isLegalEntity: false,
    tcUrl: '',
    hasEtoken:false,
    user: {
      avatarName: '',
      avatarUrl: '',
      cui: '',
      id: '',
      leName: '',
      legalEntitiesContactInfo: {
        businessSegmentation: '',
        salesTeamEmail: '',
        techSupportEmail: '',
        techSupportPhone: ''
      },
      phoneNumbers: [],
      primaryMobilePhone: '',
      segmentation: {
        business: '',
        root: '',
        treasury: ''
      }
    }
  },
  loading: false,
  isLoggedIn: false,
  error: ''
};

// general reducer function
export const reducerFn = createReducer(
  // use the state
  initialState,

  // using `on` we can map the actions, grab payloads if any, and return the state
  // on loginFail we will want to set loading to false
  on(fromActions.loginFail, (state, { payload }) => ({
    ...state,
    loading: false,
    isLoggedIn: false,
    error: payload
  })),

  on(fromActions.resetStore, () => ({ ...initialState })),

  // on login we will want to set loading to true to start waiting for the data.
  on(fromActions.login, (state) => ({
    ...state,
    loading: true,
    isLoggedIn: false,
    error: ''
  })),

  // on loginSuccess we got the data from the api and we will add it into our store
  // NOTE, always copy the store using the spread operator before you modity it {...state, `state modifications`}
  on(fromActions.loginSuccess, (state, { payload }) => {
    if (payload !== null) {
      const avatar = payload.user.avatarName;
      if (avatar && avatar.indexOf('http') !== 0) {
        payload.user.avatarName = `${environment.protocol}://${environment.basePath}/services/userprofile-ws/v1/user/avatar/${payload.user.avatarName}`;
      }
    }

    return {
      ...state,
      authData: payload !== null ? payload : initialState.authData,
      loading: false,
      isLoggedIn: payload !== null,
      error: ''
    };
  })
);

// general reducer function
export function reducer(
  state: fromModel.InitialState,
  action: Action
): fromModel.InitialState {
  return reducerFn(state, action);
}
