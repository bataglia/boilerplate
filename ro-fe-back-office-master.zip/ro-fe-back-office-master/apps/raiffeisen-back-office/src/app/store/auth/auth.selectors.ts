import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromModel from './auth.model';

// create a state from where to select, this key is defined in the module.
export const selectAuthState = createFeatureSelector<fromModel.InitialState>(
  'auth'
);

// select slices of the store to be used in facade to expose elements as observables
export const selectAuthData = createSelector(
  selectAuthState,
  (state: fromModel.InitialState) => state.authData
);

export const selectLoading = createSelector(
  selectAuthState,
  (state: fromModel.InitialState) => state.loading
);

export const selectUser = createSelector(
  selectAuthState,
  (state: fromModel.InitialState) => state.authData.user
);

export const selectIsLoggedIn = createSelector(
  selectAuthState,
  (state: fromModel.InitialState) => state.isLoggedIn
);

export const selectError = createSelector(
  selectAuthState,
  (state: fromModel.InitialState) => state.error
);

export const selectLegalEntityName = createSelector(
  selectAuthState,
  (state: fromModel.InitialState) => state.authData.user.leName
);

export const selectAvatarUrl = createSelector(
  selectAuthState,
  (state: fromModel.InitialState) => state.authData.user.avatarName
);
