import {
  HttpClient,
  HttpErrorResponse,
  HttpResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { getBaseUrl } from '@utils/helper.functions';
import * as fromModel from './auth.model';

@Injectable()
export class AuthService {
  version = 'v2';

  constructor(private readonly http: HttpClient) {}

  loginApi(
    loginData: fromModel.LoginPostData
  ): Observable<HttpResponse<fromModel.AuthData>> {
    const uri = `${getBaseUrl()}services/auth/${this.version}/login`;

    return this.http.post<fromModel.AuthData>(uri, loginData, {
      withCredentials: true,
      observe: 'response'
    });
  }

  setErrorMessage(error: HttpErrorResponse) {
    let message = 'login__errors__timeout';

    if (error.status === 401) {
      switch (error.error.message) {
        case 'AUTHERR00':
          message = 'login__errors__invalid_credentials';
          break;
        case 'AUTHERR01':
          message = 'login__errors__ro_not_active';
          break;
        case 'AUTHERR03':
          message = 'login__errors__blocked_user';
          break;
        case 'AUTHERR05':
          message = 'login__errors__restricted_access';
          break;
        case 'AUTHERR06':
          message = 'login__errors__tc_agreed';
          break;
        default:
          message = 'login__errors__invalid_credentials';
          break;
      }
    } else if (error.status === 400) {
      switch (error.error.message) {
        case 'AUTHERR08':
          message = 'login__errors__username_unavailable';
          break;
        case 'AUTHERR11':
          message = 'login__errors__invalid_username';
          break;
        default:
          message = 'login__errors__invalid_credentials';
          break;
      }
    }

    return message;
  }
}

// Does not exist on backend: AUTHERR11
// Exist on backend - 401: 05, 07, 14, 04, 02 (AUTHERR{#})
// Exist on backend - 400: 13
