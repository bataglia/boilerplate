import { createAction } from '@ngrx/store';

import * as fromModel from './cards.model';

export const loadCreditCards = createAction('[Cards] Load Credit Cards');

export const loadCreditCardsSuccess = createAction(
  '[Cards] Load Credit Cards Success',
  (payload: fromModel.CardData[]) => ({ payload })
);

export const loadCreditCardsFail = createAction(
  '[Cards] Load Credit Cards Fail'
);

export const loadDebitCardsWithParams = createAction(
  '[Cards] Load Debit Cards With Params',
  (payload: string | null) => ({ payload })
);

export const loadDebitCardsWithParamsSuccess = createAction(
  '[Cards] Load Debit Cards With Params Success',
  (payload: { data: fromModel.CardData[]; cursor: boolean }) => ({ payload })
);

export const loadDebitCardsWithParamsFail = createAction(
  '[Cards] Load Debit Cards With Params Fail'
);

export const resetStore = createAction('[Cards] Reset Store');

export const loadRawCreditData = createAction(
  '[Cards] Load Raw Credit Data',
  (payload: fromModel.CreditCardData[]) => ({ payload })
);
