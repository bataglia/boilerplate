import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';

import { of } from 'rxjs';
import { catchError, map, mergeMap, withLatestFrom } from 'rxjs/operators';

import { ToasterService } from '@rf-shared/components/toaster/toaster.service';
import { AccountsFacade } from '@rf-store/accounts/accounts.facade';

import * as fromActions from './cards.actions';
import * as fromModel from './cards.model';

import { CardsService } from './cards.service';

@Injectable()
export class CardsEffects {
  constructor(
    private readonly $actions: Actions,
    private readonly cardsService: CardsService,
    private readonly toasterService: ToasterService,
    private readonly store: Store<fromModel.InitialState>,
    private readonly accountsFacade: AccountsFacade
  ) {}

  loadCreditCards$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.loadCreditCards),
      mergeMap(() =>
        this.cardsService.loadCreditCardsApi().pipe(
          withLatestFrom(this.accountsFacade.items$),
          map(([cards, accounts]) => {
            if (accounts.length > 0) {
              const {
                cardsData,
                accountsData
              } = this.cardsService.processResponse(cards, accounts);

              this.accountsFacade.addCreditAccounts(accountsData);

              return fromActions.loadCreditCardsSuccess(cardsData);
            } else {
              return fromActions.loadRawCreditData(cards);
            }
          }),
          catchError(() => {
            this.toasterService.error('new_products__errors__account_type');

            return of(fromActions.loadCreditCardsFail());
          })
        )
      )
    )
  );

  loadDebitCardsWithParams$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.loadDebitCardsWithParams),
      mergeMap((payload) =>
        this.cardsService.loadDebitCardsWithParamsApi(payload.payload).pipe(
          map((data) => {
            const cursor = data.cursor !== undefined;

            if (cursor) {
              this.store.dispatch(
                fromActions.loadDebitCardsWithParams(data.cursor)
              );
            }

            return fromActions.loadDebitCardsWithParamsSuccess({
              data: data.list,
              cursor
            });
          }),
          catchError(() => {
            this.toasterService.error('new_products__errors__account_type');

            return of(fromActions.loadDebitCardsWithParamsFail());
          })
        )
      )
    )
  );
}
