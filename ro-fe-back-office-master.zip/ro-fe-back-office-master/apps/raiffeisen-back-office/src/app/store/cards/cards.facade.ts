import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromActions from './cards.actions';
import * as fromModel from './cards.model';
import * as fromSelectors from './cards.selectors';

@Injectable()
export class CardsFacade {
  items$ = this.store.pipe(select(fromSelectors.selectCards));

  loading$ = this.store.pipe(select(fromSelectors.selectLoading));

  creditCards$ = this.store.pipe(select(fromSelectors.selectCreditCards));

  debitCards$ = this.store.pipe(select(fromSelectors.selectCreditCards));

  rawCredit$ = this.store.pipe(select(fromSelectors.selectRawCredit));

  loadedCredit$ = this.store.pipe(select(fromSelectors.selectLoadedCredit));

  loadedDebit$ = this.store.pipe(select(fromSelectors.selectLoadedDebit));

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  loadCreditCards() {
    this.store.dispatch(fromActions.loadCreditCards());
  }

  loadCreditCardsSuccess(data: fromModel.CardData[]) {
    this.store.dispatch(fromActions.loadCreditCardsSuccess(data));
  }

  loadDebitCards() {
    this.store.dispatch(fromActions.loadDebitCardsWithParams(null));
  }

  resetStore() {
    this.store.dispatch(fromActions.resetStore());
  }
}
