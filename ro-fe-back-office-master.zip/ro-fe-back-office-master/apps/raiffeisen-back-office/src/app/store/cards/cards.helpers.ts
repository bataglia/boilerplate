export const getMinDisplayLen = () => (window.innerWidth > 767 ? 7 : 6);
