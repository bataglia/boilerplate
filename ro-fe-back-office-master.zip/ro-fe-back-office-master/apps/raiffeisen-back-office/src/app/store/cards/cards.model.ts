export interface InitialState {
  items: CardData[];
  credit: CardData[];
  debit: CardData[];
  rawCredit: CreditCardData[];
  loading: boolean;
  loadingDebit: boolean;
  loadingCredit: boolean;
  loadedDebit: boolean;
  loadedCredit: boolean;
}

export interface CardData {
  accountId: string;
  accountNickName: string;
  accountType: string;
  assetId: string;
  cardDescription: string;
  cardDRSCode: string;
  cardDRSName: string;
  cardProductCode: string;
  cardId: string;
  cardImageUrl: string;
  cardNumber: string;
  cardRank: string;
  cardType: string;
  cardStatus: string;
  currency: string;
  iban: string;
  mainCard: boolean;
  companyName: string;
  embossName: string;
  expirationDate: string;
  expirationDateDisplay?: string;
  blockAndReissue?: boolean;
}

export interface CreditCardData {
  accountId: string;
  accountType: string;
  cardType: string;
  clientType: string;
  iban: string;
  creditCardAccountList: CreditCardAccountList[];
}

export interface CreditCardAccountList {
  accountKey: string;
  ccAccountId: string;
  ccAccountStatus: string;
  ccBranchId: string;
  ccCreditLimit: number;
  ccCurrentBalance: number;
  ccCurrentBranchId: string;
  ccDateApproved: string;
  ccDirectDebitAmount: number;
  ccDirectDebitSourceAccount: string;
  ccDirectDebitType: number;
  ccHasDirectDebit: boolean;
  ccInterestPercent: number;
  ccLastPaymentAmount: number;
  ccLastStatementBalance: number;
  ccLastStatementImported: boolean;
  ccMinimumPaymentAmount: number;
  ccNextClosingDate: string;
  ccNextDirectDebitDate: string;
  ccNextPaymentDate: string;
  ccPeriod: string;
  ccPeriodEnd: string;
  ccPeriodStart: string;
  ccProductId: string;
  cccanCardNumber: string;
  creditCardList: CreditCardList[];
  currency: string;
  nickname: string;
  // adding from Account
  balance: number;
  branchId: string;
  eligibleForFeed: boolean;
  iban: string;
  id: string;
  interestRate?: string;
  maturityDate?: string;
  olp: boolean;
  openingDate: string;
  overdraftLimit?: string;
  owner: boolean;
  ownerCif: string;
  productId: string;
  productName: string;
  representative: boolean;
  status: string;
  typeId: string;
}

export interface Account {
  creditCardList?: CreditCardList[];
  cardsData?: CardData[];
  accountKey: string;
  balance: number;
  branchId: string;
  currency: string;
  eligibleForFeed: boolean;
  iban: string;
  id: string;
  interestRate?: string;
  nickname?: string;
  maturityDate?: string;
  olp: boolean;
  openingDate: string;
  overdraftLimit?: string;
  owner: boolean;
  ownerCif: string;
  productId: string;
  productName: string;
  representative: boolean;
  status: string;
  typeId: string;
}

export interface CreditCardList {
  blockAndReissue: boolean;
  cardDescription: string;
  cardId: string;
  cardImageUrl: string;
  cardNumber: string;
  cardStatus: string;
  cardStatusDescription: string;
  ccCardCurrency: string;
  ccProductName: string;
  embossName: string;
  expirationDate: string;
  mainCard: boolean;
  // adding from CardData
  cardDRSCode: string;
  cardDRSName: string;
}

export interface DebitApiResponse {
  cursor: string;
  list: CardData[];
}
