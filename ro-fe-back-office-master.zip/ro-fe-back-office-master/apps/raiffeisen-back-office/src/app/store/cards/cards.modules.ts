import { NgModule } from '@angular/core';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { CardsEffects } from './cards.effects';
import { CardsFacade } from './cards.facade';
import { reducer } from './cards.reducer';
import { CardsService } from './cards.service';

@NgModule({
  imports: [
    StoreModule.forFeature('cards', reducer),
    EffectsModule.forFeature([CardsEffects])
  ],
  providers: [CardsService, CardsFacade]
})
export class CardsStateModule {}
