import { Action, createReducer, on } from '@ngrx/store';

import * as fromActions from './cards.actions';
import * as fromModel from './cards.model';

import { getMinDisplayLen } from './cards.helpers';

export const initialState: fromModel.InitialState = {
  items: [],
  credit: [],
  debit: [],
  rawCredit: [],
  loading: false,
  loadingCredit: false,
  loadingDebit: false,
  loadedCredit: false,
  loadedDebit: false
};

export const reducerFn = createReducer(
  initialState,

  on(fromActions.resetStore, () => ({ ...initialState })),

  on(fromActions.loadCreditCardsFail, (state) => ({
    ...state,
    loading: state.loadingDebit === true ? true : false,
    loadingCredit: false,
    loadedCredit: false,
    credit: []
  })),

  on(fromActions.loadRawCreditData, (state, { payload }) => ({
    ...state,
    rawCredit: payload,
    loading: state.loadingDebit === true ? true : false,
    loadingCredit: false
  })),

  on(fromActions.loadDebitCardsWithParamsFail, (state) => ({
    ...state,
    loading: state.loadingCredit === true ? true : false,
    loadingDebit: false,
    loadedDebit: false,
    debit: []
  })),

  on(fromActions.loadCreditCards, (state) => ({
    ...state,
    loading: true,
    loadingCredit: true,
    loadedCredit: false
  })),

  on(fromActions.loadDebitCardsWithParams, (state) => ({
    ...state,
    loading: true,
    loadingDebit: true,
    loadedDebit: false
  })),

  on(fromActions.loadCreditCardsSuccess, (state, { payload }) => {
    const items = [...state.debit, ...payload, ...state.credit].filter(
      (item) => item.cardStatus === 'Active'
    );

    const loading =
      items.length > getMinDisplayLen()
        ? false
        : state.loadingDebit
        ? true
        : false;

    return {
      ...state,
      credit: [...state.credit, ...payload],
      items,
      loadingCredit: false,
      loadedCredit: true,
      loading
    };
  }),

  on(fromActions.loadDebitCardsWithParamsSuccess, (state, { payload }) => {
    const items = [...state.debit, ...payload.data, ...state.credit].filter(
      (item) => item.cardStatus === 'Active'
    );

    const loading =
      items.length > getMinDisplayLen()
        ? false
        : state.loadingCredit
        ? true
        : payload.cursor
        ? true
        : false;

    return {
      ...state,
      debit: [...state.debit, ...payload.data],
      items,
      loadingDebit: payload.cursor,
      loadedDebit: !payload.cursor,
      loading
    };
  })
);

export function reducer(
  state: fromModel.InitialState,
  action: Action
): fromModel.InitialState {
  return reducerFn(state, action);
}
