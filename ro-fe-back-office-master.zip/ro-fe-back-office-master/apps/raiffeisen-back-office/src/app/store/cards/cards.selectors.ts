import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromModel from './cards.model';

export const selectCardsState = createFeatureSelector<fromModel.InitialState>(
  'cards'
);

export const selectCards = createSelector(
  selectCardsState,
  (state: fromModel.InitialState) => state.items
);

export const selectCreditCards = createSelector(
  selectCardsState,
  (state: fromModel.InitialState) => state.items
);

export const selectDebitCards = createSelector(
  selectCardsState,
  (state: fromModel.InitialState) => state.items
);

export const selectLoading = createSelector(
  selectCardsState,
  (state: fromModel.InitialState) => state.loading
);

export const selectRawCredit = createSelector(
  selectCardsState,
  (state: fromModel.InitialState) => state.rawCredit
);

export const selectLoadedCredit = createSelector(
  selectCardsState,
  (state: fromModel.InitialState) => state.loadedCredit
);

export const selectLoadedDebit = createSelector(
  selectCardsState,
  (state: fromModel.InitialState) => state.loadedDebit
);
