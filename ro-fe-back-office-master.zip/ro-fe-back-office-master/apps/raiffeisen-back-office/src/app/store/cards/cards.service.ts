import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { buildQueryParams, getBaseUrl } from '@utils/helper.functions';

import * as fromModel from './cards.model';

import { CONSTANTS } from '@utils/constants';

@Injectable()
export class CardsService {
  version = 'v3';

  constructor(private readonly http: HttpClient) {}

  loadCreditCardsApi(): Observable<fromModel.CreditCardData[]> {
    const url = `${getBaseUrl()}services/cards-ws/${this.version}/cards/credit`;

    return this.http.get<fromModel.CreditCardData[]>(url, {
      withCredentials: true
    });
  }

  loadDebitCardsWithParamsApi(
    param: string | null
  ): Observable<fromModel.DebitApiResponse> {
    const url = `${getBaseUrl()}services/cards-ws/${this.version}/cards/debit`;

    const options: { params?: HttpParams; withCredentials: boolean } = {
      withCredentials: true
    };

    if (param !== null) {
      options.params = buildQueryParams({
        cursor: param
      });
    }

    return this.http.get<fromModel.DebitApiResponse>(url, options);
  }

  createCreditAccount(
    creditCardAccount: fromModel.CreditCardAccountList
  ): fromModel.Account {
    return {
      id: creditCardAccount.id,
      accountKey: creditCardAccount.accountKey,
      balance: creditCardAccount.ccCurrentBalance,
      branchId: creditCardAccount.branchId,
      currency: creditCardAccount.currency,
      eligibleForFeed: creditCardAccount.eligibleForFeed,
      iban: creditCardAccount.iban,
      interestRate: creditCardAccount.interestRate,
      maturityDate: creditCardAccount.maturityDate,
      nickname: creditCardAccount.nickname,
      olp: creditCardAccount.olp,
      openingDate: creditCardAccount.openingDate,
      overdraftLimit: creditCardAccount.overdraftLimit,
      owner: creditCardAccount.owner,
      ownerCif: creditCardAccount.ownerCif,
      productId: creditCardAccount.productId,
      productName: creditCardAccount.productName,
      representative: creditCardAccount.representative,
      status: creditCardAccount.status,
      typeId: creditCardAccount.typeId,
      creditCardList: creditCardAccount.creditCardList
    };
  }

  createCreditCard(
    account: fromModel.Account,
    availableAccounts: fromModel.CreditCardData,
    creditCard: fromModel.CreditCardList
  ): fromModel.CardData {
    return {
      accountId: account.id,
      accountNickName: account.nickname || '',
      accountType: availableAccounts.accountType,
      assetId: '',
      blockAndReissue: creditCard.blockAndReissue,
      cardDRSCode: creditCard.cardDRSCode,
      cardDRSName: creditCard.cardDRSName,
      cardDescription: creditCard.cardDescription,
      cardId: creditCard.cardId,
      cardImageUrl: creditCard.cardImageUrl,
      cardNumber: creditCard.cardNumber,
      cardProductCode: '',
      cardRank: '',
      cardStatus: creditCard.cardStatus,
      cardType: availableAccounts.accountType,
      companyName: '',
      currency: creditCard.ccCardCurrency,
      embossName: creditCard.embossName,
      expirationDate: creditCard.expirationDate,
      expirationDateDisplay: creditCard.expirationDate,
      iban: availableAccounts.iban,
      mainCard: creditCard.mainCard
    };
  }

  processAvailableAccounts(
    availableAccounts: fromModel.CreditCardData,
    account: fromModel.Account
  ) {
    return availableAccounts.creditCardAccountList.map(
      (creditCardAccountRaw) => {
        const { accountKey, nickname } = creditCardAccountRaw;

        const creditCardAccount = {
          ...creditCardAccountRaw,
          ...account,
          accountKey,
          nickname
        };

        const creditAccount: fromModel.Account = this.createCreditAccount(
          creditCardAccount
        );

        creditAccount.cardsData = creditCardAccount.creditCardList.map(
          (creditCard) => {
            const card: fromModel.CardData = this.createCreditCard(
              account,
              availableAccounts,
              creditCard
            );

            return card;
          }
        );

        return creditAccount;
      }
    );
  }

  processResponse(
    cards: fromModel.CreditCardData[],
    accounts: fromModel.Account[]
  ): { cardsData: fromModel.CardData[]; accountsData: fromModel.Account[] } {
    const accountsDataRaw = accounts
      .filter(
        (account) =>
          account.typeId === CONSTANTS.ACCOUNT.TYPE.CURRENT &&
          account.productId === CONSTANTS.PRODUCT.IDS.CREDIT_CARD
      )
      .map((account) => {
        const availableAccounts = cards.find(
          (card) =>
            card.accountId === account.id && card.accountType === account.typeId
        );

        if (availableAccounts) {
          return this.processAvailableAccounts(availableAccounts, account);
        }

        return [];
      });

    const accountsData = [].concat.apply([], accountsDataRaw as [

    ]) as fromModel.Account[];

    const cardsData: fromModel.CardData[] = accountsData.reduce(
      (acc, curr) => {
        let result = [...acc];
        if (curr.cardsData) {
          result = [...result, ...curr.cardsData];
        }

        return result;
      },
      [] as fromModel.CardData[]
    );

    return {
      accountsData,
      cardsData
    };
  }
}
