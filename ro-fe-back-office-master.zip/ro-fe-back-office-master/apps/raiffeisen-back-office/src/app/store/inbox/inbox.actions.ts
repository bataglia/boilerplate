import { createAction } from '@ngrx/store';
import * as fromModel from './inbox.model';

export const downloadMessageWithId = createAction(
  '[Inbox] Download Message With Id',
  (payload: number) => ({ payload })
);

export const downloadMessageWithIdSuccess = createAction(
  '[Inbox] Download Message With Id Success'
);

export const downloadMessageWithIdFail = createAction(
  '[Inbox] Download Message With Id Fail'
);

export const getTotal = createAction(
  '[Inbox] Total Unread',
  (payload: string) => ({ payload })
);

export const getTotalSuccess = createAction(
  '[Inbox] Total Unread Success',
  (payload: fromModel.InitialState) => ({ payload })
);

export const getTotalFail = createAction('[Inbox] Total Unread Fail');

export const getMessages = createAction(
  '[Inbox] Get Messages',
  (payload?: number) => ({ payload })
);

export const getMessagesSuccess = createAction(
  '[Inbox] Get Messages Success',
  (payload: fromModel.ParsedMessageResponse) => ({ payload })
);

export const getMessagesFail = createAction('[Inbox] Get Messages Fail');

export const resetStore = createAction('[Inbox] Reset Store');

export const getMessageWithId = createAction(
  '[Inbox] Get Message With Id',
  (payload: number) => ({ payload })
);

export const getMessageWithIdSuccess = createAction(
  '[Inbox] Get Message With Id Success',
  (payload: fromModel.Message) => ({ payload })
);

export const getMessageWithIdFail = createAction(
  '[Inbox] Get Message With Id Fail'
);

export const markMessageAsRead = createAction(
  '[Inbox] Mark Message As Read',
  (payload: number) => ({ payload })
);
