import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { ToasterService } from '@rf-shared/components/toaster/toaster.service';
import { InboxService } from '@rf-store/inbox/inbox.service';
import * as moment from 'moment';
import { EMPTY, of } from 'rxjs';
import {
  catchError,
  finalize,
  map,
  mergeMap,
  switchMap,
  withLatestFrom
} from 'rxjs/operators';

import { InboxFacade } from '@rf-store/inbox/inbox.facade';
import * as fromActions from './inbox.actions';
import { saveAs } from '@utils/helper.functions';

@Injectable()
export class InboxEffects {
  getTotal$ = createEffect(() =>
    this.actions.pipe(
      ofType(fromActions.getTotal),
      mergeMap(({ type, payload }) => {
        return this.inboxService.getUnreadMessagesApi(payload).pipe(
          map((data) => {
            return fromActions.getTotalSuccess(data);
          }),
          catchError((err) => of(fromActions.getTotalFail()))
        );
      })
    )
  );

  getMessages$ = createEffect(() =>
    this.actions.pipe(
      ofType(fromActions.getMessages),
      withLatestFrom(this.inboxFacade.pageResponseCursor$),
      mergeMap(([action, payload]) => {
        return this.inboxService.getMessagesApi(payload).pipe(
          map((data) => {
            const result = this.inboxService.sortAndFormatMessages(data);

            let noMoreMessagesLabel = '';

            if (!result.cursor && result.records.length === 0) {
              noMoreMessagesLabel = 'inbox__labels__no_more_messages';
            }

            return fromActions.getMessagesSuccess({
              cursor: (Number(payload) + 1).toString(),
              messages: result.records,
              noMoreMessagesLabel
            });
          }),
          catchError(() => {
            this.toasterService.error(
              'active_payments__labels__response_timeout'
            );

            return of(fromActions.getMessagesFail());
          }),
          finalize(() => {
            if (action.payload) {
              this.inboxFacade.getMessageWithId(action.payload);
            }
          })
        );
      })
    )
  );

  getMessageWithId$ = createEffect(() =>
    this.actions.pipe(
      ofType(fromActions.getMessageWithId),
      withLatestFrom(this.inboxFacade.pagedResponseMessages$),
      map(([{ payload }, messages]) => ({ payload, messages })),
      mergeMap(({ payload, messages }) => {
        if (messages.length === 0) {
          return of(fromActions.getMessages(payload));
        }

        return this.inboxService.getMessageApi(payload).pipe(
          switchMap((data) => {
            if (data.status === 'NEW') {
              return [
                fromActions.getMessageWithIdSuccess(data),
                fromActions.markMessageAsRead(payload)
              ];
            }

            return of(fromActions.getMessageWithIdSuccess(data));
          }),
          catchError(() => {
            this.toasterService.error(
              'active_payments__labels__response_timeout'
            );

            return of(fromActions.getMessageWithIdFail());
          })
        );
      })
    )
  );

  markMessageAsRead$ = createEffect(() =>
    this.actions.pipe(
      ofType(fromActions.markMessageAsRead),
      mergeMap(({ payload }) =>
        this.inboxService.markAsReadApi(payload).pipe(
          map(() => fromActions.getTotal('NEW')),
          catchError(() => {
            this.toasterService.error(
              'active_payments__labels__response_timeout'
            );

            return EMPTY;
          })
        )
      )
    )
  );

  downloadMessageWithId$ = createEffect(() =>
    this.actions.pipe(
      ofType(fromActions.downloadMessageWithId),
      mergeMap(({ type, payload }) =>
        this.inboxService.downloadMessageApi(payload).pipe(
          map((resp) => {
            saveAs(resp, '');

            return fromActions.downloadMessageWithIdSuccess();
          }),
          catchError(() => {
            this.toasterService.error(
              'active_payments__labels__response_timeout'
            );

            return of(fromActions.downloadMessageWithIdFail());
          })
        )
      )
    )
  );

  constructor(
    private readonly actions: Actions,
    private readonly inboxService: InboxService,
    private readonly toasterService: ToasterService,
    private readonly inboxFacade: InboxFacade
  ) {}
}
