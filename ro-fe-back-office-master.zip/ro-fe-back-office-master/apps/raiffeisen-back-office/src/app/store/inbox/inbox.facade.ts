import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromActions from './inbox.actions';
import * as fromModel from './inbox.model';
import * as fromSelectors from './inbox.selectors';

@Injectable()
export class InboxFacade {
  total$ = this.store.pipe(select(fromSelectors.selectTotal));

  pagedResponse$ = this.store.pipe(select(fromSelectors.selectPagedResponse));

  loading$ = this.store.pipe(select(fromSelectors.selectLoading));

  pagedResponseNoMoreMessagesLabel$ = this.store.pipe(
    select(fromSelectors.selectPagedResponseNoMoreMessagesLabel)
  );

  pageResponseCursor$ = this.store.pipe(
    select(fromSelectors.selectPageResponseCursor)
  );

  pagedResponseMessages$ = this.store.pipe(
    select(fromSelectors.selectPagedResponseMessages)
  );

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  pagedResponseMesageWithId(id: number) {
    return this.store.pipe(
      select(fromSelectors.selectPagedResponseMessageWithId(id))
    );
  }

  getTotal() {
    this.store.dispatch(fromActions.getTotal('NEW'));
  }

  getMessages(payload?: number) {
    this.store.dispatch(fromActions.getMessages(payload));
  }

  resetStore() {
    this.store.dispatch(fromActions.resetStore());
  }

  getMessageWithId(id: number) {
    this.store.dispatch(fromActions.getMessageWithId(id));
  }

  downloadMessageWithId(id: number) {
    this.store.dispatch(fromActions.downloadMessageWithId(id));
  }
}
