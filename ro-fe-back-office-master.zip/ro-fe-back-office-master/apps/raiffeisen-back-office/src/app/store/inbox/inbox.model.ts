export interface InitialState {
  loading: boolean;
  total: number;
  pagedResponse: ParsedMessageResponse;
}

export interface Message {
  id: number;
  subject: string;
  preview: string;
  createdAt: string;
  hasAttachments: boolean;
  status: string;
  month?: number;
  date?: string;
  attachments?: Attachment[];
  body?: string;
}

export interface Attachment {
  id: number;
  name: string;
  mimeType: string;
  size: number;
}

export interface InboxMessageResponse {
  cursor: string;
  records: Message[];
}

export interface ParsedMessageResponse {
  cursor: string;
  messages: Message[];
  noMoreMessagesLabel: string;
}

export interface PostData {
  status?: string;
  cursor?: number;
}
