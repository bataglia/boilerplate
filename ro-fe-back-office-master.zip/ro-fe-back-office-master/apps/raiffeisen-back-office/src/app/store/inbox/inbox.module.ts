import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { InboxEffects } from '@rf-store/inbox/inbox.effects';
import { InboxFacade } from '@rf-store/inbox/inbox.facade';
import { InboxService } from '@rf-store/inbox/inbox.service';
import { reducer } from './inbox.reducer';

@NgModule({
  imports: [
    StoreModule.forFeature('inbox', reducer),
    EffectsModule.forFeature([InboxEffects])
  ],
  providers: [InboxService, InboxFacade]
})
export class InboxModule {}
