import { Action, createReducer, on } from '@ngrx/store';
import * as fromActions from './inbox.actions';
import * as inboxModel from './inbox.model';

export const initialState: inboxModel.InitialState = {
  loading: false,

  total: 0,

  pagedResponse: {
    cursor: '',
    messages: [],
    noMoreMessagesLabel: ''
  }
};

export const reducerFn = createReducer(
  initialState,

  on(fromActions.getTotalSuccess, (state, { payload }) => ({
    ...state,
    ...payload
  })),

  on(fromActions.resetStore, (state) => ({
    ...state,
    pagedResponse: initialState.pagedResponse
  })),

  on(fromActions.getTotalFail, (state) => ({ ...state })),

  on(fromActions.getMessages, (state) => ({
    ...state,
    loading: true
  })),

  on(fromActions.getMessagesFail, (state) => ({
    ...state,
    loading: false,
    pagedResponse: {
      ...state.pagedResponse,
      noMoreMessagesLabel: 'inbox__labels__no_messages'
    }
  })),

  on(fromActions.getMessagesSuccess, (state, { payload }) => ({
    ...state,
    pagedResponse: {
      cursor: payload.cursor,
      messages: [...state.pagedResponse.messages, ...payload.messages],
      noMoreMessagesLabel: payload.noMoreMessagesLabel
    },
    loading: false
  })),

  on(fromActions.getMessageWithId, (state) => ({ ...state })),

  on(fromActions.getMessageWithIdSuccess, (state, { payload }) => {
    const messages = state.pagedResponse.messages.map((msg) => {
      if (msg.id === payload.id) {
        return {
          ...msg,
          ...payload
        };
      }

      return msg;
    });

    return {
      ...state,
      pagedResponse: {
        ...state.pagedResponse,
        messages
      }
    };
  })
);

export function reducer(
  state: inboxModel.InitialState,
  action: Action
): inboxModel.InitialState {
  return reducerFn(state, action);
}
