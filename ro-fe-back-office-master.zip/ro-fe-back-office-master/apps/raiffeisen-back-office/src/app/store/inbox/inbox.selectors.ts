import { createFeatureSelector, createSelector, props } from '@ngrx/store';
import * as fromModel from '@rf-store/inbox/inbox.model';

export const selectInboxState = createFeatureSelector<fromModel.InitialState>(
  'inbox'
);

export const selectTotal = createSelector(
  selectInboxState,
  (state: fromModel.InitialState) => state.total
);

export const selectPagedResponse = createSelector(
  selectInboxState,
  (state: fromModel.InitialState) => state.pagedResponse
);

export const selectLoading = createSelector(
  selectInboxState,
  (state: fromModel.InitialState) => state.loading
);

export const selectPagedResponseNoMoreMessagesLabel = createSelector(
  selectInboxState,
  (state: fromModel.InitialState) => state.pagedResponse.noMoreMessagesLabel
);

export const selectPageResponseCursor = createSelector(
  selectInboxState,
  (state: fromModel.InitialState) => state.pagedResponse.cursor
);

export const selectPagedResponseMessages = createSelector(
  selectInboxState,
  (state: fromModel.InitialState) => state.pagedResponse.messages
);

export const selectPagedResponseMessageWithId = (id: number) =>
  createSelector(selectInboxState, (state) => {
    const matching = state.pagedResponse.messages.filter(
      (msg) => msg.id === id
    );
    if (matching.length) {
      return matching[0];
    }

    return null;
  });
