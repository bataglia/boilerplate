import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { getBaseUrl } from '@utils/helper.functions';
import { Observable } from 'rxjs';
import * as fromModel from './inbox.model';
import * as moment from 'moment';

@Injectable()
export class InboxService {
  version = 'v1';

  constructor(private readonly http: HttpClient) {}

  getUnreadMessagesApi(status = 'NEW'): Observable<fromModel.InitialState> {
    const uri = `${getBaseUrl()}services/inbox-service/${
      this.version
    }/messages/count?status=${status}`;

    return this.http.get<fromModel.InitialState>(uri, {
      withCredentials: true
    });
  }

  getMessagesApi(cursor: string): Observable<fromModel.InboxMessageResponse> {
    const uri = `${getBaseUrl()}services/inbox-service/${
      this.version
    }/messages/list?cursor=${cursor}`;

    return this.http.get<fromModel.InboxMessageResponse>(uri, {
      withCredentials: true
    });
  }

  getMessageApi(id: number): Observable<fromModel.Message> {
    const uri = `${getBaseUrl()}services/inbox-service/${
      this.version
    }/messages/${id}`;

    return this.http.get<fromModel.Message>(uri, {
      withCredentials: true
    });
  }

  downloadMessageApi(id: number): Observable<Blob> {
    const uri = `${getBaseUrl()}services/inbox-service/${
      this.version
    }/attachments/${id}/download`;

    return this.http.get(uri, {
      withCredentials: true,
      responseType: 'blob'
    });
  }

  markAsReadApi(id: number) {
    const uri = `${getBaseUrl()}services/inbox-service/${
      this.version
    }/messages/${id}/mark-as-read`;

    return this.http.post(uri, {}, { withCredentials: true });
  }

  sortAndFormatMessages(data: fromModel.InboxMessageResponse) {
    data.records.sort((a, b) => {
      return (
        moment(b.createdAt)
          .toDate()
          .getTime() -
        moment(a.createdAt)
          .toDate()
          .getTime()
      );
    });

    data.records = data.records.map((el) => ({
      ...el,
      date: moment(el.createdAt).format('YYYY-MMM')
    }));

    return data;
  }
}
