import { createAction } from '@ngrx/store';

import * as moment from 'moment';

import * as fromModel from './payments.model';

/**
 * Creating actions for every form from the payments module
 * And the actions for the API requests.
 */

export const loadEligibleStandardPayment = createAction(
  '[Payments] Load Eligible Standard Payment'
);

export const loadEligibleStandardPaymentSuccess = createAction(
  '[Payments] Load Eligible Standard Payment Success',
  (payload: fromModel.Account[]) => ({ payload })
);

export const loadEligibleStandardPaymentFail = createAction(
  '[Payments] Load Eligible Standard Payment Fail'
);

export const loadEligibleStandardPaymentWithQueryParams = createAction(
  '[Payments] Load Eligible Standard Payment With Query Params'
);

export const loadEligibleStandardPaymentWithQueryParamsSuccess = createAction(
  '[Payments] Load Eligible Standard Payment With Query Params Success',
  (payload: fromModel.Account[]) => ({ payload })
);

export const loadEligibleStandardPaymentWithQueryParamsFail = createAction(
  '[Payments] Load Eligible Standard Payment With Query Params Fail'
);

export const selectFromAccount = createAction(
  '[Payments] Select From Account',
  (payload: fromModel.Account) => ({ payload })
);

export const selectFromAccountSuccess = createAction(
  '[Payments] Select From Account Success',
  (payload: fromModel.Account) => ({ payload })
);

export const selectFromAccountFail = createAction(
  '[Payments] Select From Account Fail'
);

export const selectToAccount = createAction(
  '[Payments] Select To Account',
  (payload: fromModel.Account) => ({ payload })
);

export const selectToAccountSuccess = createAction(
  '[Payments] Select To Account Success',
  (payload: fromModel.Account) => ({ payload })
);

export const resetToAccount = createAction(
  '[Payments] Select To Account Fail'
);

export const classifyPayment = createAction('[Payments] Clasify Payment');

export const classifyPaymentSuccess = createAction(
  '[Payments] Clasify Payment Success',
  (payload: fromModel.Classification) => ({ payload })
);

export const classifyPaymentFail = createAction(
  '[Payments] Clasify Payment Fail'
);

export const updateFormCurrency = createAction(
  '[Payments] Update formData currency',
  (payload: string) => ({ payload })
);

export const updatePaymentDate = createAction(
  '[Payments] Update formData paymentDate',
  (payload: moment.Moment) => ({ payload })
);

export const updateDetails = createAction(
  '[Payments] Update formData details',
  (payload: string[]) => ({ payload })
);

export const updateAmount = createAction(
  '[Payments] Update formData amount & effectiveAmount',
  (payload: number) => ({ payload })
);

export const validate = createAction('[Payments] Validate');

export const validateSuccess = createAction(
  '[Payments] Validate Success',
  (payload: fromModel.Validate) => ({ payload })
);

export const validateFail = createAction('[Payments] Validate Fail');

export const checkTxn = createAction('[Payments] Check Txn');

export const checkTxnSuccess = createAction('[Payments] Check Txn Success');

export const checkTxnFail = createAction('[Payments] Check Txn Fail');

export const postPayment = createAction('[Payments] Post Payment');

export const postPaymentSuccess = createAction(
  '[Payments] Post Payment Success',
  (payload: fromModel.PostPaymentResponse) => ({ payload })
);

export const postPaymentFail = createAction('[Payments] Post Payment Fail');

export const resetForm = createAction('[Payments] Reset Form');

export const resetStore = createAction('[Payments] Reset Store');
