import { Injectable } from '@angular/core';

import { Actions, createEffect, ofType } from '@ngrx/effects';

import { of } from 'rxjs';
import {
  catchError,
  map,
  mergeMap,
  take,
  withLatestFrom
} from 'rxjs/operators';

import * as fromActions from './payments.actions';
import * as fromModel from './payments.model';

import { PaymentsService } from './payments.service';

import { AccountsFacade } from '@rf-store/accounts/accounts.facade';
import { PaymentsFacade } from './payments.facade';

import { ToasterService } from '@rf-shared/components/toaster/toaster.service';

@Injectable()
export class PaymentsEffects {
  constructor(
    private readonly $actions: Actions,
    private readonly paymentsService: PaymentsService,
    private readonly paymentsFacade: PaymentsFacade,
    private readonly accountsFacade: AccountsFacade,
    private readonly toasterService: ToasterService
  ) {}

  loadEligibleStandardPayment$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.loadEligibleStandardPayment),
      withLatestFrom(this.accountsFacade.items$),
      mergeMap(([_, accounts]) =>
        this.paymentsService.loadEligibleStandardPaymentApi().pipe(
          map((res) => {
            const data = accounts.filter((item) => res.includes(item.id));

            return fromActions.loadEligibleStandardPaymentSuccess(data);
          }),
          catchError(() => {
            this.toasterService.error('general__label__tehnical_error');

            return of(fromActions.loadEligibleStandardPaymentFail());
          })
        )
      )
    )
  );

  loadEligibleStandardPaymentWithQueryParams$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.loadEligibleStandardPaymentWithQueryParams),
      withLatestFrom(
        this.accountsFacade.items$,
        this.paymentsFacade.postFormFromIban$
      ),
      mergeMap(([_, accounts, iban]) =>
        this.paymentsService
          .loadEligibleStandardPaymentWithQueryParamsApi(iban)
          .pipe(
            map((res) => {
              const data = accounts
                .filter((item) => res.includes(item.id))
                .filter((item) => item.iban !== iban);

              return fromActions.loadEligibleStandardPaymentWithQueryParamsSuccess(
                data
              );
            }),
            catchError(() => {
              this.toasterService.error('general__label__tehnical_error');

              return of(
                fromActions.loadEligibleStandardPaymentWithQueryParamsFail()
              );
            })
          )
      )
    )
  );

  selectFromAccount$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.selectFromAccount),
      mergeMap((value) =>
        this.paymentsFacade.postFormFromAccounts$(value.payload).pipe(
          take(1),
          map((accounts) => {
            if (accounts) {
              if (accounts.length > 0) {
                const item = accounts.reduce((_, curr) => curr);

                return item;
              }
            }

            return null;
          }),
          map((item) => {
            if (item) {
              return fromActions.selectFromAccountSuccess(item);
            } else {
              return fromActions.selectFromAccountFail();
            }
          })
        )
      )
    )
  );

  selectToAccount$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.selectToAccount),
      mergeMap((value) =>
        this.paymentsFacade.postFormToAccounts$(value.payload).pipe(
          take(1),
          map((accounts) => {
            if (accounts) {
              if (accounts.length > 0) {
                const item = accounts.reduce((_, curr) => curr);

                return item;
              }
            }

            return null;
          }),
          map((item) => {
            if (item) {
              return fromActions.selectToAccountSuccess(item);
            } else {
              return fromActions.resetToAccount();
            }
          })
        )
      )
    )
  );

  classifyPayment$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.classifyPayment),
      withLatestFrom(this.paymentsFacade.classifyPayment$),
      map(([_, payload]) => ({ ...payload })),
      mergeMap((payload) => {
        return this.paymentsService.classifyPaymentApi(payload).pipe(
          map((data) => {
            return fromActions.classifyPaymentSuccess(data);
          }),
          catchError(() => of(fromActions.classifyPaymentFail()))
        );
      })
    )
  );

  validate$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.validate),
      withLatestFrom(this.paymentsFacade.postForm$),
      map(([_, payload]) => ({
        actionId: payload.actionId,
        channelSubtype: payload.channelSubtype,
        effectiveAmount: payload.effectiveAmount
      })),
      mergeMap((payload: fromModel.ValidatePayload) =>
        this.paymentsService.validateApi(payload).pipe(
          map((data) => fromActions.validateSuccess(data)),
          catchError(() => of(fromActions.validateFail()))
        )
      )
    )
  );

  checkTxn = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.checkTxn),
      withLatestFrom(this.paymentsFacade.postForm$),
      map(([_, payload]) => ({
        actionId: payload.actionId,
        effectiveAmount: payload.effectiveAmount
      })),
      mergeMap((payload: fromModel.ValidatePayload) =>
        this.paymentsService.checkTxnApi(payload).pipe(
          map(() => fromActions.checkTxnSuccess()),
          catchError(() => of(fromActions.checkTxnFail()))
        )
      )
    )
  );

  postPayment$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.postPayment),
      withLatestFrom(this.paymentsFacade.postForm$),
      mergeMap(([_, postForm]) =>
        this.paymentsService.postPaymentApi(postForm).pipe(
          map((data) => fromActions.postPaymentSuccess(data)),
          catchError(() => of(fromActions.postPaymentFail()))
        )
      )
    )
  );
}
