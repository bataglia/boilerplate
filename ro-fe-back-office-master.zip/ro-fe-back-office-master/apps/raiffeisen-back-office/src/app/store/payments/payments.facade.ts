import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as moment from 'moment';

import * as fromActions from './payments.actions';
import * as fromModel from './payments.model';
import * as fromSelectors from './payments.selectors';

/**
 * This Facade will expose all selectors(slices of data) as Observables and dispatch actions.
 */

@Injectable()
export class PaymentsFacade {
  fromAccounts$ = this.store.pipe(select(fromSelectors.selectFromAccounts));

  toAccounts$ = this.store.pipe(select(fromSelectors.selectToAccounts));

  dbLoading$ = this.store.pipe(select(fromSelectors.selectDbLoading));

  dbLoaded$ = this.store.pipe(select(fromSelectors.selectDbLoaded));

  postFormfromAccount$ = this.store.pipe(
    select(fromSelectors.selectPostFormFromAccount)
  );

  postFormtoAccount$ = this.store.pipe(
    select(fromSelectors.selectPostFormToAccount)
  );

  postFormFromIban$ = this.store.pipe(
    select(fromSelectors.selectPostFormFromIban)
  );

  classifyPayment$ = this.store.pipe(
    select(fromSelectors.selectClassifyPayment)
  );

  classifyFields$ = this.store.pipe(select(fromSelectors.selectClassifyFields));

  postForm$ = this.store.pipe(select(fromSelectors.selectPostForm));

  postFormCurrency$ = this.store.pipe(
    select(fromSelectors.selectPostFormCurrency)
  );

  postFormBasicPaymentDate$ = this.store.pipe(
    select(fromSelectors.selectPostFormBasicPaymentDate)
  );

  postFormFromAccountIban$ = this.store.pipe(
    select(fromSelectors.selectPostFormFromAccountIban)
  );

  postFormToAccountIban$ = this.store.pipe(
    select(fromSelectors.selectPostFormToAccountIban)
  );

  postFormAmount$ = this.store.pipe(select(fromSelectors.selectPostFormAmount));

  postFormDetails$ = this.store.pipe(
    select(fromSelectors.selectPostFormDetails)
  );

  selectedFromAccount$ = this.store.pipe(
    select(fromSelectors.selectSelectedFromAccount)
  );

  selectedToAccount$ = this.store.pipe(
    select(fromSelectors.selectSelectedToAccount)
  );

  postFormFromAccounts$(value: fromModel.Account) {
    return this.store.pipe(
      select(fromSelectors.selectPostFormFromAccounts(value))
    );
  }

  fromAccountsBalance$(value: fromModel.Account) {
    return this.store.pipe(
      select(fromSelectors.selectFromAccountsBalance(value))
    );
  }

  postFormToAccounts$(value: fromModel.Account) {
    return this.store.pipe(
      select(fromSelectors.selectPostFormToAccounts(value))
    );
  }

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  validate() {
    this.store.dispatch(fromActions.validate());
    this.store.dispatch(fromActions.checkTxn());
  }

  loadEligibleStandardPayment() {
    this.store.dispatch(fromActions.loadEligibleStandardPayment());
  }

  loadEligibleStandardPaymentWithQueryParams() {
    this.store.dispatch(
      fromActions.loadEligibleStandardPaymentWithQueryParams()
    );
  }

  classifyPayment() {
    this.store.dispatch(fromActions.classifyPayment());
  }

  selectFromAccount(value: fromModel.Account) {
    this.store.dispatch(fromActions.selectFromAccount(value));
  }

  selectToAccount(value: fromModel.Account) {
    this.store.dispatch(fromActions.selectToAccount(value));
  }

  updateFormCurrency(value: string) {
    this.store.dispatch(fromActions.updateFormCurrency(value));
  }

  updatePaymentDate(value: moment.Moment) {
    this.store.dispatch(fromActions.updatePaymentDate(value));
  }

  updateDetails(value: string[]) {
    this.store.dispatch(fromActions.updateDetails(value));
  }

  updateAmount(value: number) {
    this.store.dispatch(fromActions.updateAmount(value));
  }

  postPayment() {
    this.store.dispatch(fromActions.postPayment());
  }

  resetForm() {
    this.store.dispatch(fromActions.resetForm());
  }

  resetStore() {
    this.store.dispatch(fromActions.resetStore());
  }
}
