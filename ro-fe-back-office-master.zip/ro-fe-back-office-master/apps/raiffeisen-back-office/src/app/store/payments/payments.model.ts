import * as moment from 'moment';

export interface InitialState {
  dbLoading: boolean;
  dbLoaded: boolean;

  fromAccounts: Account[];
  toAccounts: Account[];

  postForm: PostPaymentPayload;
  classifyPayment: ClassifyPaymentPayload;

  classificationFields: ClassificationFields[];

  selectedFromAccount: Account | null;
  selectedToAccount: Account | null;

  validate: Validate;
  checkTxn: boolean;

  postPaymentResponse?: PostPaymentResponse;
}

export interface PaymentTemplates {
  actionId: string;
  avatarName: string;
  basic: Basic;
  billDetails: BillDetails;
  currency: string;
  details: string[];
  favorite: boolean;
  fromAccount: FromToAccount;
  name: string;
  payee: Payee;
  payeeAdditionalInfo: PayeeAdditionalInfo; // this needs to be confirmed
  paymentOrderNo: number;
  smAvailability: boolean;
  taxDetails: TaxDetails;
  templateId: number;
  toAccount: FromToAccount;
}

export interface Basic {
  feeType?: string;
  priority?: string;
}

export interface FromToAccount {
  iban: string;
  olp?: boolean;
  owner?: boolean;
  representative?: boolean;
}

export interface BillDetails {
  field1: string;
  field2: string;
  field3: string;
  field4: string;
  field5: string;
  field6: string;
  field7: string;
  field8: string;
  field9: string;
  field10: string;
}

export interface Payee {
  bank: PayeeBank;
  fullName: string;
}

export interface PayeeAdditionalInfo {
  address?: string;
  name?: string;
}

export interface PayeeBank {
  bicCode: string;
}

export interface TaxDetails {
  taxBeneficiaryFiscalCode: string;
}

export interface EligiblePostPayload {
  accountTypeProductIds: EligiblePayment[];
}

export interface EligiblePayment {
  alows?: EligibleAllows;
  prodId: string;
  typeId: string;
}

export interface EligibleAllows {
  cr: string[];
  db: string[];
}

export interface BillPaymentServices {
  account: BillServicesAccount;
  barCodeService: boolean;
  manualService: boolean;
  providerId: string;
  providerLogo: string;
  providerName: string;
  quickPaymentFieldName: string;
  quickPaymentSupplierType: string;
  serviceId: string;
  serviceName: string;
  supportsQuickPayment: boolean;
}

export interface BillServicesAccount {
  cif: string;
  currency: string;
  iban: string;
  productId: string;
  status: string;
}

export interface OwnEligibility {
  typeId: string;
  eligibilities: Eligibilities[];
}

export interface Eligibilities {
  cifCondition: string;
  currencyCondition: string;
  typeId: string;
}

export interface ClassifyPaymentPayload {
  currency: string | null;
  fromAccount: ClassifyPaymentFromToAccount;
  toAccount: ClassifyPaymentFromToAccount;
  payee: ClassifyPaymentPayloadPayeePayeer;
  payer: ClassifyPaymentPayloadPayeePayeer;
}

export interface ClassifyPaymentFromToAccount {
  iban: string;
  currency: string;
  productId: string;
  status: string;
}

export interface ClassifyPaymentPayloadPayeePayeer {
  cif: string;
}

export interface Classification {
  classification: ClassificationObject;
}

export interface ClassificationObject {
  actionId: string;
  ui: ClassificationUi;
}

export interface ClassificationUi {
  fields: ClassificationFields[];
}

export interface ClassificationFields {
  name: string;
  type: string;
  mandatory?: boolean;
  placeholderId: string;
  values?: ClassificationValues[];
  rules: ClassificationRules[];
}

export interface ClassificationRules {
  ruleId: string;
  value: string;
}

export interface ClassificationValues {
  disabled: boolean;
  selected: boolean;
  value: string;
}

export interface ExchangeRatesPayload {
  actionId: string[];
  fromCurrency: string[];
  toCurrency: string[];
  transactionAmount: string[];
  transactionCurrency: string[];
}

export interface ExchangeRates {
  effectiveAmount: number;
  exchangeType: string;
  expirationTime: moment.Moment;
  fxRate: number;
  fxRateId: string;
  multiplier: number;
  primaryCurrency: string;
  secondaryCurrency: string;
}

export interface SearchData {
  matchesDepositTag: boolean;
  matchesMobileTopupTag: boolean;
  matchesRamTag: boolean;
  matchesTaxTag: boolean;
  matchesWuSendTag: boolean;
  topBeneficiaries: string[]; // this needs to be confirmed
}

export interface ValidatePayload {
  actionId: string;
  effectiveAmount: number;
  channelSubtype?: string;
}

export interface Validate {
  biometrics: boolean;
  valid: boolean;
}

export interface GrantsList {
  attributes: GrantsAttributes[];
  clientId: string;
  id: string;
  isEnabled: boolean;
  tokens: GrantsTokens[];
}

export interface GrantsAttributes {
  name: string;
  readonly: boolean;
  sensitive: boolean;
  value: string;
}

export interface GrantsTokens {
  dateCreated: string;
  lastUsed: string;
  lifetime: number;
  scope: string;
  subType: string;
  type: string;
}

export interface PostPaymentPayload {
  actionId: string;
  amount: number;
  effectiveAmount: number;
  currency: string;
  channelSubtype: string;
  happyHourPayment: boolean;
  fxRateId?: string;
  details: string[];
  fromAccount: FromToAccount;
  toAccount: FromToAccount;
  basic: PaymentPayloadBasic;
  repetition?: PaymentRepetition;
}

export interface PaymentRepetition {
  period: string;
  frequency: string;
  expirationDate: string;
}

export interface PaymentPayloadBasic {
  paymentDate: moment.Moment;
}

export interface PostPaymentResponse {
  groupId: string;
  pendingActionIds: string[];
}

export interface PendingAction {
  id: string;
  status: string;
}

export interface Account {
  accountKey: string;
  balance: number;
  branchId: string;
  currency: string;
  eligibleForFeed: boolean;
  iban: string;
  id: string;
  interestRate?: string;
  nickname?: string;
  maturityDate?: string;
  olp: boolean;
  openingDate: string;
  overdraftLimit?: string;
  owner: boolean;
  ownerCif: string;
  productId: string;
  productName: string;
  representative: boolean;
  status: string;
  typeId: string;
}
