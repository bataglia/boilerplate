import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { PaymentsEffects } from './payments.effects';
import { PaymentsFacade } from './payments.facade';
import { reducer } from './payments.reducer';
import { PaymentsService } from './payments.service';

@NgModule({
  imports: [
    StoreModule.forFeature('payments', reducer),
    EffectsModule.forFeature([PaymentsEffects])
  ],
  providers: [PaymentsService, PaymentsFacade]
})
export class PaymentsStateModule {}
