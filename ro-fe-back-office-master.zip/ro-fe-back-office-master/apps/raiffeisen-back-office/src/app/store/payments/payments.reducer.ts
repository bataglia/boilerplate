import { Action, createReducer, on } from '@ngrx/store';
import * as moment from 'moment';

import * as fromActions from './payments.actions';
import * as fromModel from './payments.model';

// Define an initial sate of the payments store
export const initialState: fromModel.InitialState = {
  dbLoading: false,
  dbLoaded: false,

  // Eligible accounts from accounts store filtered with /eligible/standard-payment/db
  fromAccounts: [],

  // Eligible accounts from accounts store filtered with eligible/standard-payment/cr?sourceAccountIban=RO73RZBR0000000000000000
  toAccounts: [],
  // postPayment payload
  postForm: {
    actionId: '',
    amount: 0,
    basic: { paymentDate: moment() },
    channelSubtype: 'ROATH',
    currency: '',
    details: [],
    effectiveAmount: 0,
    fromAccount: { iban: '' },
    happyHourPayment: false,
    toAccount: { iban: '' }
  },

  selectedFromAccount: null,
  selectedToAccount: null,

  // classification payload
  classifyPayment: {
    currency: null,
    fromAccount: { iban: '', currency: '', productId: '', status: '' },
    toAccount: { iban: '', currency: '', productId: '', status: '' },
    payee: { cif: '' },
    payer: { cif: '' }
  },

  // build forms with
  classificationFields: [],

  validate: {
    biometrics: false,
    valid: false
  },
  checkTxn: false
};

/**
 * Using the declared Actions we will adapt the initial state accordingly
 */
export const reducerFn = createReducer(
  initialState,

  on(fromActions.resetStore, () => ({ ...initialState })),

  on(fromActions.resetForm, (state) => ({
    fromAccounts: state.fromAccounts,
    dbLoading: state.dbLoading,
    dbLoaded: state.dbLoaded,

    toAccounts: initialState.toAccounts,
    postForm: initialState.postForm,
    selectedFromAccount: initialState.selectedFromAccount,
    selectedToAccount: initialState.selectedToAccount,
    classifyPayment: initialState.classifyPayment,
    classificationFields: initialState.classificationFields,
    validate: initialState.validate,
    checkTxn: initialState.checkTxn
  })),

  on(fromActions.loadEligibleStandardPayment, (state) => ({
    ...state,
    dbLoading: true
  })),

  on(fromActions.loadEligibleStandardPaymentSuccess, (state, { payload }) => ({
    ...state,
    fromAccounts: payload,
    dbLoading: false,
    dbLoaded: true
  })),

  on(fromActions.loadEligibleStandardPaymentFail, (state) => ({
    ...state,
    dbLoading: false,
    dbLoaded: false
  })),

  on(
    fromActions.loadEligibleStandardPaymentWithQueryParamsSuccess,
    (state, { payload }) => ({
      ...state,
      toAccounts: payload
    })
  ),

  on(fromActions.selectFromAccountSuccess, (state, { payload }) => ({
    ...state,
    postForm: {
      ...state.postForm,
      fromAccount: { iban: payload.iban }
    },
    classifyPayment: {
      ...state.classifyPayment,
      fromAccount: {
        iban: payload.iban,
        status: payload.status,
        productId: payload.productId,
        currency: payload.currency.replace('Lei', 'RON')
      },
      payee: { cif: payload.ownerCif }
    },
    selectedFromAccount: payload
  })),

  on(fromActions.selectToAccountSuccess, (state, { payload }) => ({
    ...state,
    postForm: {
      ...state.postForm,
      toAccount: { iban: payload.iban }
    },
    classifyPayment: {
      ...state.classifyPayment,
      toAccount: {
        iban: payload.iban,
        status: payload.status,
        productId: payload.productId,
        currency: payload.currency.replace('Lei', 'RON')
      },
      payer: { cif: payload.ownerCif }
    },
    selectedToAccount: payload
  })),

  on(fromActions.resetToAccount, (state) => ({
    ...state,
    postForm: {
      ...state.postForm,
      toAccount: initialState.postForm.toAccount
    },
    classifyPayment: {
      ...state.classifyPayment,
      toAccount: initialState.classifyPayment.toAccount,
      payer: initialState.classifyPayment.payer
    },
    selectedToAccount: null
  })),

  on(fromActions.classifyPaymentSuccess, (state, { payload }) => ({
    ...state,
    postForm: { ...state.postForm, actionId: payload.classification.actionId },
    classificationFields: [
      ...initialState.classificationFields,
      ...payload.classification.ui.fields
    ]
  })),

  on(fromActions.updateFormCurrency, (state, { payload }) => ({
    ...state,
    postForm: {
      ...state.postForm,
      currency: payload
    }
  })),

  on(fromActions.updatePaymentDate, (state, { payload }) => ({
    ...state,
    postForm: {
      ...state.postForm,
      basic: {
        ...state.postForm.basic,
        paymentDate: payload
      }
    }
  })),

  on(fromActions.updateDetails, (state, { payload }) => ({
    ...state,
    postForm: {
      ...state.postForm,
      details: payload
    }
  })),

  on(fromActions.updateAmount, (state, { payload }) => ({
    ...state,
    postForm: {
      ...state.postForm,
      amount: payload,
      effectiveAmount: payload
    }
  })),

  on(fromActions.validateSuccess, (state, { payload }) => ({
    ...state,
    validate: payload
  })),

  on(fromActions.checkTxnSuccess, (state) => ({
    ...state,
    checkTxn: true
  })),

  on(fromActions.checkTxnFail, (state) => ({
    ...state,
    checkTxn: false
  })),

  on(fromActions.postPaymentSuccess, (state, { payload }) => ({
    ...state,
    postPaymentResponse: payload
  }))
);

// general reducer function
export function reducer(
  state: fromModel.InitialState,
  action: Action
): fromModel.InitialState {
  return reducerFn(state, action);
}
