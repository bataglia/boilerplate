import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromModel from './payments.model';

// create a state from where to select, this key is defined in the module.
export const selectPaymentsState = createFeatureSelector<
  fromModel.InitialState
>('payments');

export const selectFromAccounts = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.fromAccounts
);

export const selectToAccounts = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.toAccounts
);

export const selectDbLoading = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.dbLoading
);

export const selectDbLoaded = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.dbLoaded
);

export const selectPostFormFromAccount = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.fromAccount
);

export const selectPostFormToAccount = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.toAccount
);

export const selectClassifyPayment = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.classifyPayment
);

export const selectClassifyFields = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.classificationFields
);

export const selectPostFormFromIban = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.fromAccount.iban
);

////// Selectors from store to use in individual forms

export const selectSelectedFromAccount = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.selectedFromAccount
);

export const selectSelectedToAccount = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.selectedToAccount
);

export const selectPostFormFromAccounts = (value: fromModel.Account) =>
  createSelector(
    selectPaymentsState,
    (state: fromModel.InitialState) =>
      value
        ? state.fromAccounts.filter(
            (item) => item.accountKey === value.accountKey
          )
        : null
  );

export const selectFromAccountsBalance = (value: fromModel.Account) =>
  createSelector(
    selectPaymentsState,
    (state: fromModel.InitialState) =>
      state.fromAccounts
        .filter((item) => item.accountKey === value.accountKey)
        .reduce((_, curr) => {
          return curr.balance;
        }, 0)
  );

export const selectPostFormToAccounts = (value: fromModel.Account) =>
  createSelector(
    selectPaymentsState,
    (state: fromModel.InitialState) =>
      value
        ? state.toAccounts.filter(
            (item) => item.accountKey === value.accountKey
          )
        : null
  );

export const selectPostFormBasicPaymentDate = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.basic.paymentDate
);

export const selectPostFormCurrency = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.currency
);

export const selectPostFormFromAccountIban = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.fromAccount.iban
);

export const selectPostFormToAccountIban = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.toAccount.iban
);

export const selectPostFormAmount = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.amount
);

export const selectPostFormDetails = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm.details
);

export const selectPostForm = createSelector(
  selectPaymentsState,
  (state: fromModel.InitialState) => state.postForm
);
