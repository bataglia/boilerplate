import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { buildQueryParams, getBaseUrl } from '@utils/helper.functions';

import * as fromModel from './payments.model';

/**
 * Http methods.
 */
@Injectable()
export class PaymentsService {
  version = 'v1';
  version2 = 'v2';

  constructor(private readonly http: HttpClient) {}

  loadCurrenciesApi(): Observable<string[]> {
    const url = `${getBaseUrl()}services/payments-ws/${
      this.version
    }/currencies`;

    return this.http.get<string[]>(url, {
      withCredentials: true
    });
  }

  loadPaymentTemplatesApi(): Observable<fromModel.PaymentTemplates[]> {
    const url = `${getBaseUrl()}services/payments-templates/${
      this.version
    }/template/list`;

    return this.http.get<fromModel.PaymentTemplates[]>(url, {
      withCredentials: true
    });
  }

  loadEligiblePaymentApi(
    payload: fromModel.EligiblePostPayload
  ): Observable<fromModel.EligiblePayment[]> {
    const url = `${getBaseUrl()}services/accounts-ws/${
      this.version
    }/eligible/payment`;

    return this.http.post<fromModel.EligiblePayment[]>(url, payload, {
      withCredentials: true
    });
  }

  loadEligibleStandardPaymentApi(): Observable<string[]> {
    const url = `${getBaseUrl()}services/accounts-ws/${
      this.version
    }/eligible/standard-payment/db`;

    return this.http.get<string[]>(url, {
      withCredentials: true
    });
  }

  loadOwnEligibilityApi(): Observable<string> {
    const url = `${getBaseUrl()}services/accounts-ws/${
      this.version
    }accounts/eligibility/own`;

    return this.http.get<string>(url, {
      withCredentials: true
    });
  }

  loadBillPaymentServicesApi(): Observable<fromModel.BillPaymentServices[]> {
    const url = `${getBaseUrl()}services/payments-ws/${
      this.version
    }/bill-payment/services`;

    return this.http.get<fromModel.BillPaymentServices[]>(url, {
      withCredentials: true
    });
  }

  loadEligibleStandardPaymentWithQueryParamsApi(
    iban: string
  ): Observable<string[]> {
    const url = `${getBaseUrl()}services/accounts-ws/${
      this.version
    }/eligible/standard-payment/cr`;

    const httpParams: HttpParams = buildQueryParams({
      sourceAccountIban: [iban]
    });

    return this.http.get<string[]>(url, {
      withCredentials: true,
      params: httpParams
    });
  }

  classifyPaymentApi(
    payload: fromModel.ClassifyPaymentPayload
  ): Observable<fromModel.Classification> {
    const url = `${getBaseUrl()}services/payments-ws/${
      this.version
    }/classify-payment`;

    return this.http.post<fromModel.Classification>(url, payload, {
      withCredentials: true
    });
  }

  getExchangeRatesApi(
    payload: fromModel.ExchangeRatesPayload
  ): Observable<fromModel.ExchangeRates> {
    const url = `${getBaseUrl()}services/fx-rates-ws/${this.version2}/exchange`;

    const httpParams: HttpParams = buildQueryParams(payload);

    return this.http.get<fromModel.ExchangeRates>(url, {
      withCredentials: true,
      params: httpParams
    });
  }

  searchApi(query: string): Observable<fromModel.SearchData> {
    const url = `${getBaseUrl()}services/payments-ws/${this.version}/search`;

    const httpParams: HttpParams = buildQueryParams({
      query: [query.toLocaleUpperCase()]
    });

    return this.http.get<fromModel.SearchData>(url, {
      withCredentials: true,
      params: httpParams
    });
  }

  validateApi(
    payload: fromModel.ValidatePayload
  ): Observable<fromModel.Validate> {
    const url = `${getBaseUrl()}services/payments-ws/${this.version}/validate`;

    return this.http.post<fromModel.Validate>(url, payload, {
      withCredentials: true
    });
  }

  grantsApi(): Observable<fromModel.GrantsList> {
    const url = `${getBaseUrl()}services/isam-service/${
      this.version
    }/grants/list`;

    return this.http.get<fromModel.GrantsList>(url, {
      withCredentials: true
    });
  }

  checkTxnApi(payload: fromModel.ValidatePayload) {
    const url = `${getBaseUrl()}services/payments-ws/${this.version}/check-txn`;

    // this will return a status code
    return this.http.post(url, payload, {
      withCredentials: true
    });
  }

  postPaymentApi(
    payload: fromModel.PostPaymentPayload
  ): Observable<fromModel.PostPaymentResponse> {
    const url = `${getBaseUrl()}services/payments-ws/${
      this.version
    }/post-payment`;

    // this will return a status code
    return this.http.post<fromModel.PostPaymentResponse>(url, payload, {
      withCredentials: true
    });
  }

  pendingActionApi(id: string): Observable<fromModel.PendingAction[]> {
    const url = `${getBaseUrl()}services/payments-ws/${
      this.version2
    }/pending-action/status/${id}`;

    return this.http.get<fromModel.PendingAction[]>(url, {
      withCredentials: true
    });
  }
}
