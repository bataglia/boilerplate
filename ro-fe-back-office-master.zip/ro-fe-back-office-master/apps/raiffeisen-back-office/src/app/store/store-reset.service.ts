import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

import { ToasterService } from '@rf-shared/components/toaster/toaster.service';
import { AccountsFacade } from './accounts/accounts.facade';
import { AuthFacade } from './auth/auth.facade';
import { UtilsFacade } from './utils/utils.facade';

import { environment } from '@env/environment';

import { AccountStatementsFacade } from './account-statements/account-statements.facade';
import { CardsFacade } from './cards/cards.facade';
import { PaymentsFacade } from './payments/payments.facade';
import { TransactionHistoryFacade } from './transaction-history/transaction-history.facade';

@Injectable({ providedIn: 'root' })
export class StoreResetService {
  version = 'v1';

  constructor(
    private readonly accountsFacade: AccountsFacade,
    private readonly authFacade: AuthFacade,
    private readonly cardsFacade: CardsFacade,
    private readonly utilsFacade: UtilsFacade,
    private readonly paymentsFacade: PaymentsFacade,
    private readonly toasterService: ToasterService,
    private readonly accountStatementFacade: AccountStatementsFacade,
    private readonly transactionHistoryFacade: TransactionHistoryFacade,
    private readonly router: Router,
    private readonly http: HttpClient
  ) {}

  clearStates() {
    this.authFacade.resetStore();
    this.accountsFacade.resetStore();
    this.cardsFacade.resetStore();
    this.utilsFacade.resetStore();
    this.paymentsFacade.resetStore();
    this.accountStatementFacade.reset();
    this.transactionHistoryFacade.reset();
  }

  clearStorage() {
    sessionStorage.clear();
    localStorage.clear();
  }

  clear() {
    this.clearStates();
    this.clearStorage();
    this.toasterService.clear();
    this.router.navigate(['/login']);
  }

  redirectToPf() {
    this.clearStates();
    const location = `${environment.protocol}://${environment.basePath}/portalserver/raiffeisen-portal/index`;

    window.location.href = location;
  }

  logoutWithoutRedirect() {
    this.http
      .post(
        `${environment.protocol}://${environment.basePath}/services/auth/${this.version}/logout`,
        {},
        {
          withCredentials: true
        }
      )
      .subscribe();
  }

  resetAllStates() {
    this.http
      .post(
        `${environment.protocol}://${environment.basePath}/services/auth/${this.version}/logout`,
        {},
        {
          withCredentials: true
        }
      )
      .pipe(
        tap(() => {
          this.clear();
        }),
        catchError((err) => {
          if (environment.isEnv !== 'live') {
            // tslint:disable-next-line: no-console
            console.warn('Logout was not successful from the server!');
          }

          return of(err);
        })
      )
      .subscribe();
  }
}
