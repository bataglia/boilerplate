import { NgModule } from '@angular/core';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { InboxModule } from '@rf-store/inbox/inbox.module';
import { AccountStatementsStateModule } from './account-statements/account-statements.module';
import { AccountsStateModule } from './accounts/accounts.module';
import { AuthStateModule } from './auth/auth.module';
import { CardsStateModule } from './cards/cards.modules';
import { PaymentsStateModule } from './payments/payments.module';
import { TransactionHistoryStateModule } from './transaction-history/transaction-history.module';
import { UtilsStateModule } from './utils/utils.module';

const imports = [
  AccountsStateModule,
  AuthStateModule,
  UtilsStateModule,
  CardsStateModule,
  PaymentsStateModule,
  AccountStatementsStateModule,
  TransactionHistoryStateModule,
  InboxModule,
];

@NgModule({
  imports: [
    StoreModule.forRoot({}),
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument(),
    ...imports
  ],
  exports: [StoreModule, EffectsModule]
})
export class RfStoreModule {}
