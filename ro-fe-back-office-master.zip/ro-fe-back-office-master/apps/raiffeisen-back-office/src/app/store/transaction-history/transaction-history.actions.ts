import { createAction } from '@ngrx/store';

import * as fromModel from './transaction-history.model';

export const getTransactionHistoryList = createAction(
  '[Transaction History] Get transaction history List',
  (payload: fromModel.TransactionHistoryRequest) => ({ payload })
);

export const getTransactionHistoryListSuccess = createAction(
  '[Transaction History] Get transaction history List Success',
  (payload: fromModel.TransactionHistoryList) => ({ payload })
);

export const getTransactionHistoryListFail = createAction(
  '[Transaction History] Get transaction history List Fail'
);

export const resetTransactionHistoryList = createAction(
  '[Transaction History] Reset transaction history List'
);
