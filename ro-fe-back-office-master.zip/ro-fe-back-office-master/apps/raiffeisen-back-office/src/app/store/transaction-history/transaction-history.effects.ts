import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import { of } from 'rxjs';
import { catchError, map, mergeMap, withLatestFrom } from 'rxjs/operators';

import { ToasterService } from '@rf-shared/components/toaster/toaster.service';

import * as fromActions from './transaction-history.actions';
import { TransactionHistoryFacade } from './transaction-history.facade';
import * as fromModel from './transaction-history.model';
import { TransactionHistoryService } from './transaction-history.service';

@Injectable()
export class TransactionHistoryEffects {
  constructor(
    private readonly $actions: Actions,
    private readonly transactionHistoryService: TransactionHistoryService,
    private readonly toasterService: ToasterService,
    private readonly transactionHistoryFacade: TransactionHistoryFacade
  ) {}

  getTransactionHistoryList$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.getTransactionHistoryList),
      map((action) => action.payload),
      withLatestFrom(this.transactionHistoryFacade.pagingState$),
      mergeMap(([action, pagingState]) => {
        action.pagingState = pagingState;

        return this.transactionHistoryService
          .getTransactionHistoryList(action)
          .pipe(
            map((res) => {
              const transactions: fromModel.TransactionHistoryGroup = {
                HOLD: [],
                PENDING: [],
                SUCCESS: {},
                REJECTED: []
              };

              res.transactions.forEach((x) => {
                if (x.status === fromModel.TransactionStatusTypes.SUCCESS) {
                  if (!transactions.SUCCESS[x.postedAt]) {
                    transactions.SUCCESS[x.postedAt] = [];
                  }
                  transactions.SUCCESS[x.postedAt].push(x);
                } else if (transactions[x.status]) {
                  transactions[x.status].push(x);
                }
              });

              return fromActions.getTransactionHistoryListSuccess({
                pagingState: res.pagingState,
                fileSequenceNumber: res.fileSequenceNumber,
                transactions
              });
            }),
            catchError(() => {
              this.toasterService.error('transactions__errors__le');

              return of(fromActions.getTransactionHistoryListFail());
            })
          );
      })
    )
  );
}
