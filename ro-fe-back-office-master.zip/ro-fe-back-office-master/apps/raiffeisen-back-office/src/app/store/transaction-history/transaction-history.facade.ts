import { Injectable } from '@angular/core';

import { select, Store } from '@ngrx/store';

import * as fromActions from './transaction-history.actions';
import * as fromModel from './transaction-history.model';
import * as fromSelectors from './transaction-history.selectors';

@Injectable()
export class TransactionHistoryFacade {
  list$ = this.store.pipe(select(fromSelectors.selectList));

  loading$ = this.store.pipe(select(fromSelectors.selectLoading));

  loaded$ = this.store.pipe(select(fromSelectors.selectLoaded));

  pagingState$ = this.store.pipe(select(fromSelectors.pagingState));

  isEmpty$ = this.store.pipe(select(fromSelectors.isEmpty));

  selectTransactions$(status: fromModel.TransactionStatusTypes) {
    return this.store.pipe(select(fromSelectors.selectTransactions(status)));
  }

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  getTransactionsList(payload: fromModel.TransactionHistoryRequest) {
    this.store.dispatch(fromActions.getTransactionHistoryList(payload));
  }

  reset() {
    this.store.dispatch(fromActions.resetTransactionHistoryList());
  }
}
