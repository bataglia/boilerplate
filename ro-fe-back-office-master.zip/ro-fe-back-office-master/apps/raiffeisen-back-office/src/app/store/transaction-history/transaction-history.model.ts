export interface InitialState {
  list: TransactionHistoryList;
  loading: boolean;
  loaded: boolean;
}

export interface CounterParty {
  name: string;
  iban: string;
  avatarUrl: string;
  bank_name: string;
}

export interface TransactionHistory {
  transactionId: string;
  description: string[];
  channel: string;
  transactionType: string;
  counterparty: CounterParty;
  amount: number;
  createdAt: string;
  postedAt: string;
  status: TransactionStatusTypes;
  avatarType: string;
  payTo: boolean;
  cyberReceipt: boolean;
  attachDocument: boolean;
  transactionNotSettled: boolean;
  showYouPaidTo: true;
  showYouWithdraw: boolean;
  showYouReceiveFrom: boolean;
  showYouDeposit: boolean;
  showTransactionDate: true;
  showDescription: true;
  showLocation: boolean;
  showCardImage: boolean;
  showYouAuthorized: boolean;
  showAuthorizationExpiresAt: boolean;
  channelType: string;
  referenceNumber: string;
  originalAmount: string;
  originalCurrency: string;
  transactionSource: string;
  postingDate: number;
}

export interface TransactionHistoryResponse {
  pagingState?: string;
  fileSequenceNumber?: number;
  transactions: TransactionHistory[];
}

export interface TransactionHistoryList {
  pagingState?: string;
  fileSequenceNumber?: number;
  transactions: TransactionHistoryGroup;
}

export interface TransactionHistoryDate {
  [date: string]: TransactionHistory[];
}

export interface TransactionHistoryGroup {
  HOLD: TransactionHistory[];
  PENDING: TransactionHistory[];
  SUCCESS: TransactionHistoryDate;
  REJECTED: TransactionHistory[];
}

export interface TransactionHistoryFilter {
  includeDebitTransactions: boolean;
  includeCreditTransactions: boolean;
}

export enum TransactionStatusTypes {
  PENDING = 'PENDING',
  HOLD = 'HOLD',
  REJECTED = 'REJECTED',
  SUCCESS = 'SUCCESS'
}

export enum TransactionType {
  CREDIT = 'CREDIT',
  DEBIT = 'DEBIT'
}

export interface TransactionHistoryRequest {
  accountId: number;
  pagingState?: string;
  size: number;
  filter: TransactionHistoryFilter;
  searchText?: string;
  transactionStatusTypes: TransactionStatusTypes[];
  accountType: string;
}
