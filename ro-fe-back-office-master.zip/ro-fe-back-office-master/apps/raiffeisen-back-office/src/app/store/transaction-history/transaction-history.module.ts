import { NgModule } from '@angular/core';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { TransactionHistoryEffects } from './transaction-history.effects';
import { TransactionHistoryFacade } from './transaction-history.facade';
import { reducer } from './transaction-history.reducer';
import { TransactionHistoryService } from './transaction-history.service';

@NgModule({
  imports: [
    StoreModule.forFeature('transaction-history', reducer),
    EffectsModule.forFeature([TransactionHistoryEffects])
  ],
  providers: [TransactionHistoryService, TransactionHistoryFacade]
})
export class TransactionHistoryStateModule {}
