import { Action, createReducer, on } from '@ngrx/store';

import * as fromActions from './transaction-history.actions';
import * as fromModel from './transaction-history.model';

export const initialState: fromModel.InitialState = {
  list: { transactions: { HOLD: [], PENDING: [], SUCCESS: {}, REJECTED: [] } },
  loading: false,
  loaded: false
};

export const reducerFn = createReducer(
  initialState,
  on(fromActions.getTransactionHistoryList, (state) => ({
    ...state,
    loading: true,
    loaded: false
  })),
  on(fromActions.getTransactionHistoryListSuccess, (state, { payload }) => ({
    ...state,
    list: {
      pagingState: payload.pagingState,
      fileSequenceNumber: payload.fileSequenceNumber,
      transactions: {
        REJECTED: [
          ...state.list.transactions.REJECTED,
          ...payload.transactions.REJECTED
        ],
        HOLD: [...state.list.transactions.HOLD, ...payload.transactions.HOLD],
        PENDING: [
          ...state.list.transactions.PENDING,
          ...payload.transactions.PENDING
        ],
        SUCCESS: {
          ...state.list.transactions.SUCCESS,
          ...payload.transactions.SUCCESS
        }
      }
    },
    loading: false,
    loaded: true
  })),
  on(fromActions.getTransactionHistoryListFail, (state) => ({
    ...state,
    loading: false,
    loaded: false,
    list: initialState.list
  })),
  on(fromActions.resetTransactionHistoryList, (state) => ({
    ...state,
    ...initialState
  }))
);

export function reducer(
  state: fromModel.InitialState,
  action: Action
): fromModel.InitialState {
  return reducerFn(state, action);
}
