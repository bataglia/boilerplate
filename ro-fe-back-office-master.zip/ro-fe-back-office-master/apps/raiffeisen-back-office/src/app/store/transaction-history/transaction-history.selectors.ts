import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromModel from './transaction-history.model';

export const selectTransactionsState = createFeatureSelector<
  fromModel.InitialState
>('transaction-history');

export const selectList = createSelector(
  selectTransactionsState,
  (state: fromModel.InitialState) => state.list
);

export const selectLoading = createSelector(
  selectTransactionsState,
  (state: fromModel.InitialState) => state.loading
);

export const pagingState = createSelector(
  selectTransactionsState,
  (state: fromModel.InitialState) => state.list.pagingState
);

export const selectLoaded = createSelector(
  selectTransactionsState,
  (state: fromModel.InitialState) => state.loaded
);

export const selectTransactions = (status: fromModel.TransactionStatusTypes) =>
  createSelector(
    selectTransactionsState,
    (state: fromModel.InitialState) => state.list.transactions[status]
  );

export const isEmpty = createSelector(
  selectTransactionsState,
  (state: fromModel.InitialState) => {
    const { SUCCESS, PENDING, HOLD, REJECTED } = state.list.transactions;

    return (
      Object.keys(SUCCESS).length === 0 &&
      PENDING.length === 0 &&
      HOLD.length === 0 &&
      REJECTED.length === 0
    );
  }
);
