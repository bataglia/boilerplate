import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { getBaseUrl } from '@utils/helper.functions';

import * as fromModel from './transaction-history.model';

@Injectable()
export class TransactionHistoryService {
  version = 'v2';

  constructor(private readonly http: HttpClient) {}

  getTransactionHistoryList(
    request: fromModel.TransactionHistoryRequest
  ): Observable<fromModel.TransactionHistoryResponse> {
    return this.http.post<fromModel.TransactionHistoryResponse>(
      `${getBaseUrl()}services/transactions-service/${
        this.version
      }/transactions`,
      request,
      {
        withCredentials: true
      }
    );
  }
}
