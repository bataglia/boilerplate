Utils store has 2 actions:

1.  logout:

    - ..........

2.  docs:

    - .......... 

    
