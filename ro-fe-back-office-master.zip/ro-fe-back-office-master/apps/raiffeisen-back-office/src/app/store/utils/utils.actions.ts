import { createAction } from '@ngrx/store';
import * as fromModel from './utils.model';

// Create actions
export const footerData = createAction('[Utils] Footer Data');

export const footerDataSuccess = createAction(
  '[Utils] Footer Data Success',
  (payload: fromModel.UsefulLink[] | null) => ({ payload })
);

export const footerDataFail = createAction('[Utils] Footer Data Fail');

export const getSystemDate = createAction('[Utils] Get System Date');

export const getSystemDateSuccess = createAction(
  '[Utils] Get System Date Success',
  (payload: { timestamp: string }) => ({ payload })
);

export const getSystemDateFail = createAction('[Utils] Get System Date Fail');

export const resetStore = createAction('[Utils] Reset Store');
