// import { provideMockActions } from '@ngrx/effects/testing';
// import { TestBed } from '@angular/core/testing';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { Observable, combineLatest } from 'rxjs';
// import * as fromActions from './auth.actions';
// import { AuthService } from './auth.service';
// import { AuthEffects } from './auth.effects';
// import { cold, hot } from 'jasmine-marbles';
// import { RouterTestingModule } from '@angular/router/testing';
// import { appRoutes } from '../../app.router';
// import { DashboardModule } from '../../modules/dashboard/dashboard.module';
// import { LoginModule } from '../../modules/login/login.module';
//
// import { StoreModule } from '@ngrx/store';
// import { ApplicationComponent } from '../../application/application.component';
// import { SharedModule } from '@rf-shared/shared.module';
//
// describe('Auth Effects', () => {
//   let actions: Observable<any>;
//   let effects: AuthEffects;
//   let service: AuthService;
//
//   // let router: Router;
//   // let location: Location;
//
//   const mockPayload = {
//     accountKeysListOrder: [],
//     accountsListOrder: [],
//     branchName: '123',
//     groups: [],
//     hasEMV: false,
//     isLegalEntity: false,
//     tcUrl: '123',
//     user: {
//       avatarName: '123',
//       cui: '123',
//       id: '123',
//       leName: '123',
//       legalEntitiesContactInfo: {
//         businessSegmentation: '123',
//         salesTeamEmail: '123',
//         techSupportEmail: '123',
//         techSupportPhone: '123'
//       },
//       phoneNumbers: [],
//       primaryMobilePhone: '123',
//       segmentation: {
//         business: '123',
//         root: '123',
//         treasury: '123'
//       }
//     }
//   };
//
//   const credentials = {
//     username: 'test',
//     password: 'test'
//   };
//
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         HttpClientTestingModule,
//         DashboardModule,
//         LoginModule,
//         SharedModule,
//         RouterTestingModule.withRoutes(appRoutes),
//         StoreModule.forRoot({})
//       ],
//       declarations: [ApplicationComponent],
//       providers: [AuthEffects, AuthService, provideMockActions(() => actions)]
//     });
//
//     effects = TestBed.get(AuthEffects);
//     service = TestBed.get(AuthService);
//
//     // router = TestBed.get(Router);
//     // location = TestBed.get(Location);
//     // router.initialNavigation();
//   });
//
//   it('[Auth] login$ -> loginSuccess', () => {
//     // const action = fromActions.login(credentials);
//     // const outcome = fromActions.loginSuccess(mockPayload);
//     // actions = hot('-a', { a: action });
//     const response = cold('-a|', { a: mockPayload });
//
//     spyOn(service, 'loginApi').and.returnValue(response);
//     // const expected = cold('--b', { b: outcome });
//     // expect(effects.login$).toBeObservable(expected);
//
//     combineLatest([service.loginApi(credentials)]).subscribe((arr) => {
//       expect(arr[0]).toEqual(jasmine.objectContaining(mockPayload));
//     });
//   });
//
//   it('[Auth] login$ -> loginFail', () => {
//     const error = 'login__errors__timeout';
//
//     const action = fromActions.login(credentials);
//
//     const outcome = fromActions.loginFail(error);
//
//     actions = hot('-a', { a: action });
//
//     const response = cold('-#|', {}, error);
//
//     spyOn(service, 'loginApi').and.returnValue(response);
//
//     const expected = cold('--b', { b: outcome });
//
//     expect(effects.login$).toBeObservable(expected);
//   });
// });
