import { Injectable } from '@angular/core';

import { Actions, createEffect, ofType } from '@ngrx/effects';

import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';

import * as fromActions from './utils.actions';
import { UtilsService } from './utils.service';

@Injectable()
export class UtilsEffects {
  constructor(
    private readonly $actions: Actions,
    private readonly utilsService: UtilsService
  ) {}

  footerData$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.footerData),
      mergeMap(() => {
        return this.utilsService.footerDataApi().pipe(
          map((data) => {
            return fromActions.footerDataSuccess(data.body);
          }),
          catchError(() => {
            return of(fromActions.footerDataFail());
          })
        );
      })
    )
  );

  getSystemDate$ = createEffect(() =>
    this.$actions.pipe(
      ofType(fromActions.getSystemDate),
      mergeMap(() => {
        return this.utilsService.dateTimeApi().pipe(
          map((data) => fromActions.getSystemDateSuccess(data)),
          catchError(() => of(fromActions.getSystemDateFail))
        );
      })
    )
  );
}
