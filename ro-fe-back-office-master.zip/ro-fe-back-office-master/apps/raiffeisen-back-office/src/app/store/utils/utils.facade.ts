import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromActions from './utils.actions';
import * as fromModel from './utils.model';
import * as fromSelectors from './utils.selectors';

@Injectable()
export class UtilsFacade {
  footerTechnical$ = this.store.pipe(select(fromSelectors.selectTechnical));

  footerUserGuide$ = this.store.pipe(select(fromSelectors.selectUserGuide));

  footerGeneral$ = this.store.pipe(select(fromSelectors.selectGeneral));

  footerTerms$ = this.store.pipe(select(fromSelectors.selectTerms));

  systemDate$ = this.store.pipe(select(fromSelectors.selectSystemDate));

  isCurrentMonth$ = this.store.pipe(select(fromSelectors.selectIsCurrentMonth));

  isCurrentYear$ = this.store.pipe(select(fromSelectors.selectIsCurrentYear));

  systemTimestamp$ = this.store.pipe(
    select(fromSelectors.selectSystemTimestamp)
  );

  constructor(private readonly store: Store<fromModel.InitialState>) {}

  footerData() {
    this.store.dispatch(fromActions.footerData());
  }

  getSystemDate() {
    this.store.dispatch(fromActions.getSystemDate());
  }

  resetStore() {
    this.store.dispatch(fromActions.resetStore());
  }
}
