import * as moment from 'moment';

export interface InitialState {
  'technical-requirements': UsefulLink;
  'user-guide-web': UsefulLink;
  'general-banking-condition': UsefulLink;
  'contract-web': UsefulLink;
  systemDate: Date | moment.Moment;
  systemTimestamp: string;
}

export interface UsefulLink {
  code: string;
  name: string;
  updatedAt: string;
  url: string;
}
