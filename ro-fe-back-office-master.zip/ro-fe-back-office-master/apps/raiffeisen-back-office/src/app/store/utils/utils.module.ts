import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { UtilsEffects } from './utils.effects';
import { UtilsFacade } from './utils.facade';
import { reducer } from './utils.reducer';
import { UtilsService } from './utils.service';

@NgModule({
  imports: [
    StoreModule.forFeature('utils', reducer),
    EffectsModule.forFeature([UtilsEffects])
  ],
  providers: [UtilsService, UtilsFacade]
})
export class UtilsStateModule {}
