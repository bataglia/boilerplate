// import { reducer, initialState } from './auth.reducer';
// import * as fromActions from './auth.actions';
// import * as fromModel from './auth.model';
//
// describe('Auth Reducer', () => {
//   it('[undefined action] - should return the default state', () => {
//     const action = {} as any;
//     const state = reducer(initialState, action);
//
//     expect(state).toEqual(initialState);
//   });
//
//   it('[Auth] login - should set loading to true', () => {
//     const action = fromActions.login({ username: 'admin', password: 'admin' });
//     const state = reducer(initialState, action);
//
//     const newState = {
//       ...initialState,
//       loading: true,
//       isLoggedIn: false,
//       error: ''
//     };
//
//     expect(state.loading).toBeTruthy();
//     expect(state.isLoggedIn).toEqual(false);
//     expect(state.error).toEqual('');
//     expect(state).toEqual(newState);
//   });
//
//   it('[Auth] loginFail - should set loading to false, add the error message', () => {
//     const errorMessage = 'login failed';
//     const action = fromActions.loginFail(errorMessage);
//     const state = reducer(initialState, action);
//
//     const newState = {
//       ...initialState,
//       loading: false,
//       isLoggedIn: false,
//       error: errorMessage
//     };
//
//     expect(state.loading).toEqual(false);
//     expect(state.isLoggedIn).toEqual(false);
//     expect(state.error).toEqual(errorMessage);
//     expect(state).toEqual(newState);
//   });
//
//   it('[Auth] login - should set loading to false, add the payload', () => {
//     const successPayload: fromModel.AuthData = {
//       accountKeysListOrder: [],
//       accountsListOrder: [],
//       branchName: 'asd',
//       groups: [],
//       hasEMV: false,
//       isLegalEntity: false,
//       tcUrl: '',
//       user: {
//         avatarName: 'aaa',
//         avatarUrl: 'aaa',
//         cui: '123',
//         id: '123',
//         leName: 'asd',
//         legalEntitiesContactInfo: {
//           businessSegmentation: '',
//           salesTeamEmail: 'asd@asd.asd',
//           techSupportEmail: 'asd@asd.asd',
//           techSupportPhone: '5555555555'
//         },
//         phoneNumbers: [],
//         primaryMobilePhone: '55555555555',
//         segmentation: {
//           business: '',
//           root: '',
//           treasury: ''
//         }
//       }
//     };
//     const action = fromActions.loginSuccess(successPayload);
//     const state = reducer(initialState, action);
//
//     const newState = {
//       ...initialState,
//       authData: successPayload,
//       loading: false,
//       isLoggedIn: true,
//       error: ''
//     };
//
//     expect(state.loading).toEqual(false);
//     expect(state.isLoggedIn).toEqual(true);
//     expect(state.error).toEqual('');
//     expect(state).toEqual(newState);
//   });
// });
