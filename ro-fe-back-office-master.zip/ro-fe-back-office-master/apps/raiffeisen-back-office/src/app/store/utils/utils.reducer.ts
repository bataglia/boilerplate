import { Action, createReducer, on } from '@ngrx/store';

import * as moment from 'moment';

import { getCdnUrl, reduceArrayToObject } from '@utils/helper.functions';
import * as fromActions from './utils.actions';
import * as fromModel from './utils.model';

// Define an initial sate of the utils store
export const initialState: fromModel.InitialState = {
  'technical-requirements': {
    code: '',
    name: 'footer__navigation__labels__technical_requirements',
    updatedAt: '',
    url: `${getCdnUrl()}portal/img/docs/LE/technical-requirements.pdf`
  },
  'user-guide-web': {
    code: '',
    name: 'footer__navigation__labels__user_guide',
    updatedAt: '',
    url: `${getCdnUrl()}portal/img/docs/LE//portal/img/docs/LE/user-guide-web.pdf`
  },
  'general-banking-condition': {
    code: '',
    name: 'footer__navigation__labels__general_banking_conditions',
    updatedAt: '',
    url: `${getCdnUrl()}portal/img/docs/LE//portal/img/docs/LE/general-banking-condition.pdf`
  },
  'contract-web': {
    code: '',
    name: 'footer__navigation__labels__terms_and_conditions',
    updatedAt: '',
    url: `${getCdnUrl()}portal/img/docs/LE//portal/img/docs/LE/contract-web.pdf`
  },
  systemDate: new Date(),
  systemTimestamp: ''
};

// general reducer function
export const reducerFn = createReducer(
  // use the state
  initialState,

  on(fromActions.resetStore, fromActions.footerDataFail, () => ({
    ...initialState
  })),

  on(fromActions.footerDataSuccess, (state, { payload }) => {
    if (payload === null) {
      return { ...state };
    }

    const newState: fromModel.InitialState = reduceArrayToObject(
      payload,
      'code'
    );

    return {
      ...state,
      ...newState
    };
  }),

  on(fromActions.getSystemDateSuccess, (state, { payload }) => ({
    ...state,
    systemTimestamp: payload.timestamp,
    systemDate: moment(payload.timestamp)
  }))
);

// general reducer function
export function reducer(
  state: fromModel.InitialState,
  action: Action
): fromModel.InitialState {
  return reducerFn(state, action);
}
