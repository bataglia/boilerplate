import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as moment from 'moment';
import * as fromModel from './utils.model';

// create a state from where to select, this key is defined in the module.
export const selectUtilsState = createFeatureSelector<fromModel.InitialState>(
  'utils'
);

// select slices of the store to be used in facade to expose elements as observables
export const selectTechnical = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => state['technical-requirements']
);

export const selectUserGuide = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => state['user-guide-web']
);

export const selectGeneral = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => state['general-banking-condition']
);

export const selectTerms = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => state['contract-web']
);

export const selectSystemDate = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => state.systemDate
);

export const selectSystemTimestamp = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => state.systemTimestamp
);

export const selectIsCurrentMonth = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => (date: string) => {
    const currentMonth = moment(state.systemDate).month();
    const monthToCompare = moment(date).month();

    return currentMonth === monthToCompare && state;
  }
);

export const selectIsCurrentYear = createSelector(
  selectUtilsState,
  (state: fromModel.InitialState) => (date: string) => {
    const currentYear = moment(state.systemDate).year();
    const yearToCompare = moment(date).year();

    return currentYear === yearToCompare;
  }
);
