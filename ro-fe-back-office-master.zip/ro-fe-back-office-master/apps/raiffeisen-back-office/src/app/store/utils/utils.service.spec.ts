// import { TestBed } from '@angular/core/testing';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { AuthService } from './auth.service';
// import { cold } from 'jasmine-marbles';
// import { HttpErrorResponse } from '@angular/common/http';
//
// describe('Auth Service', () => {
//   let service: AuthService;
//
//   const mockPayload = {
//     accountKeysListOrder: [],
//     accountsListOrder: [],
//     branchName: '123',
//     groups: [],
//     hasEMV: false,
//     isLegalEntity: false,
//     tcUrl: '123',
//     user: {
//       avatarName: '123',
//       cui: '123',
//       id: '123',
//       leName: '123',
//       legalEntitiesContactInfo: {
//         businessSegmentation: '123',
//         salesTeamEmail: '123',
//         techSupportEmail: '123',
//         techSupportPhone: '123'
//       },
//       phoneNumbers: [],
//       primaryMobilePhone: '123',
//       segmentation: {
//         business: '123',
//         root: '123',
//         treasury: '123'
//       }
//     }
//   };
//
//   const credentials = {
//     username: 'test',
//     password: 'test'
//   };
//
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientTestingModule],
//       providers: [AuthService]
//     });
//     service = TestBed.get(AuthService);
//   });
//
//   it('[Auth] loginApi', () => {
//     const response = cold('-a|', { a: mockPayload });
//     spyOn(service, 'loginApi').and.returnValue(response);
//     service.loginApi(credentials).subscribe((res) => {
//       expect(res).toEqual(jasmine.objectContaining(mockPayload));
//     });
//   });
//
//   it('[Auth] setErrorMessage', () => {
//     const error1 = new HttpErrorResponse({});
//     const expect1 = 'login__errors__timeout';
//
//     const error2 = new HttpErrorResponse({
//       status: 401,
//       error: { message: 'AUTHERR00' }
//     });
//     const expect2 = 'login__errors__invalid_credentials';
//
//     const error3 = new HttpErrorResponse({
//       status: 400,
//       error: { message: 'AUTHERR06' }
//     });
//     const expect3 = 'login__errors__invalid_credentials';
//
//     expect(service.setErrorMessage(error1)).toEqual(expect1);
//     expect(service.setErrorMessage(error2)).toEqual(expect2);
//     expect(service.setErrorMessage(error3)).toEqual(expect3);
//   });
// });
