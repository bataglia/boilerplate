import {
  HttpClient,
  HttpErrorResponse,
  HttpParams,
  HttpResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import * as fromModel from './utils.model';

import { buildQueryParams, getBaseUrl } from '@utils/helper.functions';

@Injectable()
export class UtilsService {
  version = 'v1';

  constructor(private readonly http: HttpClient) {}

  footerDataApi(): Observable<HttpResponse<fromModel.UsefulLink[]>> {
    const uri = `${getBaseUrl()}services/utils-service/${
      this.version
    }/util-docs`;

    const httpParams: HttpParams = buildQueryParams({
      channelSubtype: 'ROATH'
    });

    return this.http.get<fromModel.UsefulLink[]>(uri, {
      params: httpParams,
      withCredentials: true,
      observe: 'response'
    });
  }

  dateTimeApi(): Observable<{ timestamp: string }> {
    const uri = `${getBaseUrl()}services/utils-service/${this.version}/now`;

    return this.http.get<{ timestamp: string }>(uri, { withCredentials: true });
  }
}
