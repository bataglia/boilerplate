export const CONSTANTS: { [key: string]: any } = {
  LANGUAGES: {
    RO: 'ro',
    EN: 'en'
  },

  LANGUAGE_SELECTED: 'languageSelected',

  CHANNELS: {
    WEB: 'ROATH'
  },

  USER_GROUPS: {
    RAIFFEISEN_ONLINE: 'RO_PRODUCT',
    ALLOWED: 'RO_ALLOWED',
    TERMS_AND_CONDITIONS: 'RO_TC_AGREED'
  },

  HEADERS: {
    GROUPS: 'iv-groups',
    TC_URL: 'tcUrl',
    HAS_EMV: 'has-emv',
    ENROLL_SESSION_ID: 'ENROLL_SESSION_ID'
  },

  STORAGE: {
    CARDS_LIST: 'cards_data_key',
    CREDIT_CARD_LIST: 'credit_card_data_key',
    FIRST_NAME: 'first_name',
    LAST_NAME: 'last_name',
    HASEMV: 'hasEMV',
    USER_PROFILE: 'userProfile',
    IS_LEGAL_ENTITY: 'isLegalEntity',
    ENROLL_SESSION_ID: 'enrollSessionId',
    TERMS_AND_CONDITIONS_FLOW: 'termsAndConditionsFlow',
    GRANTS_LIST: 'grantsList',
    CURRENT_SELECTED_ACCOUNT: 'current_selected_account'
  },

  GRANTS: {
    AUTHENTICATOR_CLIENT: 'AuthenticatorClient',
    SMART_MOBILE_CLIENT: 'SmartMobileClient'
  },

  TODO: {
    STATES: {
      ALERT: 0,
      RESULT: 1,
      PENDING: 2
    }
  },

  ACCOUNT: {
    TYPE: {
      CURRENT: '20',
      SAVINGS: '26',
      TIME: '30',
      LOAN: '50'
    }
  },

  LOCALE: {
    RO: {
      DECIMAL_SEPARATOR: ',',
      THOUSAND_SEPARATOR: '.'
    },
    EN: {
      DECIMAL_SEPARATOR: '.',
      THOUSAND_SEPARATOR: ','
    }
  },

  CARD: {
    STATUSES: {
      ACTIVE: 'Active',
      BLOCKED: 'Blocked',
      TEMPORARY_BLOCKED: 'TEMPORARY_BLOCKED'
    }
  },

  PRODUCT: {
    IDS: {
      CREDIT_CARD: '133'
    }
  },

  FILE_TYPES: {
    PDF: 'application/pdf',
    XLS: 'application/xsl',
    XLSX: 'application/xslx',
    MT940: 'application/mt940',
    MT942: 'application/mt942',
    TXT: 'text/plain'
  }
};
