import { registerLocaleData } from '@angular/common';
// tslint:disable: match-default-export-name
import localeEn from '@angular/common/locales/en';
import localeRo from '@angular/common/locales/ro';
import { Injectable } from '@angular/core';

import { BsLocaleService } from 'ngx-bootstrap';
import { defineLocale } from 'ngx-bootstrap/chronos';
import { enGbLocale, roLocale } from 'ngx-bootstrap/locale';
import { BehaviorSubject } from 'rxjs';

import { CONSTANTS } from './constants';

@Injectable({ providedIn: 'root' })
export class DynamicLocaleService {
  private localeSubject$: BehaviorSubject<string>;
  languages: { [key: string]: any };

  constructor(private readonly localeService: BsLocaleService) {
    this.languages = CONSTANTS.LANGUAGES;
    defineLocale('ro', roLocale);
    defineLocale('en', enGbLocale);
    registerLocaleData(localeRo, 'ro');
    registerLocaleData(localeEn, 'en');

    this.setLocale(
      localStorage.getItem(CONSTANTS.LANGUAGE_SELECTED) || this.languages.RO
    );
  }

  get locale$() {
    return this.localeSubject$.asObservable();
  }

  get locale() {
    return this.localeSubject$.value;
  }

  setLocale(locale: string) {
    localStorage.setItem(CONSTANTS.LANGUAGE_SELECTED, locale);
    if (!this.localeSubject$) {
      this.localeSubject$ = new BehaviorSubject<string>(locale);
    }
    this.localeSubject$.next(locale);
    this.localeService.use(locale);
  }
}
