/**
 * Disabled state
 *
 * true : disable feature
 * false : enable feature
 */

export const FEATURE_TOGGLE: { [key: string]: boolean } = {
  FOOTER: false,
  OTHER_FUNCTIONALITIES: false
};
