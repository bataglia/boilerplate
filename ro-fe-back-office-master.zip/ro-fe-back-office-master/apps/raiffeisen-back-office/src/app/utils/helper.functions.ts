import { HttpParams } from '@angular/common/http';
import { environment } from '@env/environment';
import { CONSTANTS } from '@utils/constants';

export const reduceArrayToObject = (arr: any[], key: string) => {
  return arr.reduce((acc, curr) => {
    acc[curr[key]] = curr;

    return acc;
  }, {});
};

export const getBaseUrl = (): string =>
  `${environment.protocol}://${environment.basePath}/`;
export const getCdnUrl = (): string =>
  `${environment.protocol}://${environment.cdnPath}/`;

export const buildQueryParams = (params: any): HttpParams => {
  let queryParams = new HttpParams();

  Object.keys(params).forEach((key: string) => {
    if (params[key] !== null && params[key] !== undefined) {
      queryParams = queryParams.append(key, params[key]);
    }
  });

  return queryParams;
};

export const saveAs = (blob: Blob, filename: string) => {
  if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveOrOpenBlob(blob, filename);

    return;
  }

  const a = document.createElement('a');

  a.href = URL.createObjectURL(blob);
  a.download = filename;
  // start download
  a.click();
};

export const formatFileSize = (bytes: string | number) => {
  const suffix = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = bytes;
  let grade = 0;

  size = Number(size);

  if (!numberIsNotZero(size)) {
    return 0;
  }

  while (size > 1024) {
    size /= 1024;
    grade += 1;
  }
  size = parseFloat(size.toFixed(2));

  return `${size}${suffix[grade]}`;
};

export const numberIsNotZero = (nr: string | number) => {
  const nrParam = nr.toString();

  if (isNaN(parseFloat(nrParam))) {
    return false;
  }

  return parseFloat(nrParam) !== 0;
};

export const formatType = (mimeType: string): string => {
  let type = '';

  switch (mimeType) {
    case CONSTANTS.FILE_TYPES.PDF:
      type = 'PDF';
      break;

    case CONSTANTS.FILE_TYPES.XLS:
      type = 'XLS';
      break;

    case CONSTANTS.FILE_TYPES.XLSX:
      type = 'XLSX';
      break;

    case CONSTANTS.FILE_TYPES.TXT:
      type = 'TXT';
      break;

    default:
      type = '';
  }

  return type;
};
