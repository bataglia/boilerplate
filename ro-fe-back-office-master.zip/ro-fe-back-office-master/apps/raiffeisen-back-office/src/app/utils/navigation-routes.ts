import { Routes } from '@angular/router';

import { appRoutes } from '../app.router';

export interface Navigation {
  title: string;
  path: string;
  feature: string;
}

export const getRoutes = () => {
  return appRoutes
    .reduce(
      (acc, curr) => {
        if (curr.path === '') {
          return curr.children as Routes;
        }

        return acc;
      },
      [] as Routes
    )
    .reduce(
      (acc, curr) => {
        if (curr.children !== undefined) {
          curr.children.forEach((x) => {
            if (x.data && x.data.title && x.data.title !== '') {
              acc.push({
                path: `${curr.path}/${x.path}`,
                data: x.data
              });
            }
          });
        } else {
          acc.push(curr);
        }

        return acc;
      },
      [] as Routes
    )
    .reduce(
      (acc, curr) => {
        if (curr.data) {
          acc.push({
            title: curr.data.title ? curr.data.title : '',
            path: `/${curr.path}`,
            feature: curr.data.feature ? curr.data.feature : null
          });
        }

        return acc;
      },
      [] as Navigation[]
    );
};
