import { Injectable } from '@angular/core';
import { EventManager } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ResizeService {
  private readonly resizeSubject = new BehaviorSubject<number>(
    window.innerWidth
  );

  get windowWidth$() {
    return this.resizeSubject.asObservable();
  }

  get windowWidth() {
    return this.resizeSubject.value;
  }

  constructor(private readonly eventManager: EventManager) {
    this.eventManager.addGlobalEventListener(
      'window',
      'resize',
      this.onResize.bind(this)
    );
  }

  onResize(event: UIEvent) {
    this.resizeSubject.next(
      (event.target as Window).innerWidth *
        ((event.target as Window).devicePixelRatio > 1
          ? 1
          : (event.target as Window).devicePixelRatio)
    );
  }
}
