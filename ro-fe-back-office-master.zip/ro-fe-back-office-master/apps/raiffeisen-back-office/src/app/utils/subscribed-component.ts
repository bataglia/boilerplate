import { OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

export class SubscribedComponent implements OnDestroy {
  private readonly subscriptions = new Subscription();

  protected registerSubscriptions(...subscriptions: Subscription[]) {
    subscriptions.forEach((subscription) =>
      this.subscriptions.add(subscription)
    );
  }

  protected unsubscribeSubscriptions() {
    this.subscriptions.unsubscribe();
  }

  protected removeSubscription(subscription: Subscription) {
    this.subscriptions.remove(subscription);
  }

  ngOnDestroy() {
    this.unsubscribeSubscriptions();
  }
}
