import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, InjectionToken } from '@angular/core';

import { ServiceDataHttpConfig } from '@backbase/foundation-ang/data-http';

import { Observable } from 'rxjs';
import { SystemDate } from '../shared/interfaces/system-data.interfaces';

const version = 'v1';

export const SYSTEM_DATA_CONFIG = new InjectionToken('ServiceDataHttpConfig');

@Injectable()
export class SystemDataService {
  constructor(
    private readonly http: HttpClient,
    @Inject(SYSTEM_DATA_CONFIG) private readonly config: ServiceDataHttpConfig
  ) {}

  getSystemDate(): Observable<SystemDate> {
    const uri = `${this.config.apiRoot}/${this.config.servicePath}/${version}/now`;

    return this.http.get<SystemDate>(uri, {
      withCredentials: true
    });
  }
}
