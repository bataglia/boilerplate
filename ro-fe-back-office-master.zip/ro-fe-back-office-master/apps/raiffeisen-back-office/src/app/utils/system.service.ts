import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { SystemDate } from '@rf-shared/interfaces/system-data.interfaces';

import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SystemDataService } from './system-data.service';

@Injectable()
export class SystemService {
  systemDate$: BehaviorSubject<Date> = new BehaviorSubject<Date>(new Date());

  get systemDate(): Observable<Date> {
    return this.systemDate$.asObservable();
  }

  constructor(private readonly systemDataService: SystemDataService) {}

  loadSystemDate() {
    this.systemDataService
      .getSystemDate()
      .pipe(
        catchError((err: HttpErrorResponse) => {
          /* tslint:disable: no-console */
          console.warn(
            'Unable to retrieve system date. Using client local date'
          );

          return of({ timestamp: '' });
        })
      )
      .subscribe((response: SystemDate) => {
        this.systemDate$.next(new Date(response.timestamp));
      });
  }
}
