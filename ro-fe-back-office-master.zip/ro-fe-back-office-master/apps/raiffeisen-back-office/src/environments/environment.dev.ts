import { Environment } from './type';

export const environment: Environment = {
  production: true,
  mockProviders: [],

  isEnv: 'dev',
  protocol: 'https',
  basePath: 'ro-dev.rbro.rbg.cc',
  cdnPath: 'https://ro-cdn-dev.rbro.rbg.cc',

  assetsStaticItemName: 'bb-raiffeisen-back-office-ang',
  assetsStaticI18n: `https://${window.location.host}/assets/i18n/`
};
