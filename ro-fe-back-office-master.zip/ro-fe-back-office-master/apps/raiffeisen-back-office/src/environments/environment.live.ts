import { Environment } from './type';

export const environment: Environment = {
  production: true,
  mockProviders: [],

  isEnv: 'live',
  protocol: 'https',
  basePath: 'ro-live.rbro.rbg.cc',
  cdnPath: 'https://ro-cdn-live.rbro.rbg.cc',

  assetsStaticItemName: 'bb-raiffeisen-back-office-ang',
  assetsStaticI18n:
    '/gateway/api/portal/static/items/bb-raiffeisen-back-office-ang/assets/i18n/'
};
