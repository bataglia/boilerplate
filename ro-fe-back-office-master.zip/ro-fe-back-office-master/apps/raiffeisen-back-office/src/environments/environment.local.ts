import { Environment } from './type';

// CXP Local configuration
export const environment: Environment = {
  production: false,
  mockProviders: [],

  isEnv: 'test',
  protocol: 'https',
  basePath: 'ro-test.rbro.rbg.cc',
  cdnPath: 'https://ro-cdn-test.rbro.rbg.cc',

  assetsStaticItemName: 'bb-raiffeisen-back-office-ang',
  assetsStaticI18n:
    '/gateway/api/portal/static/items/bb-raiffeisen-back-office-ang/assets/i18n/'
};
