import { Environment } from './type';

export const environment: Environment = {
  production: true,
  mockProviders: [],

  isEnv: 'prelive',
  protocol: 'https',
  basePath: 'ro-prelive.rbro.rbg.cc',
  cdnPath: 'https://ro-cdn-pre.rbro.rbg.cc',

  assetsStaticItemName: 'bb-raiffeisen-back-office-ang',
  assetsStaticI18n:
    '/gateway/api/portal/static/items/bb-raiffeisen-back-office-ang/assets/i18n/'
};
