import { Environment } from './type';

export const environment: Environment = {
  production: true,
  mockProviders: [],

  isEnv: 'test',
  protocol: 'https',
  basePath: 'ro-test.rbro.rbg.cc',
  cdnPath: 'https://ro-cdn-test.rbro.rbg.cc',

  assetsStaticItemName: 'bb-raiffeisen-back-office-ang',
  assetsStaticI18n: `https://${window.location.host}/assets/i18n/`
};
