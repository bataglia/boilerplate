import { Item } from '@backbase/foundation-ang/core';
import { ExternalServices } from '@backbase/foundation-ang/start';

import { Environment } from './type';

const services: ExternalServices = {};

// This runs the server standalone, without CXP, that's why we mock the portal as bellow
const pageModel: Item = {
  name: 'bb-raiffeisen-back-office-ang',
  properties: {},
  children: [
    {
      name: 'main-container-back-office',
      properties: {
        classId: 'MainContainerBackOfficeComponent'
      }
    }
  ]
};

export const environment: Environment = {
  production: false,
  mockProviders: [],
  bootstrap: {
    pageModel,
    services
  },

  isEnv: 'dev',
  protocol: 'https',
  basePath: 'ro-test.rbro.rbg.cc',
  cdnPath: '',

  assetsStaticItemName: '',
  assetsStaticI18n: 'assets/i18n/'
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
