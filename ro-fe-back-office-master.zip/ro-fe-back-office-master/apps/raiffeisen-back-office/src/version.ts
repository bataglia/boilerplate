export const APP_VERSION = '1.0.1';
