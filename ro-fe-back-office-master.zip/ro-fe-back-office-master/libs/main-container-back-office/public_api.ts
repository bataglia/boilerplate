export { MainContainerBackOfficeModule } from './src/main-container-back-office.module';
export { MainContainerBackOfficeComponent } from './src/main-container-back-office.component';
