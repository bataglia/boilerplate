import { ChangeDetectionStrategy, Component } from '@angular/core';

import { RoutableWidget } from '@backbase/foundation-ang/core';

import { routes } from './routes.config';

@RoutableWidget({
  routes
})
@Component({
  selector: 'bb-main-container-back-office',
  template: '<bb-router-outlet></bb-router-outlet>',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MainContainerBackOfficeComponent {}
