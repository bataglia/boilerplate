import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BackbaseCoreModule } from '@backbase/foundation-ang/core';

import { MainContainerBackOfficeComponent } from './main-container-back-office.component';

@NgModule({
  declarations: [MainContainerBackOfficeComponent],
  imports: [
    CommonModule,
    RouterModule,
    BackbaseCoreModule.withConfig({
      classMap: { MainContainerBackOfficeComponent }
    })
  ]
})
export class MainContainerBackOfficeModule {}
