import { Route } from '@angular/router';
// tslint:disable-next-line: no-implicit-dependencies
import { appRoutes } from 'apps/raiffeisen-back-office/src/app/app.router';

export const routes: Route[] = [...appRoutes];
